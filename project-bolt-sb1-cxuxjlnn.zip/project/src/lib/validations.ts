import { z } from 'zod';

export const signUpSchema = z
  .object({
    full_name: z.string().min(2, 'Full name must be at least 2 characters'),
    email: z.string().email('Enter a valid email address'),
    password: z
      .string()
      .min(8, 'Password must be at least 8 characters')
      .regex(/[A-Z]/, 'Add at least one uppercase letter')
      .regex(/[0-9]/, 'Add at least one number'),
    confirmPassword: z.string(),
    phone: z
      .string()
      .min(10, 'Enter a valid phone number')
      .regex(/^[0-9+\-\s]+$/, 'Phone can only contain digits, +, - and spaces'),
    role: z.enum(['donor', 'ngo'], {
      errorMap: () => ({ message: 'Select an account type' }),
    }),
    agreeTerms: z.literal(true, {
      errorMap: () => ({ message: 'You must agree to the terms to continue' }),
    }),
  })
  .refine((d) => d.password === d.confirmPassword, {
    message: 'Passwords do not match',
    path: ['confirmPassword'],
  });

export type SignUpValues = z.infer<typeof signUpSchema>;

export const loginSchema = z.object({
  email: z.string().email('Enter a valid email address'),
  password: z.string().min(1, 'Enter your password'),
  remember: z.boolean().optional(),
});

export type LoginValues = z.infer<typeof loginSchema>;

export const forgotPasswordSchema = z.object({
  email: z.string().email('Enter a valid email address'),
});

export type ForgotPasswordValues = z.infer<typeof forgotPasswordSchema>;

export const resetPasswordSchema = z
  .object({
    password: z
      .string()
      .min(8, 'Password must be at least 8 characters')
      .regex(/[A-Z]/, 'Add at least one uppercase letter')
      .regex(/[0-9]/, 'Add at least one number'),
    confirmPassword: z.string(),
  })
  .refine((d) => d.password === d.confirmPassword, {
    message: 'Passwords do not match',
    path: ['confirmPassword'],
  });

export type ResetPasswordValues = z.infer<typeof resetPasswordSchema>;

export const donationSchema = z.object({
  food_name: z.string().min(2, 'Food name is required'),
  food_type: z.enum(['veg', 'non-veg', 'vegan']),
  category: z.enum([
    'cooked',
    'raw',
    'packaged',
    'bakery',
    'fruits',
    'vegetables',
    'dairy',
    'beverages',
    'groceries',
    'other',
  ]),
  quantity: z.coerce.number().positive('Quantity must be greater than 0'),
  unit: z.string().min(1, 'Select a unit'),
  description: z.string().max(500, 'Keep the description under 500 characters').optional(),
  prepared_date: z.string().min(1, 'Cooking date is required'),
  expiry_date: z.string().min(1, 'Expiry date is required'),
  pickup_time: z.string().min(1, 'Pickup time is required'),
  pickup_address: z.string().min(5, 'Enter a complete pickup address'),
  city: z.string().min(2, 'City is required').optional().or(z.literal('')),
  phone: z
    .string()
    .min(10, 'Enter a valid phone number')
    .regex(/^[0-9+\-\s]+$/, 'Phone can only contain digits, +, - and spaces'),
  special_instructions: z.string().max(300).optional(),
});

export type DonationValues = z.infer<typeof donationSchema>;

export const profileSchema = z.object({
  full_name: z.string().min(2, 'Full name is required'),
  phone: z
    .string()
    .min(10, 'Enter a valid phone number')
    .regex(/^[0-9+\-\s]+$/, 'Phone can only contain digits, +, - and spaces')
    .optional()
    .or(z.literal('')),
  address: z.string().optional().or(z.literal('')),
  city: z.string().optional().or(z.literal('')),
  district: z.string().optional().or(z.literal('')),
  state: z.string().optional().or(z.literal('')),
  country: z.string().optional().or(z.literal('')),
});

export type ProfileValues = z.infer<typeof profileSchema>;

export const reportSchema = z.object({
  type: z.enum(['fake', 'expired', 'spam', 'abuse', 'unsafe']),
  reason: z.string().min(10, 'Please describe the issue (min 10 characters)'),
});

export type ReportValues = z.infer<typeof reportSchema>;

export const reviewSchema = z.object({
  rating: z.number().min(1, 'Select a rating').max(5),
  comment: z.string().max(500, 'Keep the comment under 500 characters').optional(),
});

export type ReviewValues = z.infer<typeof reviewSchema>;

export const contactSchema = z.object({
  name: z.string().min(2, 'Enter your name'),
  email: z.string().email('Enter a valid email'),
  subject: z.string().min(3, 'Enter a subject'),
  message: z.string().min(10, 'Message must be at least 10 characters'),
});

export type ContactValues = z.infer<typeof contactSchema>;
