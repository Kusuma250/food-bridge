import { lazy, Suspense } from 'react';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import { AuthProvider } from '@/contexts/auth-context';
import { ThemeProvider } from '@/contexts/theme-context';
import { QueryProvider } from '@/contexts/query-context';
import { ErrorBoundary } from '@/components/shared/error-boundary';
import { Toaster } from '@/components/shared/toaster';
import { PageLoader } from '@/components/shared/loading';
import { PublicLayout } from '@/components/layouts/public-layout';
import { ProtectedRoute } from '@/components/shared/protected-route';

const Home = lazy(() => import('@/pages/home'));
const About = lazy(() => import('@/pages/about'));
const Contact = lazy(() => import('@/pages/contact'));
const NotFound = lazy(() => import('@/pages/not-found'));
const Unauthorized = lazy(() => import('@/pages/unauthorized'));
const Suspended = lazy(() => import('@/pages/suspended'));

const Login = lazy(() => import('@/pages/auth/login'));
const Signup = lazy(() => import('@/pages/auth/signup'));
const ForgotPassword = lazy(() => import('@/pages/auth/forgot-password'));
const ResetPassword = lazy(() => import('@/pages/auth/reset-password'));
const VerifyEmail = lazy(() => import('@/pages/auth/verify-email'));

const DonorLayout = lazy(() => import('@/pages/donor/donor-layout'));
const DonorDashboard = lazy(() => import('@/pages/donor/dashboard'));
const AddDonation = lazy(() => import('@/pages/donor/add-donation'));
const MyDonations = lazy(() => import('@/pages/donor/my-donations'));
const DonorAnalytics = lazy(() => import('@/pages/donor/analytics'));
const DonationDetails = lazy(() => import('@/pages/donor/donation-details'));

const ReceiverLayout = lazy(() => import('@/pages/receiver/receiver-layout'));
const ReceiverDashboard = lazy(() => import('@/pages/receiver/dashboard'));
const AvailableDonations = lazy(() => import('@/pages/receiver/available-donations'));
const AvailableDetails = lazy(() => import('@/pages/receiver/available-details'));
const AcceptedDonations = lazy(() => import('@/pages/receiver/accepted-donations'));

const AdminLayout = lazy(() => import('@/pages/admin/admin-layout'));
const AdminDashboard = lazy(() => import('@/pages/admin/dashboard'));
const AdminUsers = lazy(() => import('@/pages/admin/users'));
const AdminDonations = lazy(() => import('@/pages/admin/donations'));
const AdminReports = lazy(() => import('@/pages/admin/reports'));
const AdminAnalytics = lazy(() => import('@/pages/admin/analytics'));
const AdminSettings = lazy(() => import('@/pages/admin/settings'));

const Profile = lazy(() => import('@/pages/profile'));
const Settings = lazy(() => import('@/pages/settings'));
const Notifications = lazy(() => import('@/pages/notifications'));

const withSuspense = (el: React.ReactNode) => <Suspense fallback={<PageLoader />}>{el}</Suspense>;

const router = createBrowserRouter([
  {
    element: <PublicLayout />,
    errorElement: withSuspense(<ErrorBoundaryWrapper />),
    children: [
      { index: true, element: withSuspense(<Home />) },
      { path: 'about', element: withSuspense(<About />) },
      { path: 'contact', element: withSuspense(<Contact />) },
      { path: 'login', element: withSuspense(<Login />) },
      { path: 'signup', element: withSuspense(<Signup />) },
      { path: 'forgot-password', element: withSuspense(<ForgotPassword />) },
      { path: 'reset-password', element: withSuspense(<ResetPassword />) },
      { path: 'verify-email', element: withSuspense(<VerifyEmail />) },
      { path: 'unauthorized', element: withSuspense(<Unauthorized />) },
      { path: 'suspended', element: withSuspense(<Suspended />) },
    ],
  },
  {
    path: 'dashboard/donor',
    element: withSuspense(
      <ProtectedRoute roles={['donor']}>
        <DonorLayout />
      </ProtectedRoute>
    ),
    children: [
      { index: true, element: withSuspense(<DonorDashboard />) },
      { path: 'add-donation', element: withSuspense(<AddDonation />) },
      { path: 'my-donations', element: withSuspense(<MyDonations />) },
      { path: 'my-donations/:id', element: withSuspense(<DonationDetails />) },
      { path: 'analytics', element: withSuspense(<DonorAnalytics />) },
      { path: 'profile', element: withSuspense(<Profile />) },
      { path: 'settings', element: withSuspense(<Settings />) },
      { path: 'notifications', element: withSuspense(<Notifications />) },
    ],
  },
  {
    path: 'dashboard/ngo',
    element: withSuspense(
      <ProtectedRoute roles={['ngo']}>
        <ReceiverLayout />
      </ProtectedRoute>
    ),
    children: [
      { index: true, element: withSuspense(<ReceiverDashboard />) },
      { path: 'available', element: withSuspense(<AvailableDonations />) },
      { path: 'available/:id', element: withSuspense(<AvailableDetails />) },
      { path: 'accepted', element: withSuspense(<AcceptedDonations />) },
      { path: 'profile', element: withSuspense(<Profile />) },
      { path: 'settings', element: withSuspense(<Settings />) },
      { path: 'notifications', element: withSuspense(<Notifications />) },
    ],
  },
  {
    path: 'admin',
    element: withSuspense(
      <ProtectedRoute roles={['admin']}>
        <AdminLayout />
      </ProtectedRoute>
    ),
    children: [
      { index: true, element: withSuspense(<AdminDashboard />) },
      { path: 'users', element: withSuspense(<AdminUsers />) },
      { path: 'donations', element: withSuspense(<AdminDonations />) },
      { path: 'reports', element: withSuspense(<AdminReports />) },
      { path: 'analytics', element: withSuspense(<AdminAnalytics />) },
      { path: 'settings', element: withSuspense(<AdminSettings />) },
      { path: 'profile', element: withSuspense(<Profile />) },
      { path: 'notifications', element: withSuspense(<Notifications />) },
    ],
  },
  { path: '*', element: withSuspense(<NotFound />) },
]);

function ErrorBoundaryWrapper() {
  return (
    <ErrorBoundary>
      <NotFound />
    </ErrorBoundary>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <QueryProvider>
          <ErrorBoundary>
            <RouterProvider router={router} />
            <Toaster />
          </ErrorBoundary>
        </QueryProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}
