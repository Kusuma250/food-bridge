import { supabase, FOOD_IMAGES_BUCKET } from './supabase';
import type {
  AcceptedDonation,
  FoodDonation,
  Notification,
  Profile,
  Review,
  Report,
  DonationStatus,
  DeliveryStatus,
  ReportType,
  FoodCategory,
  FoodType,
} from '@/types';

/* ---------- Profiles ---------- */

export async function fetchProfile(id: string) {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', id)
    .maybeSingle();
  if (error) throw error;
  return data as Profile | null;
}

export async function updateProfile(
  id: string,
  updates: Partial<Pick<
    Profile,
    'full_name' | 'phone' | 'avatar' | 'address' | 'city' | 'district' | 'state' | 'country'
  >>
) {
  const { data, error } = await supabase
    .from('profiles')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data as Profile;
}

/* ---------- Donations ---------- */

export interface DonationFilters {
  search?: string;
  status?: DonationStatus | 'all';
  category?: FoodCategory | 'all';
  foodType?: FoodType | 'all';
}

export async function fetchDonations(filters: DonationFilters = {}) {
  let query = supabase
    .from('food_donations')
    .select('*, donor:profiles!donor_id(*)', { count: 'exact' })
    .order('created_at', { ascending: false });

  if (filters.status && filters.status !== 'all') {
    query = query.eq('status', filters.status);
  }
  if (filters.category && filters.category !== 'all') {
    query = query.eq('category', filters.category);
  }
  if (filters.foodType && filters.foodType !== 'all') {
    query = query.eq('food_type', filters.foodType);
  }
  if (filters.search) {
    query = query.or(`food_name.ilike.%${filters.search}%,description.ilike.%${filters.search}%,pickup_address.ilike.%${filters.search}%`);
  }

  const { data, error, count } = await query;
  if (error) throw error;
  return { data: (data as FoodDonation[]) ?? [], count: count ?? 0 };
}

export async function fetchDonationById(id: string) {
  const { data, error } = await supabase
    .from('food_donations')
    .select('*, donor:profiles!donor_id(*), accepted:accepted_donations(*, receiver:profiles!receiver_id(*))')
    .eq('id', id)
    .maybeSingle();
  if (error) throw error;
  return data as FoodDonation | null;
}

export async function fetchMyDonations(donorId: string, filters: DonationFilters = {}) {
  let query = supabase
    .from('food_donations')
    .select('*, accepted:accepted_donations(receiver:profiles!receiver_id(*))')
    .eq('donor_id', donorId)
    .order('created_at', { ascending: false });

  if (filters.status && filters.status !== 'all') {
    query = query.eq('status', filters.status);
  }
  if (filters.search) {
    query = query.or(`food_name.ilike.%${filters.search}%,pickup_address.ilike.%${filters.search}%`);
  }

  const { data, error } = await query;
  if (error) throw error;
  return (data as FoodDonation[]) ?? [];
}

export async function createDonation(input: Omit<FoodDonation, 'id' | 'donor_id' | 'status' | 'created_at' | 'updated_at'>) {
  const { data, error } = await supabase
    .from('food_donations')
    .insert(input)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data as FoodDonation;
}

export async function updateDonation(id: string, updates: Partial<FoodDonation>) {
  const { data, error } = await supabase
    .from('food_donations')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data as FoodDonation;
}

export async function deleteDonation(id: string) {
  const { error } = await supabase.from('food_donations').delete().eq('id', id);
  if (error) throw error;
}

/* ---------- Available donations (receiver view) ---------- */

export async function fetchAvailableDonations(filters: DonationFilters = {}) {
  let query = supabase
    .from('food_donations')
    .select('*, donor:profiles!donor_id(*)')
    .eq('status', 'pending')
    .order('created_at', { ascending: false });

  if (filters.category && filters.category !== 'all') {
    query = query.eq('category', filters.category);
  }
  if (filters.foodType && filters.foodType !== 'all') {
    query = query.eq('food_type', filters.foodType);
  }
  if (filters.search) {
    query = query.or(`food_name.ilike.%${filters.search}%,pickup_address.ilike.%${filters.search}%`);
  }

  const { data, error } = await query;
  if (error) throw error;
  return (data as FoodDonation[]) ?? [];
}

/* ---------- Accepted donations ---------- */

export async function acceptDonation(donationId: string, receiverId: string) {
  // Use the RPC to atomically accept (creates accepted_donations row, updates status, notifies).
  const { data, error } = await supabase.rpc('accept_donation', {
    p_donation_id: donationId,
    p_receiver_id: receiverId,
  });
  if (error) throw error;
  return data as AcceptedDonation;
}

export async function fetchAcceptedByReceiver(receiverId: string) {
  const { data, error } = await supabase
    .from('accepted_donations')
    .select('*, donation:food_donations(*, donor:profiles!donor_id(*))')
    .eq('receiver_id', receiverId)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data as AcceptedDonation[]) ?? [];
}

export async function fetchAcceptedByDonor(donorId: string) {
  const { data, error } = await supabase
    .from('accepted_donations')
    .select('*, donation:food_donations!inner(*), receiver:profiles!receiver_id(*)')
    .eq('donation.donor_id', donorId)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data as AcceptedDonation[]) ?? [];
}

export async function updateDeliveryStatus(acceptedId: string, status: DeliveryStatus) {
  const { data, error } = await supabase
    .from('accepted_donations')
    .update({ delivery_status: status })
    .eq('id', acceptedId)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data as AcceptedDonation;
}

/* ---------- Notifications ---------- */

export async function fetchNotifications(userId: string) {
  const { data, error } = await supabase
    .from('notifications')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data as Notification[]) ?? [];
}

export async function markNotificationRead(id: string) {
  const { error } = await supabase.from('notifications').update({ is_read: true }).eq('id', id);
  if (error) throw error;
}

export async function markAllNotificationsRead(userId: string) {
  const { error } = await supabase
    .from('notifications')
    .update({ is_read: true })
    .eq('user_id', userId)
    .eq('is_read', false);
  if (error) throw error;
}

export async function deleteNotification(id: string) {
  const { error } = await supabase.from('notifications').delete().eq('id', id);
  if (error) throw error;
}

/* ---------- Reviews ---------- */

export async function fetchReviewsForDonation(donationId: string) {
  const { data, error } = await supabase
    .from('reviews')
    .select('*, reviewer:profiles!reviewer_id(*)')
    .eq('donation_id', donationId)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data as Review[]) ?? [];
}

export async function createReview(input: {
  donation_id: string;
  reviewee_id: string;
  rating: number;
  comment?: string;
}) {
  const { data, error } = await supabase
    .from('reviews')
    .insert(input)
    .select('*, reviewer:profiles!reviewer_id(*)')
    .maybeSingle();
  if (error) throw error;
  return data as Review;
}

/* ---------- Reports ---------- */

export async function createReport(input: {
  donation_id: string | null;
  type: ReportType;
  reason: string;
}) {
  const { data, error } = await supabase.from('reports').insert(input).select().maybeSingle();
  if (error) throw error;
  return data as Report;
}

export async function fetchReports() {
  const { data, error } = await supabase
    .from('reports')
    .select('*, donation:food_donations(*), reporter:profiles!reporter_id(*)')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data as Report[]) ?? [];
}

export async function updateReportStatus(id: string, status: Report['status']) {
  const { data, error } = await supabase
    .from('reports')
    .update({ status })
    .eq('id', id)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data as Report;
}

/* ---------- Admin ---------- */

export async function fetchAllProfiles(filters: { search?: string; role?: Profile['role'] | 'all' } = {}) {
  let query = supabase.from('profiles').select('*', { count: 'exact' }).order('created_at', { ascending: false });
  if (filters.role && filters.role !== 'all') query = query.eq('role', filters.role);
  if (filters.search) query = query.or(`full_name.ilike.%${filters.search}%,email.ilike.%${filters.search}%`);
  const { data, error, count } = await query;
  if (error) throw error;
  return { data: (data as Profile[]) ?? [], count: count ?? 0 };
}

export async function setProfileSuspended(id: string, suspended: boolean) {
  const { data, error } = await supabase
    .from('profiles')
    .update({ is_suspended: suspended })
    .eq('id', id)
    .select()
    .maybeSingle();
  if (error) throw error;
  return data as Profile;
}

export async function adminUpdateDonationStatus(id: string, status: DonationStatus) {
  return updateDonation(id, { status });
}

/* ---------- Storage ---------- */

export async function uploadFoodImage(file: File, donationId: string) {
  const ext = file.name.split('.').pop();
  const path = `${donationId}/${Date.now()}.${ext}`;
  const { error } = await supabase.storage.from(FOOD_IMAGES_BUCKET).upload(path, file, {
    cacheControl: '3600',
    upsert: true,
  });
  if (error) throw error;
  const { data } = supabase.storage.from(FOOD_IMAGES_BUCKET).getPublicUrl(path);
  return data.publicUrl;
}

export async function uploadAvatar(file: File, userId: string) {
  const ext = file.name.split('.').pop();
  const path = `${userId}/avatar.${ext}`;
  const { error } = await supabase.storage.from('avatars').upload(path, file, {
    cacheControl: '3600',
    upsert: true,
  });
  if (error) throw error;
  const { data } = supabase.storage.from('avatars').getPublicUrl(path);
  return data.publicUrl;
}

export async function deleteStorageObject(bucket: string, path: string) {
  const { error } = await supabase.storage.from(bucket).remove([path]);
  if (error) throw error;
}

/* ---------- Analytics helpers ---------- */

export async function fetchDonationStats(donorId: string) {
  const { data, error } = await supabase
    .from('food_donations')
    .select('status, quantity')
    .eq('donor_id', donorId);
  if (error) throw error;
  const rows = data ?? [];
  return {
    total: rows.length,
    pending: rows.filter((r) => r.status === 'pending').length,
    accepted: rows.filter((r) => r.status === 'accepted').length,
    delivered: rows.filter((r) => r.status === 'delivered').length,
    mealsSaved: rows
      .filter((r) => r.status === 'delivered')
      .reduce((sum, r) => sum + Number(r.quantity), 0),
  };
}

export async function fetchAdminStats() {
  const [profiles, donations, accepted, reports] = await Promise.all([
    supabase.from('profiles').select('role'),
    supabase.from('food_donations').select('status, quantity, created_at'),
    supabase.from('accepted_donations').select('id, delivery_status'),
    supabase.from('reports').select('id, status'),
  ]);

  if (profiles.error) throw profiles.error;
  if (donations.error) throw donations.error;

  const profileRows = profiles.data ?? [];
  const donationRows = donations.data ?? [];
  const acceptedRows = accepted.data ?? [];
  const reportRows = reports.data ?? [];

  return {
    totalUsers: profileRows.length,
    totalDonors: profileRows.filter((p) => p.role === 'donor').length,
    totalNgos: profileRows.filter((p) => p.role === 'ngo').length,
    totalDonations: donationRows.length,
    pendingDonations: donationRows.filter((d) => d.status === 'pending').length,
    acceptedDonations: acceptedRows.length,
    deliveredDonations: acceptedRows.filter((a) => a.delivery_status === 'delivered').length,
    cancelledDonations: donationRows.filter((d) => d.status === 'cancelled').length,
    mealsSaved: donationRows
      .filter((d) => d.status === 'delivered')
      .reduce((sum, d) => sum + Number(d.quantity), 0),
    openReports: reportRows.filter((r) => r.status === 'open').length,
    weeklyDonations: groupByWeek(donationRows),
  };
}

function groupByWeek(rows: { created_at: string }[]): { week: string; count: number }[] {
  const weeks: Record<string, number> = {};
  const now = new Date();
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(now.getDate() - i * 7);
    const key = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    weeks[key] = 0;
  }
  rows.forEach((r) => {
    const d = new Date(r.created_at);
    const daysAgo = Math.floor((now.getTime() - d.getTime()) / 86400000);
    const weekIndex = 5 - Math.floor(daysAgo / 7);
    if (weekIndex >= 0 && weekIndex <= 5) {
      const key = Object.keys(weeks)[weekIndex];
      if (key) weeks[key]++;
    }
  });
  return Object.entries(weeks).map(([week, count]) => ({ week, count }));
}
