import type { FoodCategory, FoodType } from '@/types';

interface AIResponse {
  shelfLife: string;
  storageTips: string[];
  safetyTips: string[];
  bestPickupTime: string;
  estimatedMeals: number;
}

/**
 * Rule-based food assistant. Emulates AI recommendations using food-safety
 * heuristics — no external API key required, works fully offline.
 */
export function getFoodAssistant(input: {
  category: FoodCategory;
  foodType: FoodType;
  quantity: number;
  unit: string;
  expiryHours?: number;
}): AIResponse {
  const { category, foodType, quantity, unit } = input;

  const shelfLifeMap: Record<FoodCategory, string> = {
    cooked: '2–4 hours at room temperature, up to 3 days refrigerated',
    raw: '1–2 days refrigerated; freeze for up to 3 months',
    packaged: 'Check best-before label; typically weeks to months unopened',
    bakery: '1–2 days at room temperature; 1 week refrigerated',
    fruits: '2–7 days at room temperature; up to 2 weeks refrigerated',
    vegetables: '3–7 days refrigerated',
    dairy: 'Refrigerate continuously; consume within 2–5 days after opening',
    beverages: 'Unopened per label; refrigerate 2–4 days after opening',
    groceries: 'Months when stored dry and cool',
    other: 'Use best judgment and check the label',
  };

  const storageMap: Record<FoodCategory, string[]> = {
    cooked: ['Cool within 2 hours of cooking', 'Store in airtight containers', 'Reheat once only above 75°C'],
    raw: ['Keep below 4°C', 'Store on the lowest shelf to avoid drips', 'Separate from ready-to-eat food'],
    packaged: ['Keep sealed until donation', 'Store in a cool dry place', 'Avoid direct sunlight'],
    bakery: ['Avoid humidity to prevent mould', 'Use paper bags for bread', 'Freeze if donating next day'],
    fruits: ['Keep ethylene producers (bananas) away from others', 'Refrigerate ripe fruit', 'Sort out bruised pieces'],
    vegetables: ['Remove rubber bands', 'Store leafy greens with a damp cloth', 'Keep root vegetables dark'],
    dairy: ['Maintain cold chain continuously', 'Keep in main fridge, not the door', 'Do not refreeze thawed dairy'],
    beverages: ['Keep sealed', 'Refrigerate after opening', 'Avoid temperature swings'],
    groceries: ['Dry, cool, pest-free storage', 'Rotate stock (first in, first out)', 'Keep packaging intact'],
    other: ['Follow any label instructions', 'Keep separate from chemicals', 'Store hygienically'],
  };

  const safetyMap: Record<FoodType, string[]> = {
    veg: ['Confirm no cross-contact with non-veg utensils', 'Label allergens if applicable'],
    'non-veg': ['Keep cold chain intact', 'Discard if smell or colour changes', 'Never donate reheated twice'],
    vegan: ['Confirm no animal-derived ingredients', 'Use dedicated utensils'],
  };

  const mealsPerUnit: Record<string, number> = {
    kg: 4,
    g: 0.004,
    litres: 4,
    ml: 0.004,
    packets: 2,
    boxes: 4,
    trays: 3,
    portions: 1,
    pieces: 1,
  };
  const estimatedMeals = Math.max(1, Math.round(quantity * (mealsPerUnit[unit] ?? 1)));

  const expiryHours = input.expiryHours ?? 0;
  const bestPickupTime =
    expiryHours > 0 && expiryHours < 4
      ? 'Within the next 2 hours — food is highly perishable'
      : expiryHours < 12
        ? 'Within 6 hours to stay safe'
        : 'Schedule within 24 hours for best quality';

  return {
    shelfLife: shelfLifeMap[category],
    storageTips: storageMap[category],
    safetyTips: safetyMap[foodType],
    bestPickupTime,
    estimatedMeals,
  };
}

export interface AIRecommendationCard {
  icon: string;
  title: string;
  body: string;
  tone: 'info' | 'success' | 'warning';
}

export function getRecommendationCards(input: {
  category: FoodCategory;
  foodType: FoodType;
  expiryHours?: number;
}): AIRecommendationCard[] {
  const a = getFoodAssistant({ ...input, quantity: 1, unit: 'kg' });
  const cards: AIRecommendationCard[] = [
    { icon: 'Clock', title: 'Shelf Life', body: a.shelfLife, tone: 'info' },
    { icon: 'Snowflake', title: 'Storage Tips', body: a.storageTips[0], tone: 'info' },
    { icon: 'ShieldCheck', title: 'Food Safety', body: a.safetyTips[0], tone: 'success' },
    { icon: 'Truck', title: 'Best Pickup Time', body: a.bestPickupTime, tone: 'warning' },
  ];
  if (input.expiryHours !== undefined && input.expiryHours < 4) {
    cards.push({
      icon: 'AlertTriangle',
      title: 'Expiry Alert',
      body: 'This food expires soon — prioritise immediate pickup and collection.',
      tone: 'warning',
    });
  }
  return cards;
}
