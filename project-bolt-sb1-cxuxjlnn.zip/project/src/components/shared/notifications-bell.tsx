import { Link } from 'react-router-dom';
import { Bell, CheckCheck, Trash2, Inbox } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useNotifications } from '@/hooks/use-notifications';
import { useAuth } from '@/contexts/auth-context';
import { timeAgo, cn } from '@/lib/utils';

export function NotificationsBell() {
  const { user } = useAuth();
  const { notifications, unreadCount, markRead, markAllRead, remove } = useNotifications();

  if (!user) return null;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          aria-label={`Notifications${unreadCount ? ` (${unreadCount} unread)` : ''}`}
          className="relative inline-flex h-9 w-9 items-center justify-center rounded-lg border border-border bg-background text-foreground transition-colors hover:bg-accent/10 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          <Bell className="h-[18px] w-[18px]" />
          {unreadCount > 0 && (
            <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-accent px-1 text-[10px] font-bold text-white">
              {unreadCount > 9 ? '9+' : unreadCount}
            </span>
          )}
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80 p-0 sm:w-96">
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <p className="font-bold">Notifications</p>
          {unreadCount > 0 && (
            <Button variant="ghost" size="sm" onClick={markAllRead} className="h-7 gap-1.5 text-xs">
              <CheckCheck className="h-3.5 w-3.5" /> Mark all read
            </Button>
          )}
        </div>
        <ScrollArea className="h-80">
          {notifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center gap-2 px-4 py-10 text-center">
              <Inbox className="h-8 w-8 text-muted-foreground" />
              <p className="text-sm text-muted-foreground">No notifications yet</p>
            </div>
          ) : (
            <ul className="divide-y divide-border">
              {notifications.map((n) => (
                <li
                  key={n.id}
                  className={cn(
                    'group relative px-4 py-3 transition-colors hover:bg-muted/40',
                    !n.is_read && 'bg-primary/5'
                  )}
                >
                  {n.link ? (
                    <Link to={n.link} onClick={() => markRead(n.id)} className="block">
                      <NotificationBody n={n} />
                    </Link>
                  ) : (
                    <NotificationBody n={n} />
                  )}
                  <div className="mt-2 flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">{timeAgo(n.created_at)}</span>
                    <div className="flex items-center gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                      {!n.is_read && (
                        <button
                          onClick={() => markRead(n.id)}
                          className="rounded p-1 text-xs text-primary hover:bg-primary/10"
                          aria-label="Mark as read"
                        >
                          <CheckCheck className="h-3.5 w-3.5" />
                        </button>
                      )}
                      <button
                        onClick={() => remove(n.id)}
                        className="rounded p-1 text-xs text-destructive hover:bg-destructive/10"
                        aria-label="Delete notification"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </ScrollArea>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function NotificationBody({ n }: { n: { title: string; message: string; is_read: boolean } }) {
  return (
    <div className="flex gap-2.5">
      {!n.is_read && <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-accent" />}
      <div className={cn('min-w-0', n.is_read && 'pl-4.5')}>
        <p className="text-sm font-semibold leading-tight">{n.title}</p>
        <p className="mt-0.5 text-xs text-muted-foreground line-clamp-2">{n.message}</p>
      </div>
    </div>
  );
}
