import { MapPin, Clock, Calendar, Package, Phone, FileText } from 'lucide-react';
import type { FoodDonation } from '@/types';
import { FOOD_CATEGORIES, FOOD_TYPES } from '@/types';
import { FreshnessBadge } from './freshness-badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card } from '@/components/ui/card';
import { formatDate, formatDateTime, initials } from '@/lib/utils';

export function DonationInfo({ donation }: { donation: FoodDonation }) {
  const categoryLabel = FOOD_CATEGORIES.find((c) => c.value === donation.category)?.label ?? donation.category;
  const typeLabel = FOOD_TYPES.find((t) => t.value === donation.food_type)?.label ?? donation.food_type;

  return (
    <div className="grid gap-6 lg:grid-cols-3">
      <Card className="p-6 shadow-soft lg:col-span-2">
        <h3 className="font-bold">Food Information</h3>
        <dl className="mt-4 grid gap-x-6 gap-y-4 sm:grid-cols-2">
          <InfoRow icon={<Package className="h-4 w-4" />} label="Quantity" value={`${donation.quantity} ${donation.unit}`} />
          <InfoRow icon={<Package className="h-4 w-4" />} label="Category" value={categoryLabel} />
          <InfoRow icon={<Package className="h-4 w-4" />} label="Food type" value={typeLabel} />
          <InfoRow icon={<Calendar className="h-4 w-4" />} label="Prepared" value={formatDate(donation.prepared_date)} />
          <InfoRow icon={<Clock className="h-4 w-4" />} label="Pickup time" value={donation.pickup_time ?? 'Flexible'} />
          <div className="flex items-start gap-3">
            <Clock className="mt-0.5 h-4 w-4 text-primary" />
            <div>
              <dt className="text-xs text-muted-foreground">Expiry</dt>
              <dd className="text-sm font-medium">{formatDateTime(donation.expiry_date)}</dd>
              <div className="mt-1"><FreshnessBadge expiry={donation.expiry_date} /></div>
            </div>
          </div>
        </dl>

        {donation.description && (
          <div className="mt-5 border-t border-border pt-4">
            <p className="flex items-center gap-2 text-sm font-semibold"><FileText className="h-4 w-4 text-primary" /> Description</p>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{donation.description}</p>
          </div>
        )}
        {donation.special_instructions && (
          <div className="mt-4">
            <p className="flex items-center gap-2 text-sm font-semibold"><FileText className="h-4 w-4 text-primary" /> Special Instructions</p>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{donation.special_instructions}</p>
          </div>
        )}
      </Card>

      <div className="space-y-6">
        {donation.donor && (
          <Card className="p-6 shadow-soft">
            <h3 className="font-bold">Donor</h3>
            <div className="mt-4 flex items-center gap-3">
              <Avatar className="h-12 w-12">
                {donation.donor.avatar && <AvatarImage src={donation.donor.avatar} alt={donation.donor.full_name} />}
                <AvatarFallback className="bg-primary/10 font-bold text-primary">{initials(donation.donor.full_name)}</AvatarFallback>
              </Avatar>
              <div>
                <p className="font-bold">{donation.donor.full_name}</p>
                <p className="text-xs capitalize text-muted-foreground">{donation.donor.role}</p>
              </div>
            </div>
            {donation.phone && (
              <p className="mt-3 flex items-center gap-2 text-sm text-muted-foreground">
                <Phone className="h-4 w-4 text-primary" /> {donation.phone}
              </p>
            )}
          </Card>
        )}

        <Card className="overflow-hidden shadow-soft">
          <div className="p-6">
            <h3 className="font-bold">Pickup Location</h3>
            <p className="mt-2 flex items-start gap-2 text-sm text-muted-foreground">
              <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-primary" /> {donation.pickup_address}
            </p>
          </div>
          <div className="relative flex h-40 items-center justify-center bg-gradient-to-br from-primary/10 to-accent/10">
            <div className="bg-grid absolute inset-0 opacity-10" />
            <div className="relative flex flex-col items-center gap-1 text-center">
              <MapPin className="h-8 w-8 text-primary" />
              <a
                href={`https://maps.google.com/?q=${encodeURIComponent(donation.pickup_address)}`}
                target="_blank"
                rel="noreferrer"
                className="text-sm font-semibold text-primary hover:underline"
              >
                Open in Google Maps
              </a>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}

function InfoRow({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-start gap-3">
      <span className="mt-0.5 text-primary">{icon}</span>
      <div>
        <dt className="text-xs text-muted-foreground">{label}</dt>
        <dd className="text-sm font-medium">{value}</dd>
      </div>
    </div>
  );
}
