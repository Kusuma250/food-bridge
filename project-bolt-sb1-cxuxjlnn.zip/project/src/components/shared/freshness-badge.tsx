import { Sprout, Clock, AlertTriangle } from 'lucide-react';
import { freshness } from '@/lib/utils';
import { cn } from '@/lib/utils';

export function FreshnessBadge({ expiry, className }: { expiry: string | null; className?: string }) {
  const f = freshness(expiry);
  const config = {
    fresh: { icon: Sprout, cls: 'bg-green-100 text-green-700 border-green-200 dark:bg-green-500/15 dark:text-green-300 dark:border-green-500/30' },
    soon: { icon: Clock, cls: 'bg-amber-100 text-amber-700 border-amber-200 dark:bg-amber-500/15 dark:text-amber-300 dark:border-amber-500/30' },
    expired: { icon: AlertTriangle, cls: 'bg-red-100 text-red-700 border-red-200 dark:bg-red-500/15 dark:text-red-300 dark:border-red-500/30' },
  }[f.tone];
  const Icon = config.icon;
  return (
    <span className={cn('inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-semibold', config.cls, className)}>
      <Icon className="h-3.5 w-3.5" />
      {f.label}
    </span>
  );
}
