import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Star, Send } from 'lucide-react';
import { toast } from 'sonner';
import { reviewSchema, type ReviewValues } from '@/lib/validations';
import { createReview, fetchReviewsForDonation } from '@/services/data';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/contexts/auth-context';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card } from '@/components/ui/card';
import { cn, initials, timeAgo } from '@/lib/utils';
import { LoadingSpinner } from '@/components/shared/loading';
import { EmptyState } from '@/components/shared/empty-state';

interface ReviewsSectionProps {
  donationId: string;
  revieweeId: string;
  revieweeName: string;
  canReview: boolean;
}

export function ReviewsSection({ donationId, revieweeId, revieweeName, canReview }: ReviewsSectionProps) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [rating, setRating] = useState(0);
  const [hover, setHover] = useState(0);

  const { data: reviews, isLoading } = useQuery({
    queryKey: ['reviews', donationId],
    queryFn: () => fetchReviewsForDonation(donationId),
  });

  const form = useForm<ReviewValues>({
    resolver: zodResolver(reviewSchema),
    defaultValues: { rating: 0, comment: '' },
  });

  const mutation = useMutation({
    mutationFn: (values: ReviewValues) =>
      createReview({ donation_id: donationId, reviewee_id: revieweeId, rating: values.rating, comment: values.comment }),
    onSuccess: () => {
      toast.success('Review submitted');
      queryClient.invalidateQueries({ queryKey: ['reviews', donationId] });
      form.reset();
      setRating(0);
    },
    onError: (e) => toast.error('Could not submit review', { description: (e as Error).message }),
  });

  const onSubmit = (values: ReviewValues) => {
    if (rating === 0) {
      toast.error('Select a rating');
      return;
    }
    mutation.mutate({ ...values, rating });
  };

  const avg = reviews && reviews.length ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length : 0;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h3 className="font-bold">Reviews</h3>
        {reviews && reviews.length > 0 && (
          <div className="flex items-center gap-1.5 text-sm">
            <Star className="h-4 w-4 fill-accent text-accent" />
            <span className="font-bold">{avg.toFixed(1)}</span>
            <span className="text-muted-foreground">({reviews.length})</span>
          </div>
        )}
      </div>

      {canReview && user && (
        <Card className="p-5 shadow-soft">
          <p className="text-sm font-medium">Rate {revieweeName}</p>
          <form onSubmit={form.handleSubmit(onSubmit)} className="mt-3 space-y-3">
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map((n) => (
                <button
                  key={n}
                  type="button"
                  onMouseEnter={() => setHover(n)}
                  onMouseLeave={() => setHover(0)}
                  onClick={() => { setRating(n); form.setValue('rating', n); }}
                  aria-label={`${n} stars`}
                >
                  <Star
                    className={cn(
                      'h-7 w-7 transition-colors',
                      (hover || rating) >= n ? 'fill-accent text-accent' : 'text-muted-foreground/40'
                    )}
                  />
                </button>
              ))}
            </div>
            <Textarea
              rows={2}
              placeholder="Share your experience (optional)…"
              {...form.register('comment')}
            />
            <Button type="submit" size="sm" disabled={mutation.isPending} className="gradient-primary text-white">
              <Send className="mr-2 h-4 w-4" /> {mutation.isPending ? 'Submitting…' : 'Submit review'}
            </Button>
          </form>
        </Card>
      )}

      {isLoading ? (
        <LoadingSpinner />
      ) : reviews && reviews.length > 0 ? (
        <ul className="space-y-3">
          {reviews.map((r) => (
            <li key={r.id} className="rounded-xl border border-border bg-card p-4 shadow-soft">
              <div className="flex items-center gap-3">
                <Avatar className="h-9 w-9">
                  {r.reviewer?.avatar && <AvatarImage src={r.reviewer.avatar} alt={r.reviewer.full_name} />}
                  <AvatarFallback className="text-xs font-bold">{r.reviewer ? initials(r.reviewer.full_name) : 'U'}</AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <p className="text-sm font-bold">{r.reviewer?.full_name ?? 'Anonymous'}</p>
                  <p className="text-xs text-muted-foreground">{timeAgo(r.created_at)}</p>
                </div>
                <div className="flex gap-0.5">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className={cn('h-3.5 w-3.5', i < r.rating ? 'fill-accent text-accent' : 'text-muted-foreground/30')} />
                  ))}
                </div>
              </div>
              {r.comment && <p className="mt-3 text-sm text-muted-foreground">{r.comment}</p>}
            </li>
          ))}
        </ul>
      ) : (
        <EmptyState icon={<Star className="h-6 w-6" />} title="No reviews yet" description="Reviews appear after a donation is completed." />
      )}
    </div>
  );
}

const reportTypes = [
  { value: 'fake', label: 'Fake donation' },
  { value: 'expired', label: 'Expired food' },
  { value: 'spam', label: 'Spam' },
  { value: 'abuse', label: 'Abuse' },
  { value: 'unsafe', label: 'Unsafe food' },
] as const;

export { reportTypes };
