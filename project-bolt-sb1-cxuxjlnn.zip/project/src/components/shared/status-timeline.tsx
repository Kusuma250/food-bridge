import { motion } from 'framer-motion';
import { CheckCircle2, Circle, XCircle, Truck } from 'lucide-react';
import type { DeliveryStatus } from '@/types';
import { DELIVERY_STATUS_STEPS } from '@/types';
import { cn } from '@/lib/utils';

interface StatusTimelineProps {
  current: DeliveryStatus;
  cancelled?: boolean;
}

export function StatusTimeline({ current, cancelled }: StatusTimelineProps) {
  const currentIndex = DELIVERY_STATUS_STEPS.findIndex((s) => s.value === current);

  return (
    <div className="relative">
      <div className="absolute left-5 top-0 h-full w-0.5 bg-border" />
      <ol className="space-y-5">
        {DELIVERY_STATUS_STEPS.map((step, i) => {
          const done = cancelled ? false : i < currentIndex;
          const active = cancelled ? false : i === currentIndex;
          const Icon = done ? CheckCircle2 : active ? Circle : Circle;
          return (
            <motion.li
              key={step.value}
              initial={{ opacity: 0, x: -12 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.08 }}
              className="relative flex items-center gap-4"
            >
              <span
                className={cn(
                  'relative z-10 flex h-10 w-10 items-center justify-center rounded-full border-2 bg-background',
                  done && 'border-primary bg-primary text-primary-foreground',
                  active && 'border-primary text-primary',
                  !done && !active && 'border-border text-muted-foreground',
                  cancelled && 'border-destructive text-destructive'
                )}
              >
                {cancelled ? <XCircle className="h-5 w-5" /> : <Icon className={cn('h-5 w-5', active && 'animate-pulse')} />}
              </span>
              <div>
                <p className={cn('font-semibold', !done && !active && 'text-muted-foreground')}>{step.label}</p>
                {active && (
                  <p className="text-xs text-primary flex items-center gap-1">
                    <Truck className="h-3 w-3" /> In progress
                  </p>
                )}
              </div>
            </motion.li>
          );
        })}
      </ol>
      {cancelled && (
        <div className="mt-4 flex items-center gap-2 rounded-xl border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive">
          <XCircle className="h-4 w-4" /> This donation was cancelled.
        </div>
      )}
    </div>
  );
}
