import { Link } from 'react-router-dom';
import { UtensilsCrossed } from 'lucide-react';
import { cn } from '@/lib/utils';

export function Logo({ className, showText = true }: { className?: string; showText?: boolean }) {
  return (
    <Link to="/" className={cn('group flex items-center gap-2.5', className)} aria-label="Food Bridge home">
      <span className="relative flex h-9 w-9 items-center justify-center rounded-xl gradient-primary text-white shadow-glow transition-transform group-hover:scale-105">
        <UtensilsCrossed className="h-5 w-5" />
      </span>
      {showText && (
        <span className="text-lg font-extrabold tracking-tight">
          Food<span className="text-primary">Bridge</span>
        </span>
      )}
    </Link>
  );
}
