import { Badge } from '@/components/ui/badge';
import { DONATION_STATUS_META, type DonationStatus } from '@/types';
import { cn } from '@/lib/utils';

export function StatusBadge({ status, className }: { status: DonationStatus; className?: string }) {
  const meta = DONATION_STATUS_META[status];
  return (
    <Badge variant="outline" className={cn('border', meta.border, meta.bg, meta.color, className)}>
      <span className="mr-1.5 inline-block h-1.5 w-1.5 rounded-full bg-current" />
      {meta.label}
    </Badge>
  );
}
