import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { MapPin, Clock, Package, User } from 'lucide-react';
import type { FoodDonation } from '@/types';
import { FreshnessBadge } from './freshness-badge';
import { StatusBadge } from './status-badge';
import { FOOD_TYPES } from '@/types';
import { cn, timeAgo } from '@/lib/utils';

interface DonationCardProps {
  donation: FoodDonation;
  to: string;
  showStatus?: boolean;
  footer?: React.ReactNode;
  index?: number;
}

const foodTypeBadge: Record<string, string> = {
  veg: 'bg-green-100 text-green-700 dark:bg-green-500/15 dark:text-green-300',
  'non-veg': 'bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-300',
  vegan: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300',
};

export function DonationCard({ donation, to, showStatus, footer, index = 0 }: DonationCardProps) {
  const typeLabel = FOOD_TYPES.find((t) => t.value === donation.food_type)?.label ?? donation.food_type;
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: Math.min(index * 0.05, 0.3), ease: [0.16, 1, 0.3, 1] }}
    >
      <Link
        to={to}
        className="group flex h-full flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-soft transition-all hover:-translate-y-1 hover:shadow-glow"
      >
        <div className="relative h-44 overflow-hidden bg-muted">
          {donation.image_url ? (
            <img
              src={donation.image_url}
              alt={donation.food_name}
              loading="lazy"
              className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-primary/15 to-accent/15">
              <Package className="h-10 w-10 text-primary/40" />
            </div>
          )}
          <div className="absolute left-3 top-3 flex gap-2">
            <span className={cn('rounded-full px-2.5 py-0.5 text-xs font-semibold', foodTypeBadge[donation.food_type])}>
              {typeLabel}
            </span>
            <FreshnessBadge expiry={donation.expiry_date} />
          </div>
          {showStatus && (
            <div className="absolute right-3 top-3">
              <StatusBadge status={donation.status} />
            </div>
          )}
        </div>

        <div className="flex flex-1 flex-col gap-3 p-4">
          <div>
            <h3 className="font-bold leading-tight line-clamp-1 group-hover:text-primary">{donation.food_name}</h3>
            <p className="mt-1 text-sm text-muted-foreground line-clamp-2">{donation.description}</p>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground">
            <span className="inline-flex items-center gap-1.5">
              <Package className="h-3.5 w-3.5 text-primary" /> {donation.quantity} {donation.unit}
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Clock className="h-3.5 w-3.5 text-primary" /> {donation.pickup_time ?? 'Flexible'}
            </span>
            <span className="inline-flex items-center gap-1.5 col-span-2 line-clamp-1">
              <MapPin className="h-3.5 w-3.5 text-primary" /> {donation.pickup_address}
            </span>
            {donation.donor && (
              <span className="inline-flex items-center gap-1.5 col-span-2 line-clamp-1">
                <User className="h-3.5 w-3.5 text-primary" /> {donation.donor.full_name}
              </span>
            )}
          </div>

          <div className="mt-auto flex items-center justify-between pt-2">
            <span className="text-xs text-muted-foreground">{timeAgo(donation.created_at)}</span>
            {footer}
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
