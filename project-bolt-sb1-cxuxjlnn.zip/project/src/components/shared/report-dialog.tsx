import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Flag, Send } from 'lucide-react';
import { toast } from 'sonner';
import { reportSchema, type ReportValues } from '@/lib/validations';
import { createReport } from '@/services/data';
import { useMutation } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import type { ReportType } from '@/types';

const types: { value: ReportType; label: string }[] = [
  { value: 'fake', label: 'Fake donation' },
  { value: 'expired', label: 'Expired food' },
  { value: 'spam', label: 'Spam' },
  { value: 'abuse', label: 'Abuse' },
  { value: 'unsafe', label: 'Unsafe food' },
];

export function ReportDialog({ donationId }: { donationId: string }) {
  const [open, setOpen] = useState(false);
  const form = useForm<ReportValues>({
    resolver: zodResolver(reportSchema),
    defaultValues: { type: 'fake', reason: '' },
  });

  const mutation = useMutation({
    mutationFn: (values: ReportValues) =>
      createReport({ donation_id: donationId, type: values.type, reason: values.reason }),
    onSuccess: () => {
      toast.success('Report submitted', { description: 'Our admin team will review it shortly.' });
      form.reset();
      setOpen(false);
    },
    onError: (e) => toast.error('Could not submit report', { description: (e as Error).message }),
  });

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="text-destructive hover:text-destructive">
          <Flag className="mr-2 h-4 w-4" /> Report
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Report this donation</DialogTitle>
          <DialogDescription>
            Help keep Food Bridge safe. Reports are reviewed by our admin team.
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit((v) => mutation.mutate(v))} className="space-y-4">
            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Report type</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                    <SelectContent>
                      {types.map((t) => (
                        <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="reason"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Details</FormLabel>
                  <FormControl>
                    <Textarea rows={4} placeholder="Explain the issue so we can act on it…" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button type="submit" size="sm" disabled={mutation.isPending} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                <Send className="mr-2 h-4 w-4" /> {mutation.isPending ? 'Submitting…' : 'Submit report'}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
