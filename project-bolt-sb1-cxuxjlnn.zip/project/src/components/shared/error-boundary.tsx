import { Component, type ErrorInfo, type ReactNode } from 'react';
import { AlertTriangle, RefreshCw, Home } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Logo } from '@/components/shared/logo';

interface Props {
  children: ReactNode;
}
interface State {
  hasError: boolean;
  error?: Error;
}

export class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('ErrorBoundary caught:', error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex min-h-screen flex-col items-center justify-center gap-6 px-6 text-center">
          <Logo showText={false} />
          <div className="flex h-20 w-20 items-center justify-center rounded-3xl bg-destructive/10 text-destructive">
            <AlertTriangle className="h-9 w-9" />
          </div>
          <div className="max-w-md">
            <h1 className="text-2xl font-extrabold">Something went wrong</h1>
            <p className="mt-2 text-muted-foreground">
              An unexpected error occurred. Try refreshing the page, or head back home.
            </p>
            {this.state.error && (
              <pre className="mt-4 max-h-40 overflow-auto rounded-xl border border-border bg-muted p-4 text-left text-xs text-muted-foreground">
                {this.state.error.message}
              </pre>
            )}
          </div>
          <div className="flex gap-3">
            <Button onClick={() => window.location.reload()} variant="outline">
              <RefreshCw className="mr-2 h-4 w-4" /> Refresh
            </Button>
            <Button asChild className="gradient-primary text-white">
              <Link to="/">
                <Home className="mr-2 h-4 w-4" /> Go home
              </Link>
            </Button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
