import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Search, PlusCircle, Package, ArrowUpDown, Trash2, Eye, ChevronLeft, ChevronRight, LayoutGrid, List } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/auth-context';
import { fetchMyDonations, deleteDonation } from '@/services/data';
import type { DonationStatus, FoodDonation } from '@/types';
import { DonationCard } from '@/components/shared/donation-card';
import { StatusBadge } from '@/components/shared/status-badge';
import { EmptyState } from '@/components/shared/empty-state';
import { ErrorState } from '@/components/shared/error-state';
import { LoadingSpinner, TableSkeleton } from '@/components/shared/loading';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { cn, formatDate, paginate } from '@/lib/utils';

const PAGE_SIZE = 8;
const statusOptions: { value: DonationStatus | 'all'; label: string }[] = [
  { value: 'all', label: 'All statuses' },
  { value: 'pending', label: 'Pending' },
  { value: 'accepted', label: 'Accepted' },
  { value: 'collected', label: 'Collected' },
  { value: 'on_the_way', label: 'On The Way' },
  { value: 'delivered', label: 'Delivered' },
  { value: 'cancelled', label: 'Cancelled' },
];

export default function MyDonations() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState<DonationStatus | 'all'>('all');
  const [sort, setSort] = useState<'newest' | 'oldest'>('newest');
  const [view, setView] = useState<'grid' | 'table'>('grid');
  const [page, setPage] = useState(1);
  const [toDelete, setToDelete] = useState<FoodDonation | null>(null);

  const { data, isLoading, isError, refetch } = useQuery({
    queryKey: ['my-donations', user?.id],
    queryFn: () => fetchMyDonations(user!.id),
    enabled: !!user,
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => deleteDonation(id),
    onSuccess: () => {
      toast.success('Donation deleted');
      queryClient.invalidateQueries({ queryKey: ['my-donations'] });
      queryClient.invalidateQueries({ queryKey: ['donor-stats'] });
    },
    onError: (e) => toast.error('Could not delete', { description: (e as Error).message }),
  });

  const filtered = useMemo(() => {
    let rows = data ?? [];
    if (status !== 'all') rows = rows.filter((d) => d.status === status);
    if (search) {
      const q = search.toLowerCase();
      rows = rows.filter(
        (d) => d.food_name.toLowerCase().includes(q) || d.pickup_address.toLowerCase().includes(q)
      );
    }
    rows = [...rows].sort((a, b) =>
      sort === 'newest'
        ? new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
        : new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
    );
    return rows;
  }, [data, status, search, sort]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const pageRows = paginate(filtered, page, PAGE_SIZE);

  return (
    <div className="space-y-6">
      <div className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h2 className="text-2xl font-extrabold">My Donations</h2>
          <p className="mt-1 text-muted-foreground">{filtered.length} donation{filtered.length !== 1 ? 's' : ''}</p>
        </div>
        <Button asChild className="gradient-primary text-white shadow-glow">
          <Link to="/dashboard/donor/add-donation">
            <PlusCircle className="mr-2 h-4 w-4" /> Add donation
          </Link>
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-3 rounded-2xl border border-border bg-card p-4 shadow-soft sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search by food name or address…"
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            className="pl-9"
          />
        </div>
        <Select value={status} onValueChange={(v) => { setStatus(v as DonationStatus | 'all'); setPage(1); }}>
          <SelectTrigger className="sm:w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            {statusOptions.map((o) => (
              <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={sort} onValueChange={(v) => setSort(v as 'newest' | 'oldest')}>
          <SelectTrigger className="sm:w-36">
            <ArrowUpDown className="mr-2 h-4 w-4" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="newest">Newest</SelectItem>
            <SelectItem value="oldest">Oldest</SelectItem>
          </SelectContent>
        </Select>
        <div className="flex rounded-lg border border-border">
          <button
            onClick={() => setView('grid')}
            className={cn('flex h-9 w-9 items-center justify-center rounded-l-lg', view === 'grid' ? 'bg-primary text-primary-foreground' : 'hover:bg-accent/10')}
            aria-label="Grid view"
          >
            <LayoutGrid className="h-4 w-4" />
          </button>
          <button
            onClick={() => setView('table')}
            className={cn('flex h-9 w-9 items-center justify-center rounded-r-lg border-l border-border', view === 'table' ? 'bg-primary text-primary-foreground' : 'hover:bg-accent/10')}
            aria-label="Table view"
          >
            <List className="h-4 w-4" />
          </button>
        </div>
      </div>

      {isError ? (
        <ErrorState onRetry={refetch} />
      ) : isLoading ? (
        view === 'grid' ? <LoadingSpinner /> : <TableSkeleton />
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={<Package className="h-7 w-7" />}
          title="No donations found"
          description={search || status !== 'all' ? 'Try adjusting your filters.' : 'Create your first donation to get started.'}
          action={
            <Button asChild className="gradient-primary text-white">
              <Link to="/dashboard/donor/add-donation">
                <PlusCircle className="mr-2 h-4 w-4" /> Add donation
              </Link>
            </Button>
          }
        />
      ) : view === 'grid' ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {pageRows.map((d, i) => (
            <DonationCard key={d.id} donation={d} to={`/dashboard/donor/my-donations/${d.id}`} showStatus index={i} />
          ))}
        </div>
      ) : (
        <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-soft">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Food</TableHead>
                <TableHead>Quantity</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Created</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pageRows.map((d) => (
                <TableRow key={d.id}>
                  <TableCell className="font-medium">{d.food_name}</TableCell>
                  <TableCell>{d.quantity} {d.unit}</TableCell>
                  <TableCell><StatusBadge status={d.status} /></TableCell>
                  <TableCell className="text-muted-foreground">{formatDate(d.created_at)}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      <Button asChild size="icon" variant="ghost" className="h-8 w-8">
                        <Link to={`/dashboard/donor/my-donations/${d.id}`}><Eye className="h-4 w-4" /></Link>
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-8 w-8 text-destructive hover:text-destructive"
                        onClick={() => setToDelete(d)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {filtered.length > PAGE_SIZE && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Page {page} of {totalPages}
          </p>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
              <ChevronLeft className="h-4 w-4" /> Prev
            </Button>
            <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>
              Next <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      <AlertDialog open={!!toDelete} onOpenChange={(open) => !open && setToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this donation?</AlertDialogTitle>
            <AlertDialogDescription>
              “{toDelete?.food_name}” will be permanently removed. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => toDelete && deleteMutation.mutate(toDelete.id)}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
