import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { Package, HeartHandshake, CheckCircle2, Clock, PlusCircle, ArrowRight, TrendingUp } from 'lucide-react';
import { useAuth } from '@/contexts/auth-context';
import { fetchDonationStats, fetchMyDonations } from '@/services/data';
import { StatCard } from '@/components/shared/stat-card';
import { DonationCard } from '@/components/shared/donation-card';
import { EmptyState } from '@/components/shared/empty-state';
import { ErrorState } from '@/components/shared/error-state';
import { LoadingSpinner } from '@/components/shared/loading';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';

const CATEGORY_COLORS = ['#16a34a', '#22c55e', '#f97316', '#0ea5e9', '#eab308', '#a855f7', '#ec4899', '#14b8a6', '#f43f5e', '#64748b'];

export default function DonorDashboard() {
  const { user } = useAuth();

  const { data: stats, isLoading: statsLoading, isError: statsError, refetch: refetchStats } = useQuery({
    queryKey: ['donor-stats', user?.id],
    queryFn: () => fetchDonationStats(user!.id),
    enabled: !!user,
  });

  const { data: donations, isLoading: donationsLoading } = useQuery({
    queryKey: ['my-donations-recent', user?.id],
    queryFn: () => fetchMyDonations(user!.id),
    enabled: !!user,
  });

  const recent = (donations ?? []).slice(0, 4);

  const categoryData = (donations ?? []).reduce<Record<string, number>>((acc, d) => {
    acc[d.category] = (acc[d.category] ?? 0) + 1;
    return acc;
  }, {});
  const pieData = Object.entries(categoryData).map(([name, value]) => ({ name, value }));

  // Weekly trend (last 6 weeks)
  const weeklyData = (() => {
    const weeks: { week: string; count: number }[] = [];
    const now = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(now.getDate() - i * 7);
      weeks.push({ week: d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }), count: 0 });
    }
    (donations ?? []).forEach((d) => {
      const daysAgo = Math.floor((now.getTime() - new Date(d.created_at).getTime()) / 86400000);
      const idx = 5 - Math.floor(daysAgo / 7);
      if (idx >= 0 && idx <= 5) weeks[idx].count++;
    });
    return weeks;
  })();

  return (
    <div className="space-y-8">
      {/* Welcome */}
      <div className="flex flex-col items-start justify-between gap-4 rounded-2xl gradient-primary p-6 text-white shadow-glow sm:flex-row sm:items-center">
        <div>
          <h2 className="text-2xl font-extrabold">Welcome back!</h2>
          <p className="mt-1 text-white/80">Here is your donation impact at a glance.</p>
        </div>
        <Button asChild variant="secondary" className="bg-white text-primary hover:bg-white/90">
          <Link to="/dashboard/donor/add-donation">
            <PlusCircle className="mr-2 h-4 w-4" /> New donation
          </Link>
        </Button>
      </div>

      {/* Stats */}
      {statsLoading ? (
        <LoadingSpinner label="Loading your stats…" />
      ) : statsError ? (
        <ErrorState onRetry={refetchStats} />
      ) : stats ? (
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <StatCard icon={<Package className="h-5 w-5" />} label="Total Donations" value={stats.total} tone="primary" delay={0} />
          <StatCard icon={<HeartHandshake className="h-5 w-5" />} label="Meals Saved" value={stats.mealsSaved} tone="accent" delay={0.08} />
          <StatCard icon={<CheckCircle2 className="h-5 w-5" />} label="Accepted" value={stats.accepted} tone="info" delay={0.16} />
          <StatCard icon={<Clock className="h-5 w-5" />} label="Pending" value={stats.pending} tone="warning" delay={0.24} />
        </div>
      ) : null}

      {/* Charts */}
      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="p-5 shadow-soft lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h3 className="font-bold">Weekly Donations</h3>
              <p className="text-xs text-muted-foreground">Donations created over the last 6 weeks</p>
            </div>
            <TrendingUp className="h-5 w-5 text-primary" />
          </div>
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={weeklyData} margin={{ left: -20, right: 8, top: 8 }}>
              <defs>
                <linearGradient id="donationsGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#16a34a" stopOpacity={0.35} />
                  <stop offset="100%" stopColor="#16a34a" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="week" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
              <YAxis allowDecimals={false} tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
              <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))' }} />
              <Area type="monotone" dataKey="count" stroke="#16a34a" strokeWidth={2.5} fill="url(#donationsGradient)" />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-5 shadow-soft">
          <h3 className="font-bold">Category Breakdown</h3>
          <p className="text-xs text-muted-foreground">What you donate most</p>
          {pieData.length === 0 ? (
            <div className="flex h-[220px] items-center justify-center text-sm text-muted-foreground">
              No data yet
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={50} outerRadius={85} paddingAngle={3}>
                  {pieData.map((_, i) => (
                    <Cell key={i} fill={CATEGORY_COLORS[i % CATEGORY_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))' }} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </Card>
      </div>

      {/* Recent donations */}
      <div>
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-lg font-bold">Recent Donations</h3>
          <Button asChild variant="ghost" size="sm">
            <Link to="/dashboard/donor/my-donations">
              View all <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </Button>
        </div>
        {donationsLoading ? (
          <LoadingSpinner />
        ) : recent.length === 0 ? (
          <EmptyState
            icon={<Package className="h-7 w-7" />}
            title="No donations yet"
            description="Create your first donation and start making an impact today."
            action={
              <Button asChild className="gradient-primary text-white">
                <Link to="/dashboard/donor/add-donation">
                  <PlusCircle className="mr-2 h-4 w-4" /> Add donation
                </Link>
              </Button>
            }
          />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {recent.map((d, i) => (
              <DonationCard key={d.id} donation={d} to={`/dashboard/donor/my-donations/${d.id}`} showStatus index={i} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
