import { useQuery } from '@tanstack/react-query';
import { Download, TrendingUp, Package, HeartHandshake, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/auth-context';
import { fetchMyDonations, fetchDonationStats } from '@/services/data';
import { StatCard } from '@/components/shared/stat-card';
import { LoadingSpinner } from '@/components/shared/loading';
import { ErrorState } from '@/components/shared/error-state';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { downloadFile, toCsv, formatDate } from '@/lib/utils';
import {
  BarChart, Bar, PieChart, Pie, Cell, LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from 'recharts';

const COLORS = ['#16a34a', '#22c55e', '#f97316', '#0ea5e9', '#eab308', '#a855f7', '#ec4899', '#14b8a6', '#f43f5e', '#64748b'];

export default function DonorAnalytics() {
  const { user } = useAuth();

  const { data: donations, isLoading, isError, refetch } = useQuery({
    queryKey: ['my-donations-analytics', user?.id],
    queryFn: () => fetchMyDonations(user!.id),
    enabled: !!user,
  });

  const { data: stats } = useQuery({
    queryKey: ['donor-stats', user?.id],
    queryFn: () => fetchDonationStats(user!.id),
    enabled: !!user,
  });

  if (isLoading) return <LoadingSpinner label="Crunching your numbers…" />;
  if (isError) return <ErrorState onRetry={refetch} />;

  const rows = donations ?? [];

  // Monthly trend
  const monthly = (() => {
    const map: Record<string, number> = {};
    const now = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      map[d.toLocaleDateString('en-US', { month: 'short' })] = 0;
    }
    rows.forEach((r) => {
      const d = new Date(r.created_at);
      const key = d.toLocaleDateString('en-US', { month: 'short' });
      if (key in map) map[key]++;
    });
    return Object.entries(map).map(([month, count]) => ({ month, count }));
  })();

  // Category breakdown
  const categoryData = rows.reduce<Record<string, number>>((acc, d) => {
    acc[d.category] = (acc[d.category] ?? 0) + 1;
    return acc;
  }, {});
  const pieData = Object.entries(categoryData).map(([name, value]) => ({ name, value }));

  // Status breakdown
  const statusData = ['pending', 'accepted', 'collected', 'on_the_way', 'delivered', 'cancelled'].map((s) => ({
    status: s.replace('_', ' '),
    count: rows.filter((r) => r.status === s).length,
  }));

  // Daily line (last 14 days)
  const daily = (() => {
    const map: Record<string, number> = {};
    const now = new Date();
    for (let i = 13; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(now.getDate() - i);
      map[d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })] = 0;
    }
    rows.forEach((r) => {
      const d = new Date(r.created_at);
      const key = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
      if (key in map) map[key]++;
    });
    return Object.entries(map).map(([day, count]) => ({ day, count }));
  })();

  const exportCsv = () => {
    const csv = toCsv(rows.map((r) => ({
      food_name: r.food_name,
      category: r.category,
      food_type: r.food_type,
      quantity: r.quantity,
      unit: r.unit,
      status: r.status,
      created_at: formatDate(r.created_at),
    })));
    downloadFile('my-donations.csv', csv, 'text/csv');
    toast.success('Exported CSV');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h2 className="text-2xl font-extrabold">Analytics</h2>
          <p className="mt-1 text-muted-foreground">Understand your donation patterns and impact.</p>
        </div>
        <Button variant="outline" onClick={exportCsv}>
          <Download className="mr-2 h-4 w-4" /> Export CSV
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard icon={<Package className="h-5 w-5" />} label="Total" value={stats?.total ?? 0} tone="primary" />
        <StatCard icon={<HeartHandshake className="h-5 w-5" />} label="Meals Saved" value={stats?.mealsSaved ?? 0} tone="accent" />
        <StatCard icon={<CheckCircle2 className="h-5 w-5" />} label="Delivered" value={stats?.delivered ?? 0} tone="success" />
        <StatCard icon={<TrendingUp className="h-5 w-5" />} label="Pending" value={stats?.pending ?? 0} tone="warning" />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="p-5 shadow-soft">
          <h3 className="font-bold">Monthly Donations</h3>
          <p className="text-xs text-muted-foreground">Last 6 months</p>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={monthly} margin={{ left: -20, top: 12 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
              <YAxis allowDecimals={false} tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
              <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))' }} />
              <Bar dataKey="count" fill="#16a34a" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-5 shadow-soft">
          <h3 className="font-bold">Category Analysis</h3>
          <p className="text-xs text-muted-foreground">What you donate</p>
          {pieData.length === 0 ? (
            <div className="flex h-[240px] items-center justify-center text-sm text-muted-foreground">No data yet</div>
          ) : (
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={95} label>
                  {pieData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))' }} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="p-5 shadow-soft">
          <h3 className="font-bold">Donation Trend</h3>
          <p className="text-xs text-muted-foreground">Last 14 days</p>
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={daily} margin={{ left: -20, top: 12 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="day" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
              <YAxis allowDecimals={false} tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
              <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))' }} />
              <Line type="monotone" dataKey="count" stroke="#f97316" strokeWidth={2.5} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-5 shadow-soft">
          <h3 className="font-bold">Status Breakdown</h3>
          <p className="text-xs text-muted-foreground">Where your donations stand</p>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={statusData} layout="vertical" margin={{ left: 20, top: 12 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" horizontal={false} />
              <XAxis type="number" allowDecimals={false} tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
              <YAxis type="category" dataKey="status" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" width={90} />
              <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))' }} />
              <Bar dataKey="count" fill="#22c55e" radius={[0, 8, 8, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>
    </div>
  );
}
