import { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { ArrowLeft, Edit2, Trash2, XCircle, MapPin, Phone, User } from 'lucide-react';
import { toast } from 'sonner';
import { fetchDonationById, updateDonation, deleteDonation, fetchAcceptedByDonor } from '@/services/data';
import { useAuth } from '@/contexts/auth-context';
import { PageLoader } from '@/components/shared/loading';
import { ErrorState } from '@/components/shared/error-state';
import { StatusBadge } from '@/components/shared/status-badge';
import { StatusTimeline } from '@/components/shared/status-timeline';
import { DonationInfo } from '@/components/shared/donation-info';
import { ReviewsSection } from '@/components/shared/reviews-section';
import { ReportDialog } from '@/components/shared/report-dialog';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { formatDate, initials } from '@/lib/utils';

export default function DonationDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [confirmDelete, setConfirmDelete] = useState(false);

  const { data: donation, isLoading, isError, refetch } = useQuery({
    queryKey: ['donation', id],
    queryFn: () => fetchDonationById(id!),
    enabled: !!id,
  });

  const { data: accepted } = useQuery({
    queryKey: ['accepted-by-donor', user?.id],
    queryFn: () => fetchAcceptedByDonor(user!.id),
    enabled: !!user && !!donation,
  });

  const thisAccepted = accepted?.find((a) => a.donation_id === id);

  const cancelMutation = useMutation({
    mutationFn: () => updateDonation(id!, { status: 'cancelled' }),
    onSuccess: () => {
      toast.success('Donation cancelled');
      queryClient.invalidateQueries({ queryKey: ['donation', id] });
      queryClient.invalidateQueries({ queryKey: ['my-donations'] });
    },
    onError: (e) => toast.error('Could not cancel', { description: (e as Error).message }),
  });

  const deleteMutation = useMutation({
    mutationFn: () => deleteDonation(id!),
    onSuccess: () => {
      toast.success('Donation deleted');
      navigate('/dashboard/donor/my-donations');
    },
    onError: (e) => toast.error('Could not delete', { description: (e as Error).message }),
  });

  if (isLoading) return <PageLoader />;
  if (isError) return <ErrorState onRetry={refetch} />;
  if (!donation) return <ErrorState title="Donation not found" message="This donation may have been removed." />;

  const canModify = donation.status === 'pending';
  const receiver = thisAccepted?.receiver;

  return (
    <div className="space-y-6">
      <Button asChild variant="ghost" size="sm">
        <Link to="/dashboard/donor/my-donations"><ArrowLeft className="mr-2 h-4 w-4" /> Back to donations</Link>
      </Button>

      {/* Header */}
      <div className="flex flex-col gap-4 rounded-2xl border border-border bg-card p-6 shadow-soft sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-start gap-4">
          <div className="h-16 w-16 shrink-0 overflow-hidden rounded-xl bg-muted">
            {donation.image_url ? (
              <img src={donation.image_url} alt={donation.food_name} className="h-full w-full object-cover" />
            ) : null}
          </div>
          <div>
            <h1 className="text-2xl font-extrabold">{donation.food_name}</h1>
            <div className="mt-2 flex items-center gap-2">
              <StatusBadge status={donation.status} />
              <span className="text-sm text-muted-foreground">Created {formatDate(donation.created_at)}</span>
            </div>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          {canModify && (
            <>
              <Button asChild variant="outline" size="sm">
                <Link to="/dashboard/donor/add-donation"><Edit2 className="mr-2 h-4 w-4" /> Edit</Link>
              </Button>
              <Button variant="outline" size="sm" className="text-warning hover:text-warning" onClick={() => cancelMutation.mutate()} disabled={cancelMutation.isPending}>
                <XCircle className="mr-2 h-4 w-4" /> Cancel donation
              </Button>
              <Button variant="outline" size="sm" className="text-destructive hover:text-destructive" onClick={() => setConfirmDelete(true)}>
                <Trash2 className="mr-2 h-4 w-4" /> Delete
              </Button>
            </>
          )}
          <ReportDialog donationId={donation.id} />
        </div>
      </div>

      {/* Gallery */}
      {donation.image_url && (
        <Card className="overflow-hidden shadow-soft">
          <img src={donation.image_url} alt={donation.food_name} className="h-72 w-full object-cover sm:h-96" />
        </Card>
      )}

      <DonationInfo donation={donation} />

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Timeline */}
        <Card className="p-6 shadow-soft">
          <h3 className="font-bold">Live Status</h3>
          <p className="mt-1 text-xs text-muted-foreground">Track pickup and delivery progress</p>
          <div className="mt-5">
            <StatusTimeline current={thisAccepted?.delivery_status ?? 'accepted'} cancelled={donation.status === 'cancelled'} />
          </div>
        </Card>

        {/* Receiver info */}
        <Card className="p-6 shadow-soft lg:col-span-2">
          <h3 className="font-bold">Receiver</h3>
          {receiver ? (
            <div className="mt-4 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-3">
                <Avatar className="h-12 w-12">
                  {receiver.avatar && <AvatarImage src={receiver.avatar} alt={receiver.full_name} />}
                  <AvatarFallback className="bg-primary/10 font-bold text-primary">{initials(receiver.full_name)}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-bold">{receiver.full_name}</p>
                  <p className="text-xs capitalize text-muted-foreground">{receiver.role}</p>
                </div>
              </div>
              <div className="flex flex-col gap-1.5 text-sm text-muted-foreground">
                {receiver.phone && <span className="flex items-center gap-2"><Phone className="h-4 w-4 text-primary" /> {receiver.phone}</span>}
                {receiver.address && <span className="flex items-center gap-2"><MapPin className="h-4 w-4 text-primary" /> {receiver.address}</span>}
              </div>
            </div>
          ) : (
            <div className="mt-4 flex items-center gap-3 rounded-xl border border-dashed border-border bg-muted/30 p-4 text-sm text-muted-foreground">
              <User className="h-5 w-5 text-primary" />
              {donation.status === 'pending' ? 'Waiting for an NGO to accept this donation.' : 'No receiver information available.'}
            </div>
          )}
        </Card>
      </div>

      <Card className="p-6 shadow-soft">
        <ReviewsSection
          donationId={donation.id}
          revieweeId={receiver?.id ?? ''}
          revieweeName={receiver?.full_name ?? 'the receiver'}
          canReview={donation.status === 'delivered' && !!receiver && receiver.id !== user?.id}
        />
      </Card>

      <AlertDialog open={confirmDelete} onOpenChange={setConfirmDelete}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this donation?</AlertDialogTitle>
            <AlertDialogDescription>
              “{donation.food_name}” will be permanently removed. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={() => deleteMutation.mutate()}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
