import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Upload, X, ImageIcon, Sparkles, Loader2, Save } from 'lucide-react';
import { toast } from 'sonner';
import { donationSchema, type DonationValues } from '@/lib/validations';
import { useAuth } from '@/contexts/auth-context';
import { createDonation, uploadFoodImage } from '@/services/data';
import { getRecommendationCards } from '@/services/ai-assistant';
import { FOOD_CATEGORIES, FOOD_TYPES, UNITS } from '@/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import * as Icons from 'lucide-react';

export default function AddDonation() {
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const form = useForm<DonationValues>({
    resolver: zodResolver(donationSchema),
    defaultValues: {
      food_name: '',
      food_type: 'veg',
      category: 'cooked',
      quantity: 0,
      unit: 'kg',
      description: '',
      prepared_date: '',
      expiry_date: '',
      pickup_time: '',
      pickup_address: profile?.address ?? '',
      city: profile?.city ?? '',
      phone: profile?.phone ?? '',
      special_instructions: '',
    },
  });

  const watched = form.watch();
  const expiryHours = watched.expiry_date
    ? (new Date(watched.expiry_date).getTime() - Date.now()) / 3600000
    : undefined;
  const recommendations = watched.category
    ? getRecommendationCards({ category: watched.category, foodType: watched.food_type, expiryHours })
    : [];

  const handleImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      toast.error('Image too large', { description: 'Max file size is 5MB.' });
      return;
    }
    setImageFile(file);
    setImagePreview(URL.createObjectURL(file));
  };

  const removeImage = () => {
    setImageFile(null);
    setImagePreview(null);
  };

  const onSubmit = async (values: DonationValues) => {
    if (!user) return;
    setSubmitting(true);
    try {
      let imageUrl: string | null = null;
      if (imageFile) {
        setUploading(true);
        const tempId = `${user.id}-${Date.now()}`;
        imageUrl = await uploadFoodImage(imageFile, tempId);
        setUploading(false);
      }

      await createDonation({
        food_name: values.food_name,
        food_type: values.food_type,
        category: values.category,
        quantity: Number(values.quantity),
        unit: values.unit,
        description: values.description ?? null,
        prepared_date: values.prepared_date,
        expiry_date: values.expiry_date ? new Date(values.expiry_date).toISOString() : null,
        pickup_time: values.pickup_time,
        pickup_address: values.pickup_address,
        latitude: null,
        longitude: null,
        image_url: imageUrl,
        phone: values.phone,
        special_instructions: values.special_instructions ?? null,
      });

      toast.success('Donation created!', { description: 'Your surplus food is now visible to NGOs nearby.' });
      navigate('/dashboard/donor/my-donations');
    } catch (e) {
      toast.error('Could not create donation', { description: (e as Error).message });
    } finally {
      setSubmitting(false);
      setUploading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-extrabold">Add a Donation</h2>
        <p className="mt-1 text-muted-foreground">List your surplus food so NGOs can find and collect it.</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <Card className="space-y-5 p-6 shadow-soft">
                <h3 className="font-bold">Food details</h3>

                <div className="grid gap-4 sm:grid-cols-2">
                  <FormField
                    control={form.control}
                    name="food_name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Food Name</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g. Cooked rice and curry" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="category"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Food Category</FormLabel>
                        <Select value={field.value} onValueChange={field.onChange}>
                          <FormControl>
                            <SelectTrigger><SelectValue placeholder="Select category" /></SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {FOOD_CATEGORIES.map((c) => (
                              <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid gap-4 sm:grid-cols-3">
                  <FormField
                    control={form.control}
                    name="food_type"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Food Type</FormLabel>
                        <Select value={field.value} onValueChange={field.onChange}>
                          <FormControl>
                            <SelectTrigger><SelectValue /></SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {FOOD_TYPES.map((t) => (
                              <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="quantity"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Quantity</FormLabel>
                        <FormControl>
                          <Input type="number" min={0} step="0.1" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="unit"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Unit</FormLabel>
                        <Select value={field.value} onValueChange={field.onChange}>
                          <FormControl>
                            <SelectTrigger><SelectValue /></SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {UNITS.map((u) => (
                              <SelectItem key={u} value={u}>{u}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea rows={3} placeholder="Describe the food, ingredients, allergens…" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </Card>

              <Card className="space-y-5 p-6 shadow-soft">
                <h3 className="font-bold">Pickup & timing</h3>
                <div className="grid gap-4 sm:grid-cols-2">
                  <FormField
                    control={form.control}
                    name="prepared_date"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Cooking / Prepared Date</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="expiry_date"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Expiry Date & Time</FormLabel>
                        <FormControl>
                          <Input type="datetime-local" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <FormField
                  control={form.control}
                  name="pickup_time"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Preferred Pickup Time</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Today 4 PM – 7 PM" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="pickup_address"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Pickup Address</FormLabel>
                      <FormControl>
                        <Textarea rows={2} placeholder="Full pickup address" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="grid gap-4 sm:grid-cols-2">
                  <FormField
                    control={form.control}
                    name="city"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>City</FormLabel>
                        <FormControl>
                          <Input placeholder="City" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Contact Phone</FormLabel>
                        <FormControl>
                          <Input placeholder="Phone for pickup coordination" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <FormField
                  control={form.control}
                  name="special_instructions"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Special Instructions <span className="text-muted-foreground">(optional)</span></FormLabel>
                      <FormControl>
                        <Textarea rows={2} placeholder="e.g. Bring your own containers, ring the back door…" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </Card>

              <Card className="p-6 shadow-soft">
                <FormLabel>Food Image <span className="text-muted-foreground">(optional)</span></FormLabel>
                <div className="mt-3">
                  {imagePreview ? (
                    <div className="relative overflow-hidden rounded-xl border border-border">
                      <img src={imagePreview} alt="Donation preview" className="h-56 w-full object-cover" />
                      <button
                        type="button"
                        onClick={removeImage}
                        className="absolute right-3 top-3 rounded-lg bg-black/60 p-1.5 text-white hover:bg-black/80"
                        aria-label="Remove image"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  ) : (
                    <label
                      htmlFor="food-image"
                      className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-border bg-muted/30 py-10 transition-colors hover:border-primary hover:bg-primary/5"
                    >
                      <ImageIcon className="h-8 w-8 text-muted-foreground" />
                      <span className="text-sm font-medium">Click to upload an image</span>
                      <span className="text-xs text-muted-foreground">PNG, JPG up to 5MB</span>
                      <input id="food-image" type="file" accept="image/*" className="hidden" onChange={handleImage} />
                    </label>
                  )}
                </div>
              </Card>

              <div className="flex justify-end gap-3">
                <Button type="button" variant="outline" onClick={() => navigate('/dashboard/donor/my-donations')}>
                  Cancel
                </Button>
                <Button type="submit" className="gradient-primary text-white shadow-glow" disabled={submitting || uploading}>
                  {uploading ? (
                    <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Uploading image…</>
                  ) : submitting ? (
                    <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving…</>
                  ) : (
                    <><Save className="mr-2 h-4 w-4" /> Publish donation</>
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </div>

        {/* AI Assistant sidebar */}
        <div className="space-y-4">
          <Card className="p-5 shadow-soft">
            <div className="flex items-center gap-2">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl gradient-accent text-white">
                <Sparkles className="h-5 w-5" />
              </span>
              <div>
                <h3 className="font-bold">AI Food Assistant</h3>
                <p className="text-xs text-muted-foreground">Smart recommendations for safe donations</p>
              </div>
            </div>
            <div className="mt-4 space-y-3">
              {recommendations.map((r, i) => {
                const Icon = (Icons[r.icon as keyof typeof Icons] ?? Icons.Sparkles) as React.ComponentType<{ className?: string }>;
                const toneCls = {
                  info: 'bg-info/10 text-info',
                  success: 'bg-success/10 text-success',
                  warning: 'bg-warning/10 text-warning',
                }[r.tone];
                return (
                  <div key={i} className={cn('rounded-xl border border-border p-3')}>
                    <div className="flex items-center gap-2">
                      <span className={cn('flex h-8 w-8 items-center justify-center rounded-lg', toneCls)}>
                        <Icon className="h-4 w-4" />
                      </span>
                      <p className="text-sm font-bold">{r.title}</p>
                    </div>
                    <p className="mt-2 text-xs leading-relaxed text-muted-foreground">{r.body}</p>
                  </div>
                );
              })}
            </div>
          </Card>

          <Card className="p-5 shadow-soft">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Upload className="h-4 w-4" />
              Tip: add a clear photo — donations with images get accepted faster.
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
