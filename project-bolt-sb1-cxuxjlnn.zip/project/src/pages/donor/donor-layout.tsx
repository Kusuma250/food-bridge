import { LayoutDashboard, PlusCircle, Package, BarChart3, User, Settings, Bell } from 'lucide-react';
import { DashboardShell, type NavItem } from '@/components/layouts/dashboard-shell';

const items: NavItem[] = [
  { to: '/dashboard/donor', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/dashboard/donor/add-donation', label: 'Add Donation', icon: PlusCircle },
  { to: '/dashboard/donor/my-donations', label: 'My Donations', icon: Package },
  { to: '/dashboard/donor/analytics', label: 'Analytics', icon: BarChart3 },
  { to: '/dashboard/donor/notifications', label: 'Notifications', icon: Bell },
  { to: '/dashboard/donor/profile', label: 'Profile', icon: User },
  { to: '/dashboard/donor/settings', label: 'Settings', icon: Settings },
];

export default function DonorLayout() {
  return <DashboardShell items={items} title="Donor Dashboard" accent="donor" />;
}
