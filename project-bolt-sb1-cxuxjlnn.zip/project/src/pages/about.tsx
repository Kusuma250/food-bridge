import { motion } from 'framer-motion';
import { Target, Eye, Sprout, Users, Truck, Leaf, TrendingUp } from 'lucide-react';
import { SectionHeading } from '@/components/shared/section-heading';
import { StatCard } from '@/components/shared/stat-card';
import { Card } from '@/components/ui/card';

const mission = {
  icon: Target,
  title: 'Our Mission',
  body: 'To eliminate food waste by creating a seamless bridge between those who have surplus food and those who need it — ensuring no edible meal ends up in a landfill while people go hungry.',
};

const vision = {
  icon: Eye,
  title: 'Our Vision',
  body: 'A world where surplus food is never wasted, where every restaurant, hotel, and household can redirect their excess to nourish communities — making hunger a solvable problem, one donation at a time.',
};

const goals = [
  { icon: Leaf, title: 'Cut Food Waste', desc: 'Divert 1 million kg of surplus food from landfills by 2030.' },
  { icon: Users, title: 'Feed Communities', desc: 'Connect 10,000 NGOs and shelters with reliable food sources.' },
  { icon: Truck, title: 'Enable Fast Pickup', desc: 'Reduce average donation-to-collection time under 4 hours.' },
  { icon: TrendingUp, title: 'Scale Impact', desc: 'Expand to 100 cities with verified donor and receiver networks.' },
];

const impact = [
  { icon: <Sprout className="h-5 w-5" />, label: 'Food Saved', value: '12,400 kg', tone: 'primary' as const },
  { icon: <Users className="h-5 w-5" />, label: 'People Fed', value: '28,900', tone: 'accent' as const },
  { icon: <Truck className="h-5 w-5" />, label: 'Pickups Completed', value: '3,420', tone: 'info' as const },
  { icon: <Leaf className="h-5 w-5" />, label: 'CO₂ Reduced', value: '31 t', tone: 'success' as const },
];

const team = [
  { name: 'Aarav Mehta', role: 'Founder & CEO', initials: 'AM' },
  { name: 'Sara Okafor', role: 'Head of Operations', initials: 'SO' },
  { name: 'Diego Ramos', role: 'Lead Engineer', initials: 'DR' },
  { name: 'Mei Lin', role: 'NGO Partnerships', initials: 'ML' },
];

const timeline = [
  { year: '2023', title: 'The Idea', desc: 'Founded after witnessing caterers discard trays of edible food after a community event.' },
  { year: '2024', title: 'First 1,000 Donations', desc: 'Launched in 3 cities and crossed our first thousand successful pickups within six months.' },
  { year: '2025', title: 'Verified NGO Network', desc: 'Onboarded 186 verified NGOs, shelters, and community kitchens across 12 cities.' },
  { year: '2026', title: 'AI Food Assistant', desc: 'Introduced AI-powered shelf-life and storage guidance to keep donations safe and timely.' },
];

export default function About() {
  return (
    <div className="overflow-hidden">
      <section className="gradient-hero py-20 sm:py-28">
        <div className="container">
          <SectionHeading
            eyebrow="About Food Bridge"
            title="We turn surplus into sustenance"
            description="Food Bridge is a smart food donation platform built to reduce food waste and fight hunger — connecting generous donors with communities that need it most."
          />
        </div>
      </section>

      <section className="py-20">
        <div className="container grid gap-6 md:grid-cols-2">
          {[mission, vision].map((item, i) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
            >
              <Card className="h-full p-8 shadow-soft">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl gradient-primary text-white shadow-glow">
                  <item.icon className="h-6 w-6" />
                </div>
                <h3 className="mt-5 text-2xl font-bold">{item.title}</h3>
                <p className="mt-3 leading-relaxed text-muted-foreground">{item.body}</p>
              </Card>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="bg-card/40 py-20">
        <div className="container">
          <SectionHeading eyebrow="Our Goals" title="What we are working toward" />
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {goals.map((g, i) => (
              <motion.div
                key={g.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                className="rounded-2xl border border-border bg-background p-6 shadow-soft"
              >
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <g.icon className="h-5 w-5" />
                </div>
                <h3 className="mt-4 font-bold">{g.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{g.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="container">
          <SectionHeading eyebrow="Our Impact" title="Real numbers, real meals" />
          <div className="mt-12 grid grid-cols-2 gap-4 lg:grid-cols-4">
            {impact.map((s, i) => (
              <StatCard key={s.label} icon={s.icon} label={s.label} value={s.value} tone={s.tone} delay={i * 0.08} />
            ))}
          </div>
        </div>
      </section>

      <section className="bg-card/40 py-20">
        <div className="container">
          <SectionHeading eyebrow="Meet the Team" title="The people behind Food Bridge" />
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {team.map((m, i) => (
              <motion.div
                key={m.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                className="rounded-2xl border border-border bg-background p-6 text-center shadow-soft"
              >
                <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full gradient-primary text-xl font-bold text-white shadow-glow">
                  {m.initials}
                </div>
                <h3 className="mt-4 font-bold">{m.name}</h3>
                <p className="text-sm text-muted-foreground">{m.role}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="container max-w-3xl">
          <SectionHeading eyebrow="Our Journey" title="How we got here" />
          <ol className="mt-12 space-y-6 border-l-2 border-primary/20 pl-6">
            {timeline.map((t, i) => (
              <motion.li
                key={t.year}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                className="relative"
              >
                <span className="absolute -left-[31px] flex h-6 w-6 items-center justify-center rounded-full gradient-primary text-[10px] font-bold text-white ring-4 ring-background">
                  {i + 1}
                </span>
                <div className="rounded-2xl border border-border bg-card p-5 shadow-soft">
                  <span className="text-sm font-bold text-primary">{t.year}</span>
                  <h3 className="mt-1 font-bold">{t.title}</h3>
                  <p className="mt-1 text-sm text-muted-foreground">{t.desc}</p>
                </div>
              </motion.li>
            ))}
          </ol>
        </div>
      </section>
    </div>
  );
}
