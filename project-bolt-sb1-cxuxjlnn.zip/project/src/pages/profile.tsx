import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Camera, Save, Trash2, Lock, User as UserIcon, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';
import { profileSchema, type ProfileValues } from '@/lib/validations';
import { useAuth } from '@/contexts/auth-context';
import { updateProfile, uploadAvatar } from '@/services/data';
import { supabase } from '@/services/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card } from '@/components/ui/card';
import { PageLoader } from '@/components/shared/loading';
import { initials } from '@/lib/utils';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';

export default function Profile() {
  const { user, profile, refreshProfile, signOut } = useAuth();
  const [uploading, setUploading] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [saving, setSaving] = useState(false);

  const form = useForm<ProfileValues>({
    resolver: zodResolver(profileSchema),
    values: {
      full_name: profile?.full_name ?? '',
      phone: profile?.phone ?? '',
      address: profile?.address ?? '',
      city: profile?.city ?? '',
      district: profile?.district ?? '',
      state: profile?.state ?? '',
      country: profile?.country ?? '',
    },
  });

  if (!user || !profile) return <PageLoader />;

  const handleAvatar = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) {
      toast.error('Image too large', { description: 'Max 2MB.' });
      return;
    }
    setUploading(true);
    try {
      const url = await uploadAvatar(file, user.id);
      await updateProfile(user.id, { avatar: url });
      await refreshProfile();
      toast.success('Avatar updated');
    } catch (e) {
      toast.error('Upload failed', { description: (e as Error).message });
    } finally {
      setUploading(false);
    }
  };

  const onSubmit = async (values: ProfileValues) => {
    setSaving(true);
    try {
      await updateProfile(user.id, {
        full_name: values.full_name,
        phone: values.phone || null,
        address: values.address || null,
        city: values.city || null,
        district: values.district || null,
        state: values.state || null,
        country: values.country || null,
      });
      await refreshProfile();
      toast.success('Profile updated');
    } catch (e) {
      toast.error('Update failed', { description: (e as Error).message });
    } finally {
      setSaving(false);
    }
  };

  const deleteAccount = async () => {
    try {
      await supabase.from('profiles').delete().eq('id', user.id);
      await signOut();
      toast.success('Account deleted');
      window.location.href = '/';
    } catch (e) {
      toast.error('Could not delete account', { description: (e as Error).message });
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-extrabold">Profile</h2>
        <p className="mt-1 text-muted-foreground">Manage your personal information and account.</p>
      </div>

      {/* Avatar card */}
      <Card className="p-6 shadow-soft">
        <div className="flex flex-col items-center gap-4 sm:flex-row sm:items-center">
          <div className="relative">
            <Avatar className="h-24 w-24">
              {profile.avatar && <AvatarImage src={profile.avatar} alt={profile.full_name} />}
              <AvatarFallback className="bg-primary/10 text-2xl font-bold text-primary">{initials(profile.full_name)}</AvatarFallback>
            </Avatar>
            <label
              htmlFor="avatar-upload"
              className="absolute -bottom-1 -right-1 flex h-8 w-8 cursor-pointer items-center justify-center rounded-full gradient-primary text-white shadow-glow"
              aria-label="Upload avatar"
            >
              <Camera className="h-4 w-4" />
              <input id="avatar-upload" type="file" accept="image/*" className="hidden" onChange={handleAvatar} disabled={uploading} />
            </label>
          </div>
          <div className="text-center sm:text-left">
            <h3 className="text-xl font-bold">{profile.full_name}</h3>
            <p className="text-sm text-muted-foreground">{profile.email}</p>
            <span className="mt-1 inline-flex rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-semibold capitalize text-primary">{profile.role}</span>
          </div>
        </div>
      </Card>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <Card className="space-y-5 p-6 shadow-soft">
            <h3 className="flex items-center gap-2 font-bold"><UserIcon className="h-5 w-5 text-primary" /> Personal Information</h3>
            <div className="grid gap-4 sm:grid-cols-2">
              <FormField control={form.control} name="full_name" render={({ field }) => (
                <FormItem>
                  <FormLabel>Full Name</FormLabel>
                  <FormControl><Input {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="phone" render={({ field }) => (
                <FormItem>
                  <FormLabel>Phone</FormLabel>
                  <FormControl><Input placeholder="+1 555 000 1234" {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
            </div>
            <FormField control={form.control} name="address" render={({ field }) => (
              <FormItem>
                <FormLabel>Address</FormLabel>
                <FormControl><Textarea rows={2} {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )} />
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <FormField control={form.control} name="city" render={({ field }) => (
                <FormItem><FormLabel>City</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="district" render={({ field }) => (
                <FormItem><FormLabel>District</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="state" render={({ field }) => (
                <FormItem><FormLabel>State</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
              )} />
              <FormField control={form.control} name="country" render={({ field }) => (
                <FormItem><FormLabel>Country</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
              )} />
            </div>
            <div className="flex justify-end">
              <Button type="submit" className="gradient-primary text-white shadow-glow" disabled={saving}>
                <Save className="mr-2 h-4 w-4" /> {saving ? 'Saving…' : 'Save changes'}
              </Button>
            </div>
          </Card>
        </form>
      </Form>

      {/* Password change */}
      <PasswordChangeCard />

      {/* Danger zone */}
      <Card className="border-destructive/30 p-6 shadow-soft">
        <h3 className="flex items-center gap-2 font-bold text-destructive"><AlertTriangle className="h-5 w-5" /> Danger Zone</h3>
        <p className="mt-2 text-sm text-muted-foreground">Permanently delete your account and all associated data. This cannot be undone.</p>
        <Button variant="destructive" className="mt-4" onClick={() => setConfirmDelete(true)}>
          <Trash2 className="mr-2 h-4 w-4" /> Delete account
        </Button>
      </Card>

      <AlertDialog open={confirmDelete} onOpenChange={setConfirmDelete}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete your account?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove your profile and donations. This action is irreversible.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={deleteAccount}>
              Delete permanently
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function PasswordChangeCard() {
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [confirm, setConfirm] = useState('');
  const [loading, setLoading] = useState(false);

  const change = async (e: React.FormEvent) => {
    e.preventDefault();
    if (next !== confirm) {
      toast.error('Passwords do not match');
      return;
    }
    if (next.length < 8) {
      toast.error('Password too short', { description: 'Use at least 8 characters.' });
      return;
    }
    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password: next });
    setLoading(false);
    if (error) {
      toast.error('Could not change password', { description: error.message });
      return;
    }
    toast.success('Password changed');
    setCurrent(''); setNext(''); setConfirm('');
  };

  return (
    <Card className="space-y-5 p-6 shadow-soft">
      <h3 className="flex items-center gap-2 font-bold"><Lock className="h-5 w-5 text-primary" /> Change Password</h3>
      <form onSubmit={change} className="grid gap-4 sm:grid-cols-3">
        <div>
          <label className="text-sm font-medium">New Password</label>
          <Input type="password" value={next} onChange={(e) => setNext(e.target.value)} placeholder="••••••••" className="mt-1.5" />
        </div>
        <div>
          <label className="text-sm font-medium">Confirm Password</label>
          <Input type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} placeholder="••••••••" className="mt-1.5" />
        </div>
        <div className="flex items-end">
          <Button type="submit" className="w-full" disabled={loading}>{loading ? 'Updating…' : 'Update password'}</Button>
        </div>
      </form>
      <input type="hidden" value={current} onChange={(e) => setCurrent(e.target.value)} />
    </Card>
  );
}
