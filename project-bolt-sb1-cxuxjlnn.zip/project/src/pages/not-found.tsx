import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Home, Search, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Logo } from '@/components/shared/logo';

export default function NotFound() {
  return (
    <div className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden px-6 text-center">
      <div className="absolute inset-0 gradient-hero" />
      <div className="absolute inset-0 bg-grid opacity-[0.04] [mask-image:radial-gradient(50%_50%_at_50%_50%,black,transparent)]" />
      <div className="relative">
        <Logo />
        <motion.h1
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="mt-10 text-8xl font-extrabold tracking-tight sm:text-9xl"
        >
          <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">404</span>
        </motion.h1>
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.15 }}
          className="mt-4 max-w-md"
        >
          <h2 className="text-2xl font-bold">Page not found</h2>
          <p className="mt-2 text-muted-foreground">
            The page you are looking for may have been moved, deleted, or never existed.
          </p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row"
        >
          <Button asChild className="gradient-primary text-white shadow-glow">
            <Link to="/">
              <Home className="mr-2 h-4 w-4" /> Back home
            </Link>
          </Button>
          <Button asChild variant="outline">
            <Link to="/contact">
              <Search className="mr-2 h-4 w-4" /> Contact support
            </Link>
          </Button>
        </motion.div>
        <Link to="/" className="mt-8 inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary">
          <ArrowLeft className="h-4 w-4" /> Return to Food Bridge
        </Link>
      </div>
    </div>
  );
}
