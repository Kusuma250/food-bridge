import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { Users, Package, Building2, CheckCircle2, Clock, XCircle, HeartHandshake, Trash2, Flag, ArrowRight, TrendingUp } from 'lucide-react';
import { fetchAdminStats } from '@/services/data';
import { StatCard } from '@/components/shared/stat-card';
import { LoadingSpinner } from '@/components/shared/loading';
import { ErrorState } from '@/components/shared/error-state';
import { Card } from '@/components/ui/card';
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from 'recharts';

export default function AdminDashboard() {
  const { data, isLoading, isError, refetch } = useQuery({
    queryKey: ['admin-stats'],
    queryFn: fetchAdminStats,
  });

  if (isLoading) return <LoadingSpinner label="Loading platform stats…" />;
  if (isError) return <ErrorState onRetry={refetch} />;
  if (!data) return null;

  const wasteReducedKg = Math.round(data.mealsSaved * 0.4);

  return (
    <div className="space-y-8">
      <div className="rounded-2xl bg-foreground p-6 text-background shadow-glow">
        <h2 className="text-2xl font-extrabold">Admin Dashboard</h2>
        <p className="mt-1 text-background/70">Platform-wide overview of Food Bridge activity.</p>
      </div>

      {/* Primary stats */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard icon={<Users className="h-5 w-5" />} label="Total Users" value={data.totalUsers} tone="primary" delay={0} />
        <StatCard icon={<Package className="h-5 w-5" />} label="Total Donations" value={data.totalDonations} tone="accent" delay={0.08} />
        <StatCard icon={<HeartHandshake className="h-5 w-5" />} label="Meals Saved" value={data.mealsSaved} tone="success" delay={0.16} />
        <StatCard icon={<Trash2 className="h-5 w-5" />} label="Waste Reduced" value={`${wasteReducedKg} kg`} tone="info" delay={0.24} />
      </div>

      {/* Secondary stats */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard icon={<Building2 className="h-5 w-5" />} label="Donors" value={data.totalDonors} tone="primary" />
        <StatCard icon={<Building2 className="h-5 w-5" />} label="NGOs" value={data.totalNgos} tone="accent" />
        <StatCard icon={<Clock className="h-5 w-5" />} label="Pending" value={data.pendingDonations} tone="warning" />
        <StatCard icon={<XCircle className="h-5 w-5" />} label="Cancelled" value={data.cancelledDonations} tone="info" />
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard icon={<CheckCircle2 className="h-5 w-5" />} label="Accepted" value={data.acceptedDonations} tone="info" />
        <StatCard icon={<CheckCircle2 className="h-5 w-5" />} label="Delivered" value={data.deliveredDonations} tone="success" />
        <StatCard icon={<Flag className="h-5 w-5" />} label="Open Reports" value={data.openReports} tone="warning" />
        <StatCard icon={<TrendingUp className="h-5 w-5" />} label="Weekly Avg" value={Math.round(data.weeklyDonations.reduce((s, w) => s + w.count, 0) / 6)} tone="primary" />
      </div>

      {/* Charts */}
      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="p-5 shadow-soft">
          <h3 className="font-bold">Donation Growth</h3>
          <p className="text-xs text-muted-foreground">Weekly donations over the last 6 weeks</p>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={data.weeklyDonations} margin={{ left: -20, top: 12 }}>
              <defs>
                <linearGradient id="adminDonations" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#16a34a" stopOpacity={0.35} />
                  <stop offset="100%" stopColor="#16a34a" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="week" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
              <YAxis allowDecimals={false} tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
              <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))' }} />
              <Area type="monotone" dataKey="count" stroke="#16a34a" strokeWidth={2.5} fill="url(#adminDonations)" />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-5 shadow-soft">
          <h3 className="font-bold">Platform Health</h3>
          <p className="text-xs text-muted-foreground">Donations by outcome</p>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart
              data={[
                { name: 'Pending', count: data.pendingDonations },
                { name: 'Accepted', count: data.acceptedDonations },
                { name: 'Delivered', count: data.deliveredDonations },
                { name: 'Cancelled', count: data.cancelledDonations },
              ]}
              margin={{ left: -20, top: 12 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
              <YAxis allowDecimals={false} tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
              <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))' }} />
              <Bar dataKey="count" fill="#f97316" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Quick links */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { to: '/admin/users', icon: Users, label: 'Manage Users' },
          { to: '/admin/donations', icon: Package, label: 'Manage Donations' },
          { to: '/admin/reports', icon: Flag, label: 'Review Reports' },
          { to: '/admin/analytics', icon: BarChart3Like, label: 'View Analytics' },
        ].map((q) => (
          <Link key={q.to} to={q.to} className="group rounded-2xl border border-border bg-card p-5 shadow-soft transition-all hover:-translate-y-1 hover:shadow-glow">
            <div className="flex items-center justify-between">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
                <q.icon className="h-5 w-5" />
              </span>
              <ArrowRight className="h-4 w-4 text-muted-foreground transition-transform group-hover:translate-x-1 group-hover:text-primary" />
            </div>
            <p className="mt-3 font-bold">{q.label}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}

function BarChart3Like({ className }: { className?: string }) {
  return <TrendingUp className={className} />;
}
