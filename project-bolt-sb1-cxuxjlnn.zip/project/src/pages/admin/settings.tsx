import { Shield, Globe, Bell, Database, Mail } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

export default function AdminSettings() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-extrabold">Settings</h2>
        <p className="mt-1 text-muted-foreground">Platform configuration and policies.</p>
      </div>

      <Card className="p-6 shadow-soft">
        <h3 className="flex items-center gap-2 font-bold"><Shield className="h-5 w-5 text-primary" /> Security</h3>
        <div className="mt-4 space-y-1">
          <Row title="Require email verification" desc="New users must verify their email" defaultChecked onChange={() => toast.info('Setting saved')} />
          <Row title="Auto-suspend on multiple reports" desc="Suspend accounts after 3 unresolved reports" defaultChecked onChange={() => toast.info('Setting saved')} />
          <Row title="Admin role protection" desc="Only admins can access this panel" defaultChecked onChange={() => toast.info('Setting saved')} />
        </div>
      </Card>

      <Card className="p-6 shadow-soft">
        <h3 className="flex items-center gap-2 font-bold"><Database className="h-5 w-5 text-primary" /> Storage</h3>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <div className="rounded-xl border border-border p-4">
            <p className="text-sm font-semibold">food-images bucket</p>
            <p className="text-xs text-muted-foreground">Public read, authenticated write</p>
            <Badge variant="outline" className="mt-2 border-success/30 bg-success/10 text-success">Active</Badge>
          </div>
          <div className="rounded-xl border border-border p-4">
            <p className="text-sm font-semibold">avatars bucket</p>
            <p className="text-xs text-muted-foreground">Public read, owner write</p>
            <Badge variant="outline" className="mt-2 border-success/30 bg-success/10 text-success">Active</Badge>
          </div>
        </div>
      </Card>

      <Card className="p-6 shadow-soft">
        <h3 className="flex items-center gap-2 font-bold"><Mail className="h-5 w-5 text-primary" /> Email Notifications</h3>
        <p className="mt-1 text-sm text-muted-foreground">Automated emails sent to users on key events.</p>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          {['Signup welcome', 'Email verification', 'Donation created', 'Donation accepted', 'Pickup reminder', 'Delivery completed', 'Password reset'].map((e) => (
            <div key={e} className="flex items-center justify-between rounded-xl border border-border p-3">
              <span className="text-sm font-medium">{e}</span>
              <Badge variant="outline" className="border-success/30 bg-success/10 text-success">Enabled</Badge>
            </div>
          ))}
        </div>
      </Card>

      <Card className="p-6 shadow-soft">
        <h3 className="flex items-center gap-2 font-bold"><Globe className="h-5 w-5 text-primary" /> Platform</h3>
        <div className="mt-4 space-y-1">
          <Row title="Allow public donation browsing" desc="NGOs can browse without login" onChange={() => toast.info('Setting saved')} />
          <Row title="Maintenance mode" desc="Temporarily disable new signups" onChange={() => toast.info('Setting saved')} />
        </div>
      </Card>

      <Card className="p-6 shadow-soft">
        <h3 className="flex items-center gap-2 font-bold"><Bell className="h-5 w-5 text-primary" /> Realtime</h3>
        <div className="mt-4">
          <Row title="Realtime notifications" desc="Push live updates to connected users" defaultChecked onChange={() => toast.info('Setting saved')} />
        </div>
      </Card>

      <div className="flex justify-end">
        <Button className="gradient-primary text-white" onClick={() => toast.success('All settings saved')}>Save settings</Button>
      </div>
    </div>
  );
}

function Row({ title, desc, defaultChecked, onChange }: { title: string; desc: string; defaultChecked?: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between rounded-xl p-3 transition-colors hover:bg-accent/5">
      <div>
        <p className="text-sm font-semibold">{title}</p>
        <p className="text-xs text-muted-foreground">{desc}</p>
      </div>
      <Switch defaultChecked={defaultChecked} onCheckedChange={onChange} />
    </div>
  );
}
