import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Search, Download, Trash2, Eye, ChevronLeft, ChevronRight, Package } from 'lucide-react';
import { toast } from 'sonner';
import { fetchDonations, deleteDonation, adminUpdateDonationStatus } from '@/services/data';
import type { DonationStatus, FoodDonation } from '@/types';
import { StatusBadge } from '@/components/shared/status-badge';
import { EmptyState } from '@/components/shared/empty-state';
import { ErrorState } from '@/components/shared/error-state';
import { TableSkeleton } from '@/components/shared/loading';
import { DonationInfo } from '@/components/shared/donation-info';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { downloadFile, toCsv, formatDate, paginate } from '@/lib/utils';

const PAGE_SIZE = 10;
const statusOptions: { value: DonationStatus | 'all'; label: string }[] = [
  { value: 'all', label: 'All statuses' },
  { value: 'pending', label: 'Pending' },
  { value: 'accepted', label: 'Accepted' },
  { value: 'collected', label: 'Collected' },
  { value: 'on_the_way', label: 'On The Way' },
  { value: 'delivered', label: 'Delivered' },
  { value: 'cancelled', label: 'Cancelled' },
];

export default function AdminDonations() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState<DonationStatus | 'all'>('all');
  const [page, setPage] = useState(1);
  const [viewDonation, setViewDonation] = useState<FoodDonation | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<FoodDonation | null>(null);

  const { data, isLoading, isError, refetch } = useQuery({
    queryKey: ['admin-donations', search, status],
    queryFn: () => fetchDonations({ search, status }),
  });

  const statusMutation = useMutation({
    mutationFn: ({ id, status }: { id: string; status: DonationStatus }) => adminUpdateDonationStatus(id, status),
    onSuccess: () => {
      toast.success('Donation status updated');
      queryClient.invalidateQueries({ queryKey: ['admin-donations'] });
    },
    onError: (e) => toast.error('Update failed', { description: (e as Error).message }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => deleteDonation(id),
    onSuccess: () => {
      toast.success('Donation deleted');
      queryClient.invalidateQueries({ queryKey: ['admin-donations'] });
      setConfirmDelete(null);
    },
    onError: (e) => toast.error('Delete failed', { description: (e as Error).message }),
  });

  const rows = data?.data ?? [];
  const totalPages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
  const pageRows = paginate(rows, page, PAGE_SIZE);

  const exportCsv = () => {
    const csv = toCsv(rows.map((d) => ({
      food: d.food_name, category: d.category, type: d.food_type, quantity: `${d.quantity} ${d.unit}`,
      status: d.status, donor: d.donor?.full_name ?? '', created: formatDate(d.created_at),
    })));
    downloadFile('foodbridge-donations.csv', csv, 'text/csv');
    toast.success('Exported CSV');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h2 className="text-2xl font-extrabold">Donations</h2>
          <p className="mt-1 text-muted-foreground">{data?.count ?? 0} total donations</p>
        </div>
        <Button variant="outline" onClick={exportCsv}><Download className="mr-2 h-4 w-4" /> Export</Button>
      </div>

      <div className="flex flex-col gap-3 rounded-2xl border border-border bg-card p-4 shadow-soft sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input placeholder="Search donations…" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} className="pl-9" />
        </div>
        <Select value={status} onValueChange={(v) => { setStatus(v as DonationStatus | 'all'); setPage(1); }}>
          <SelectTrigger className="sm:w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            {statusOptions.map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {isError ? (
        <ErrorState onRetry={refetch} />
      ) : isLoading ? (
        <TableSkeleton />
      ) : rows.length === 0 ? (
        <EmptyState icon={<Package className="h-7 w-7" />} title="No donations found" description="Try adjusting your search or filters." />
      ) : (
        <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-soft">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Food</TableHead>
                <TableHead>Donor</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Created</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pageRows.map((d) => (
                <TableRow key={d.id}>
                  <TableCell className="font-medium">{d.food_name}<span className="ml-2 text-xs text-muted-foreground">{d.quantity} {d.unit}</span></TableCell>
                  <TableCell className="text-sm">{d.donor?.full_name ?? '—'}</TableCell>
                  <TableCell><StatusBadge status={d.status} /></TableCell>
                  <TableCell className="text-sm text-muted-foreground">{formatDate(d.created_at)}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      <Select onValueChange={(v) => statusMutation.mutate({ id: d.id, status: v as DonationStatus })}>
                        <SelectTrigger className="h-8 w-32 text-xs"><SelectValue placeholder="Change" /></SelectTrigger>
                        <SelectContent>
                          {statusOptions.filter((o) => o.value !== 'all').map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
                        </SelectContent>
                      </Select>
                      <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => setViewDonation(d)}><Eye className="h-4 w-4" /></Button>
                      <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive" onClick={() => setConfirmDelete(d)}><Trash2 className="h-4 w-4" /></Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {rows.length > PAGE_SIZE && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">Page {page} of {totalPages}</p>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft className="h-4 w-4" /></Button>
            <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}><ChevronRight className="h-4 w-4" /></Button>
          </div>
        </div>
      )}

      <Dialog open={!!viewDonation} onOpenChange={(open) => !open && setViewDonation(null)}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>{viewDonation?.food_name}</DialogTitle>
            <DialogDescription>Full donation details</DialogDescription>
          </DialogHeader>
          {viewDonation && <DonationInfo donation={viewDonation} />}
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!confirmDelete} onOpenChange={(open) => !open && setConfirmDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this donation?</AlertDialogTitle>
            <AlertDialogDescription>“{confirmDelete?.food_name}” will be permanently removed.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={() => confirmDelete && deleteMutation.mutate(confirmDelete.id)}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
