import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Flag, CheckCircle2, XCircle } from 'lucide-react';
import { toast } from 'sonner';
import { fetchReports, updateReportStatus } from '@/services/data';
import type { ReportStatus, ReportType } from '@/types';
import { EmptyState } from '@/components/shared/empty-state';
import { ErrorState } from '@/components/shared/error-state';
import { TableSkeleton } from '@/components/shared/loading';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { formatDate, timeAgo } from '@/lib/utils';

const typeMeta: Record<ReportType, { label: string; color: string }> = {
  fake: { label: 'Fake Donation', color: 'bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-300' },
  expired: { label: 'Expired Food', color: 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300' },
  spam: { label: 'Spam', color: 'bg-blue-100 text-blue-700 dark:bg-blue-500/15 dark:text-blue-300' },
  abuse: { label: 'Abuse', color: 'bg-purple-100 text-purple-700 dark:bg-purple-500/15 dark:text-purple-300' },
  unsafe: { label: 'Unsafe Food', color: 'bg-orange-100 text-orange-700 dark:bg-orange-500/15 dark:text-orange-300' },
};

const statusMeta: Record<ReportStatus, { label: string; color: string }> = {
  open: { label: 'Open', color: 'border-warning/30 bg-warning/10 text-warning' },
  reviewing: { label: 'Reviewing', color: 'border-info/30 bg-info/10 text-info' },
  resolved: { label: 'Resolved', color: 'border-success/30 bg-success/10 text-success' },
  dismissed: { label: 'Dismissed', color: 'border-muted bg-muted text-muted-foreground' },
};

export default function AdminReports() {
  const queryClient = useQueryClient();

  const { data, isLoading, isError, refetch } = useQuery({
    queryKey: ['admin-reports'],
    queryFn: fetchReports,
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, status }: { id: string; status: ReportStatus }) => updateReportStatus(id, status),
    onSuccess: () => {
      toast.success('Report updated');
      queryClient.invalidateQueries({ queryKey: ['admin-reports'] });
    },
    onError: (e) => toast.error('Update failed', { description: (e as Error).message }),
  });

  const rows = data ?? [];
  const openCount = rows.filter((r) => r.status === 'open').length;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-extrabold">Reports</h2>
        <p className="mt-1 text-muted-foreground">{openCount} open report{openCount !== 1 ? 's' : ''} need review</p>
      </div>

      {isError ? (
        <ErrorState onRetry={refetch} />
      ) : isLoading ? (
        <TableSkeleton />
      ) : rows.length === 0 ? (
        <EmptyState icon={<Flag className="h-7 w-7" />} title="No reports" description="User-submitted reports will appear here for review." />
      ) : (
        <div className="space-y-4">
          {rows.map((r) => {
            const tm = typeMeta[r.type];
            const sm = statusMeta[r.status];
            return (
              <Card key={r.id} className="p-5 shadow-soft">
                <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <Badge variant="outline" className={tm.color}>{tm.label}</Badge>
                      <Badge variant="outline" className={sm.color}>{sm.label}</Badge>
                      <span className="text-xs text-muted-foreground">{timeAgo(r.created_at)}</span>
                    </div>
                    <p className="mt-3 text-sm">{r.reason}</p>
                    <div className="mt-3 flex flex-wrap gap-4 text-xs text-muted-foreground">
                      <span>Reported by: <span className="font-medium text-foreground">{r.reporter?.full_name ?? 'Unknown'}</span></span>
                      {r.donation && <span>Donation: <span className="font-medium text-foreground">{r.donation.food_name}</span></span>}
                      <span>Date: {formatDate(r.created_at)}</span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    {r.status !== 'resolved' && (
                      <Button size="sm" variant="outline" className="text-success" onClick={() => updateMutation.mutate({ id: r.id, status: 'resolved' })}>
                        <CheckCircle2 className="mr-1.5 h-4 w-4" /> Resolve
                      </Button>
                    )}
                    {r.status !== 'dismissed' && (
                      <Button size="sm" variant="outline" onClick={() => updateMutation.mutate({ id: r.id, status: 'dismissed' })}>
                        <XCircle className="mr-1.5 h-4 w-4" /> Dismiss
                      </Button>
                    )}
                    <Select onValueChange={(v) => updateMutation.mutate({ id: r.id, status: v as ReportStatus })}>
                      <SelectTrigger className="h-8 w-28 text-xs"><SelectValue placeholder="Status" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="open">Open</SelectItem>
                        <SelectItem value="reviewing">Reviewing</SelectItem>
                        <SelectItem value="resolved">Resolved</SelectItem>
                        <SelectItem value="dismissed">Dismissed</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
