import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Search, Download, Ban, CheckCircle2, Trash2, Eye, ChevronLeft, ChevronRight, Users as UsersIcon } from 'lucide-react';
import { toast } from 'sonner';
import { fetchAllProfiles, setProfileSuspended } from '@/services/data';
import type { Profile, UserRole } from '@/types';
import { EmptyState } from '@/components/shared/empty-state';
import { ErrorState } from '@/components/shared/error-state';
import { TableSkeleton } from '@/components/shared/loading';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { downloadFile, toCsv, formatDate, initials, paginate } from '@/lib/utils';
import { supabase } from '@/services/supabase';

const PAGE_SIZE = 10;

export default function AdminUsers() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState('');
  const [role, setRole] = useState<UserRole | 'all'>('all');
  const [page, setPage] = useState(1);
  const [viewUser, setViewUser] = useState<Profile | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<Profile | null>(null);

  const { data, isLoading, isError, refetch } = useQuery({
    queryKey: ['admin-users', search, role],
    queryFn: () => fetchAllProfiles({ search, role }),
  });

  const suspendMutation = useMutation({
    mutationFn: ({ id, suspended }: { id: string; suspended: boolean }) => setProfileSuspended(id, suspended),
    onSuccess: () => {
      toast.success('User status updated');
      queryClient.invalidateQueries({ queryKey: ['admin-users'] });
    },
    onError: (e) => toast.error('Action failed', { description: (e as Error).message }),
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('profiles').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success('User deleted');
      queryClient.invalidateQueries({ queryKey: ['admin-users'] });
      setConfirmDelete(null);
    },
    onError: (e) => toast.error('Delete failed', { description: (e as Error).message }),
  });

  const rows = data?.data ?? [];
  const totalPages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
  const pageRows = paginate(rows, page, PAGE_SIZE);

  const exportCsv = () => {
    const csv = toCsv(rows.map((u) => ({
      name: u.full_name, email: u.email, phone: u.phone ?? '', role: u.role,
      city: u.city ?? '', country: u.country ?? '', suspended: u.is_suspended, joined: formatDate(u.created_at),
    })));
    downloadFile('foodbridge-users.csv', csv, 'text/csv');
    toast.success('Exported CSV');
  };

  const roleBadge: Record<UserRole, string> = {
    donor: 'bg-primary/10 text-primary',
    ngo: 'bg-accent/10 text-accent',
    admin: 'bg-foreground/10 text-foreground',
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h2 className="text-2xl font-extrabold">Users</h2>
          <p className="mt-1 text-muted-foreground">{data?.count ?? 0} registered users</p>
        </div>
        <Button variant="outline" onClick={exportCsv}><Download className="mr-2 h-4 w-4" /> Export</Button>
      </div>

      <div className="flex flex-col gap-3 rounded-2xl border border-border bg-card p-4 shadow-soft sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input placeholder="Search by name or email…" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} className="pl-9" />
        </div>
        <Select value={role} onValueChange={(v) => { setRole(v as UserRole | 'all'); setPage(1); }}>
          <SelectTrigger className="sm:w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All roles</SelectItem>
            <SelectItem value="donor">Donors</SelectItem>
            <SelectItem value="ngo">NGOs</SelectItem>
            <SelectItem value="admin">Admins</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {isError ? (
        <ErrorState onRetry={refetch} />
      ) : isLoading ? (
        <TableSkeleton />
      ) : rows.length === 0 ? (
        <EmptyState icon={<UsersIcon className="h-7 w-7" />} title="No users found" description="Try adjusting your search or filters." />
      ) : (
        <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-soft">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Location</TableHead>
                <TableHead>Joined</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pageRows.map((u) => (
                <TableRow key={u.id}>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <Avatar className="h-9 w-9">
                        {u.avatar && <AvatarImage src={u.avatar} alt={u.full_name} />}
                        <AvatarFallback className="text-xs font-bold">{initials(u.full_name)}</AvatarFallback>
                      </Avatar>
                      <div className="min-w-0">
                        <p className="truncate text-sm font-medium">{u.full_name}</p>
                        <p className="truncate text-xs text-muted-foreground">{u.email}</p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className={`capitalize ${roleBadge[u.role]}`}>{u.role}</Badge>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">{[u.city, u.country].filter(Boolean).join(', ') || '—'}</TableCell>
                  <TableCell className="text-sm text-muted-foreground">{formatDate(u.created_at)}</TableCell>
                  <TableCell>
                    {u.is_suspended ? (
                      <Badge variant="outline" className="border-destructive/30 bg-destructive/10 text-destructive">Suspended</Badge>
                    ) : (
                      <Badge variant="outline" className="border-success/30 bg-success/10 text-success">Active</Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => setViewUser(u)}><Eye className="h-4 w-4" /></Button>
                      <Button
                        size="icon" variant="ghost" className="h-8 w-8"
                        onClick={() => suspendMutation.mutate({ id: u.id, suspended: !u.is_suspended })}
                        title={u.is_suspended ? 'Activate' : 'Suspend'}
                      >
                        {u.is_suspended ? <CheckCircle2 className="h-4 w-4 text-success" /> : <Ban className="h-4 w-4 text-warning" />}
                      </Button>
                      <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive" onClick={() => setConfirmDelete(u)}><Trash2 className="h-4 w-4" /></Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {rows.length > PAGE_SIZE && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">Page {page} of {totalPages}</p>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft className="h-4 w-4" /></Button>
            <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}><ChevronRight className="h-4 w-4" /></Button>
          </div>
        </div>
      )}

      {/* View user dialog */}
      <Dialog open={!!viewUser} onOpenChange={(open) => !open && setViewUser(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>User Profile</DialogTitle>
            <DialogDescription>Full details for this user.</DialogDescription>
          </DialogHeader>
          {viewUser && (
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <Avatar className="h-16 w-16">
                  {viewUser.avatar && <AvatarImage src={viewUser.avatar} alt={viewUser.full_name} />}
                  <AvatarFallback className="bg-primary/10 font-bold text-primary">{initials(viewUser.full_name)}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-lg font-bold">{viewUser.full_name}</p>
                  <p className="text-sm text-muted-foreground">{viewUser.email}</p>
                  <Badge variant="outline" className={`mt-1 capitalize ${roleBadge[viewUser.role]}`}>{viewUser.role}</Badge>
                </div>
              </div>
              <dl className="grid grid-cols-2 gap-4 text-sm">
                <div><dt className="text-muted-foreground">Phone</dt><dd className="font-medium">{viewUser.phone ?? '—'}</dd></div>
                <div><dt className="text-muted-foreground">City</dt><dd className="font-medium">{viewUser.city ?? '—'}</dd></div>
                <div><dt className="text-muted-foreground">State</dt><dd className="font-medium">{viewUser.state ?? '—'}</dd></div>
                <div><dt className="text-muted-foreground">Country</dt><dd className="font-medium">{viewUser.country ?? '—'}</dd></div>
                <div><dt className="text-muted-foreground">Joined</dt><dd className="font-medium">{formatDate(viewUser.created_at)}</dd></div>
                <div><dt className="text-muted-foreground">Status</dt><dd className="font-medium">{viewUser.is_suspended ? 'Suspended' : 'Active'}</dd></div>
              </dl>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!confirmDelete} onOpenChange={(open) => !open && setConfirmDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this user?</AlertDialogTitle>
            <AlertDialogDescription>
              “{confirmDelete?.full_name}” and all their donations will be permanently removed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={() => confirmDelete && deleteMutation.mutate(confirmDelete.id)}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
