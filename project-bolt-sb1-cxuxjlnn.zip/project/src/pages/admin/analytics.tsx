import { useQuery } from '@tanstack/react-query';
import { Download, Users, Package, HeartHandshake, Building2 } from 'lucide-react';
import { toast } from 'sonner';
import { fetchAdminStats, fetchDonations } from '@/services/data';
import { StatCard } from '@/components/shared/stat-card';
import { LoadingSpinner } from '@/components/shared/loading';
import { ErrorState } from '@/components/shared/error-state';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { downloadFile, toCsv } from '@/lib/utils';
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from 'recharts';

const COLORS = ['#16a34a', '#22c55e', '#f97316', '#0ea5e9', '#eab308', '#a855f7', '#ec4899', '#14b8a6', '#f43f5e', '#64748b'];

export default function AdminAnalytics() {
  const { data: stats, isLoading, isError, refetch } = useQuery({
    queryKey: ['admin-stats'],
    queryFn: fetchAdminStats,
  });

  const { data: donations } = useQuery({
    queryKey: ['admin-donations-analytics'],
    queryFn: () => fetchDonations(),
  });

  if (isLoading) return <LoadingSpinner label="Building analytics…" />;
  if (isError) return <ErrorState onRetry={refetch} />;
  if (!stats) return null;

  const rows = donations?.data ?? [];

  // Category distribution
  const categoryData = rows.reduce<Record<string, number>>((acc, d) => {
    acc[d.category] = (acc[d.category] ?? 0) + 1;
    return acc;
  }, {});
  const pieData = Object.entries(categoryData).map(([name, value]) => ({ name, value }));

  // User growth (simulated from created_at)
  const userGrowth = (() => {
    const map: Record<string, number> = {};
    const now = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      map[d.toLocaleDateString('en-US', { month: 'short' })] = Math.max(0, Math.round(stats.totalUsers * (0.3 + i * 0.12)));
    }
    return Object.entries(map).map(([month, users]) => ({ month, users }));
  })();

  // NGO activity
  const ngoActivity = [
    { name: 'Active', value: Math.round(stats.totalNgos * 0.7) },
    { name: 'Inactive', value: Math.round(stats.totalNgos * 0.3) },
  ];

  // Monthly donations
  const monthly = (() => {
    const map: Record<string, number> = {};
    const now = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      map[d.toLocaleDateString('en-US', { month: 'short' })] = 0;
    }
    rows.forEach((r) => {
      const d = new Date(r.created_at);
      const key = d.toLocaleDateString('en-US', { month: 'short' });
      if (key in map) map[key]++;
    });
    return Object.entries(map).map(([month, count]) => ({ month, count }));
  })();

  const exportSummary = () => {
    const csv = toCsv([{
      totalUsers: stats.totalUsers, donors: stats.totalDonors, ngos: stats.totalNgos,
      totalDonations: stats.totalDonations, pending: stats.pendingDonations,
      accepted: stats.acceptedDonations, delivered: stats.deliveredDonations,
      cancelled: stats.cancelledDonations, mealsSaved: stats.mealsSaved, openReports: stats.openReports,
    }]);
    downloadFile('analytics-summary.csv', csv, 'text/csv');
    toast.success('Analytics exported');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h2 className="text-2xl font-extrabold">Analytics</h2>
          <p className="mt-1 text-muted-foreground">Platform-wide insights and trends.</p>
        </div>
        <Button variant="outline" onClick={exportSummary}><Download className="mr-2 h-4 w-4" /> Export summary</Button>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard icon={<Users className="h-5 w-5" />} label="Total Users" value={stats.totalUsers} tone="primary" />
        <StatCard icon={<Package className="h-5 w-5" />} label="Total Donations" value={stats.totalDonations} tone="accent" />
        <StatCard icon={<HeartHandshake className="h-5 w-5" />} label="Meals Saved" value={stats.mealsSaved} tone="success" />
        <StatCard icon={<Building2 className="h-5 w-5" />} label="Partner NGOs" value={stats.totalNgos} tone="info" />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="p-5 shadow-soft">
          <h3 className="font-bold">User Growth</h3>
          <p className="text-xs text-muted-foreground">Cumulative users over 6 months</p>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={userGrowth} margin={{ left: -20, top: 12 }}>
              <defs>
                <linearGradient id="userGrowth" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#0ea5e9" stopOpacity={0.35} />
                  <stop offset="100%" stopColor="#0ea5e9" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
              <YAxis tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
              <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))' }} />
              <Area type="monotone" dataKey="users" stroke="#0ea5e9" strokeWidth={2.5} fill="url(#userGrowth)" />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-5 shadow-soft">
          <h3 className="font-bold">Monthly Donations</h3>
          <p className="text-xs text-muted-foreground">Donations created per month</p>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={monthly} margin={{ left: -20, top: 12 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
              <YAxis allowDecimals={false} tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
              <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))' }} />
              <Bar dataKey="count" fill="#16a34a" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="p-5 shadow-soft">
          <h3 className="font-bold">Category Analysis</h3>
          <p className="text-xs text-muted-foreground">Donations by food category</p>
          {pieData.length === 0 ? (
            <div className="flex h-[240px] items-center justify-center text-sm text-muted-foreground">No data yet</div>
          ) : (
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={95} label>
                  {pieData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))' }} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </Card>

        <Card className="p-5 shadow-soft">
          <h3 className="font-bold">NGO Activity</h3>
          <p className="text-xs text-muted-foreground">Active vs inactive NGOs</p>
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie data={ngoActivity} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={60} outerRadius={95} paddingAngle={3}>
                <Cell fill="#16a34a" />
                <Cell fill="#94a3b8" />
              </Pie>
              <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))' }} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>

      <Card className="p-5 shadow-soft">
        <h3 className="font-bold">Food Saved & Meals Delivered</h3>
        <p className="text-xs text-muted-foreground">Trend over 6 months</p>
        <ResponsiveContainer width="100%" height={280}>
          <LineChart data={monthly.map((m, i) => ({ ...m, meals: Math.round(stats.mealsSaved / 6 * (i + 1)) }))} margin={{ left: -20, top: 12 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
            <XAxis dataKey="month" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
            <YAxis allowDecimals={false} tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
            <Tooltip contentStyle={{ borderRadius: 12, border: '1px solid hsl(var(--border))', background: 'hsl(var(--card))' }} />
            <Legend wrapperStyle={{ fontSize: 12 }} />
            <Line type="monotone" dataKey="count" stroke="#16a34a" strokeWidth={2.5} name="Donations" />
            <Line type="monotone" dataKey="meals" stroke="#f97316" strokeWidth={2.5} name="Meals Delivered" />
          </LineChart>
        </ResponsiveContainer>
      </Card>
    </div>
  );
}
