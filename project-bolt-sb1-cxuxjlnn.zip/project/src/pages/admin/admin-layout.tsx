import { LayoutDashboard, Users, Package, Flag, BarChart3, Settings, Bell, User } from 'lucide-react';
import { DashboardShell, type NavItem } from '@/components/layouts/dashboard-shell';

const items: NavItem[] = [
  { to: '/admin', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/admin/users', label: 'Users', icon: Users },
  { to: '/admin/donations', label: 'Donations', icon: Package },
  { to: '/admin/reports', label: 'Reports', icon: Flag },
  { to: '/admin/analytics', label: 'Analytics', icon: BarChart3 },
  { to: '/admin/notifications', label: 'Notifications', icon: Bell },
  { to: '/admin/profile', label: 'Profile', icon: User },
  { to: '/admin/settings', label: 'Settings', icon: Settings },
];

export default function AdminLayout() {
  return <DashboardShell items={items} title="Admin Panel" accent="admin" />;
}
