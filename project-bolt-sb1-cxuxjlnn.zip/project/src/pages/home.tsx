import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowRight,
  HandPlatter,
  Search,
  Truck,
  ShieldCheck,
  Zap,
  BadgeCheck,
  Lock,
  Sprout,
  Utensils,
  HeartHandshake,
  Users,
  Building2,
  Trash2,
  Star,
  ChevronDown,
  Mail,
  Leaf,
  Apple,
  Carrot,
  Sandwich,
} from 'lucide-react';
import { useState } from 'react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { SectionHeading } from '@/components/shared/section-heading';
import { StatCard } from '@/components/shared/stat-card';
import { toast } from 'sonner';

const stats = [
  { icon: <Utensils className="h-5 w-5" />, label: 'Food Saved', value: '12,400 kg', tone: 'primary' as const },
  { icon: <HeartHandshake className="h-5 w-5" />, label: 'Meals Donated', value: '28,900', tone: 'accent' as const },
  { icon: <Users className="h-5 w-5" />, label: 'Registered Donors', value: '1,240', tone: 'info' as const },
  { icon: <Building2 className="h-5 w-5" />, label: 'Partner NGOs', value: '186', tone: 'success' as const },
];

const steps = [
  {
    icon: HandPlatter,
    title: 'Donate',
    desc: 'Restaurants, hotels, and households list surplus food in under a minute with photos and pickup details.',
  },
  {
    icon: Search,
    title: 'Match',
    desc: 'Verified NGOs and shelters discover nearby donations and accept the ones they can collect in time.',
  },
  {
    icon: Truck,
    title: 'Deliver',
    desc: 'Coordinate pickup, track live delivery status, and confirm meals reach people who need them.',
  },
];

const features = [
  { icon: Trash2, title: 'Food Waste Reduction', desc: 'Divert surplus food from landfills and turn it into meals for communities in need.' },
  { icon: Zap, title: 'Fast Pickup', desc: 'Real-time matching with nearby receivers ensures food is collected before it spoils.' },
  { icon: BadgeCheck, title: 'Verified NGOs', desc: 'Every receiving organization is identity-verified before they can accept donations.' },
  { icon: Lock, title: 'Secure Platform', desc: 'Row-level security, role-based access, and encrypted sessions protect every transaction.' },
];

const testimonials = [
  { name: 'Priya Sharma', role: 'Cafe Owner', quote: 'We used to throw away trays of food every night. Food Bridge turned that waste into 400 meals a week.', rating: 5 },
  { name: 'Marcus Lee', role: 'Shelter Coordinator', quote: 'The freshness badges and live status tracker make coordination effortless. Pickup has never been this smooth.', rating: 5 },
  { name: 'Aisha Khan', role: 'Event Caterer', quote: 'After large events, listing surplus food takes two minutes. Real families get fed instead of dumpsters.', rating: 5 },
];

const faqs = [
  { q: 'Who can donate food on Food Bridge?', a: 'Anyone with surplus food — restaurants, hotels, caterers, event organizers, bakeries, grocery stores, hostels, households, and individuals. Simply create a donor account and list your food.' },
  { q: 'How do I know the NGOs are legitimate?', a: 'Every NGO and receiver organization goes through an identity verification process before they can accept donations. Look for the verified badge on profiles.' },
  { q: 'Is there a cost to use Food Bridge?', a: 'No. Food Bridge is free for donors and receivers. Our mission is to reduce food waste and fight hunger, not to profit from generosity.' },
  { q: 'What kind of food can I donate?', a: 'Cooked food, raw ingredients, packaged items, bakery, fruits, vegetables, dairy, and groceries. Each listing includes food type, category, and expiry so receivers can judge freshness.' },
  { q: 'How is food safety handled?', a: 'Our AI Food Assistant provides shelf-life guidance, storage tips, and best pickup-time recommendations. Donors set expiry times and freshness badges flag food that must be collected soon.' },
  { q: 'Can I track my donations?', a: 'Yes. Every donation has a live status timeline — Created, Accepted, Preparing Pickup, Collected, On The Way, and Delivered — so you always know where your food is.' },
];

const floatingIcons = [Leaf, Apple, Carrot, Sandwich];

export default function Home() {
  const [email, setEmail] = useState('');

  const subscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    toast.success('Subscribed!', { description: 'You will receive updates about our fight against hunger.' });
    setEmail('');
  };

  return (
    <div className="overflow-hidden">
      {/* Hero */}
      <section className="relative gradient-hero">
        <div className="absolute inset-0 bg-grid opacity-[0.03] [mask-image:radial-gradient(60%_50%_at_50%_30%,black,transparent)]" />
        {floatingIcons.map((Icon, i) => (
          <motion.div
            key={i}
            className="absolute hidden text-primary/20 lg:block"
            style={{ top: `${15 + i * 18}%`, left: i % 2 === 0 ? '8%' : '82%' }}
            animate={{ y: [0, -16, 0] }}
            transition={{ duration: 6 + i, repeat: Infinity, ease: 'easeInOut' }}
          >
            <Icon className="h-12 w-12" />
          </motion.div>
        ))}

        <div className="container relative py-20 sm:py-28 lg:py-36">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="mx-auto max-w-4xl text-center"
          >
            <span className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-4 py-1.5 text-sm font-semibold text-primary">
              <Sprout className="h-4 w-4" /> Reducing waste. Fighting hunger.
            </span>
            <h1 className="mt-6 text-4xl font-extrabold tracking-tight text-balance sm:text-5xl lg:text-6xl">
              Bridge Surplus Food With{' '}
              <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                Those Who Need It
              </span>
            </h1>
            <p className="mx-auto mt-6 max-w-2xl text-lg leading-relaxed text-muted-foreground text-balance">
              Food Bridge connects restaurants, hotels, and households with NGOs, shelters, and people in need.
              Turn surplus food into meals in minutes — not landfill.
            </p>
            <div className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <Button asChild size="lg" className="gradient-primary text-white shadow-glow h-12 px-8 text-base">
                <Link to="/signup">
                  Donate Food <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="h-12 px-8 text-base">
                <Link to="/signup">
                  <Search className="mr-2 h-5 w-5" /> Find Food
                </Link>
              </Button>
            </div>
            <p className="mt-6 text-sm text-muted-foreground">Free to join. No fees. Real impact.</p>
          </motion.div>
        </div>
      </section>

      {/* Stats */}
      <section className="border-y border-border bg-card/40 py-14">
        <div className="container">
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            {stats.map((s, i) => (
              <StatCard key={s.label} icon={s.icon} label={s.label} value={s.value} tone={s.tone} delay={i * 0.08} />
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-20 sm:py-28">
        <div className="container">
          <SectionHeading
            eyebrow="How It Works"
            title="Three simple steps to save food"
            description="From surplus to served in a flow designed to be fast, safe, and transparent."
          />
          <div className="mt-14 grid gap-6 md:grid-cols-3">
            {steps.map((step, i) => (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-80px' }}
                transition={{ duration: 0.5, delay: i * 0.12 }}
                className="relative rounded-2xl border border-border bg-card p-7 shadow-soft"
              >
                <span className="absolute right-6 top-6 text-5xl font-extrabold text-primary/10">{i + 1}</span>
                <div className="flex h-12 w-12 items-center justify-center rounded-xl gradient-primary text-white shadow-glow">
                  <step.icon className="h-6 w-6" />
                </div>
                <h3 className="mt-5 text-xl font-bold">{step.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{step.desc}</p>
                {i < steps.length - 1 && (
                  <ArrowRight className="absolute -right-3 top-1/2 hidden h-6 w-6 -translate-y-1/2 text-border md:block" />
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="bg-card/40 py-20 sm:py-28">
        <div className="container">
          <SectionHeading
            eyebrow="Why Food Bridge"
            title="Built for trust, speed, and impact"
            description="Everything you need to donate confidently and receive reliably."
          />
          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {features.map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-80px' }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                className="group rounded-2xl border border-border bg-background p-6 shadow-soft transition-all hover:-translate-y-1 hover:shadow-glow"
              >
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary transition-colors group-hover:gradient-primary group-hover:text-white">
                  <f.icon className="h-5 w-5" />
                </div>
                <h3 className="mt-4 font-bold">{f.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 sm:py-28">
        <div className="container">
          <SectionHeading eyebrow="Testimonials" title="Loved by donors and receivers" />
          <div className="mt-14 grid gap-6 md:grid-cols-3">
            {testimonials.map((t, i) => (
              <motion.figure
                key={t.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-80px' }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                className="rounded-2xl border border-border bg-card p-6 shadow-soft"
              >
                <div className="flex gap-0.5">
                  {Array.from({ length: t.rating }).map((_, j) => (
                    <Star key={j} className="h-4 w-4 fill-accent text-accent" />
                  ))}
                </div>
                <blockquote className="mt-4 text-sm leading-relaxed text-muted-foreground">“{t.quote}”</blockquote>
                <figcaption className="mt-5 flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full gradient-primary text-sm font-bold text-white">
                    {t.name.split(' ').map((n) => n[0]).join('')}
                  </div>
                  <div>
                    <p className="text-sm font-bold">{t.name}</p>
                    <p className="text-xs text-muted-foreground">{t.role}</p>
                  </div>
                </figcaption>
              </motion.figure>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="bg-card/40 py-20 sm:py-28">
        <div className="container max-w-3xl">
          <SectionHeading eyebrow="FAQ" title="Questions, answered" />
          <Accordion type="single" collapsible className="mt-10 space-y-3">
            {faqs.map((faq, i) => (
              <AccordionItem
                key={i}
                value={`item-${i}`}
                className="rounded-xl border border-border bg-background px-5 shadow-soft"
              >
                <AccordionTrigger className="text-left text-base font-semibold hover:no-underline">
                  <span className="flex items-center gap-3">
                    <ChevronDown className="h-4 w-4 shrink-0 text-primary transition-transform" />
                    {faq.q}
                  </span>
                </AccordionTrigger>
                <AccordionContent className="text-sm leading-relaxed text-muted-foreground">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>

      {/* Newsletter CTA */}
      <section className="py-20 sm:py-28">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="relative overflow-hidden rounded-3xl gradient-primary p-8 text-center text-white shadow-glow sm:p-14"
          >
            <div className="absolute inset-0 bg-dots opacity-10" />
            <div className="relative">
              <ShieldCheck className="mx-auto h-10 w-10" />
              <h2 className="mt-4 text-3xl font-extrabold sm:text-4xl">Join the fight against hunger</h2>
              <p className="mx-auto mt-3 max-w-xl text-white/80">
                Get monthly impact reports, food-safety tips, and stories from donors and NGOs in your inbox.
              </p>
              <form onSubmit={subscribe} className="mx-auto mt-7 flex max-w-md flex-col gap-3 sm:flex-row">
                <Input
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="border-white/20 bg-white/10 text-white placeholder:text-white/60 focus-visible:ring-white"
                  aria-label="Email address"
                />
                <Button type="submit" variant="secondary" className="bg-white text-primary hover:bg-white/90">
                  <Mail className="mr-2 h-4 w-4" /> Subscribe
                </Button>
              </form>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
