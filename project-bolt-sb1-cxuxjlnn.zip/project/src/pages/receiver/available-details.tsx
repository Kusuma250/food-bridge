import { useParams, Link, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { ArrowLeft, HandPlatter, MapPin, Sparkles } from 'lucide-react';
import { toast } from 'sonner';
import * as Icons from 'lucide-react';
import { fetchDonationById, acceptDonation, fetchAcceptedByReceiver } from '@/services/data';
import { getRecommendationCards } from '@/services/ai-assistant';
import { useAuth } from '@/contexts/auth-context';
import { PageLoader } from '@/components/shared/loading';
import { ErrorState } from '@/components/shared/error-state';
import { StatusBadge } from '@/components/shared/status-badge';
import { DonationInfo } from '@/components/shared/donation-info';
import { ReportDialog } from '@/components/shared/report-dialog';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';

export default function AvailableDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: donation, isLoading, isError, refetch } = useQuery({
    queryKey: ['donation', id],
    queryFn: () => fetchDonationById(id!),
    enabled: !!id,
  });

  const { data: accepted } = useQuery({
    queryKey: ['accepted-by-receiver', user?.id],
    queryFn: () => fetchAcceptedByReceiver(user!.id),
    enabled: !!user,
  });

  const alreadyAccepted = accepted?.some((a) => a.donation_id === id);

  const acceptMutation = useMutation({
    mutationFn: () => acceptDonation(id!, user!.id),
    onSuccess: () => {
      toast.success('Donation accepted!', { description: 'Coordinate pickup with the donor. Check your accepted list.' });
      queryClient.invalidateQueries({ queryKey: ['available-donations'] });
      queryClient.invalidateQueries({ queryKey: ['accepted-by-receiver'] });
      queryClient.invalidateQueries({ queryKey: ['donation', id] });
      navigate('/dashboard/ngo/accepted');
    },
    onError: (e) => toast.error('Could not accept', { description: (e as Error).message }),
  });

  if (isLoading) return <PageLoader />;
  if (isError) return <ErrorState onRetry={refetch} />;
  if (!donation) return <ErrorState title="Donation not found" message="This donation may have been removed or already accepted." />;

  const recommendations = getRecommendationCards({
    category: donation.category,
    foodType: donation.food_type,
    expiryHours: donation.expiry_date ? (new Date(donation.expiry_date).getTime() - Date.now()) / 3600000 : undefined,
  });

  const isPending = donation.status === 'pending';

  return (
    <div className="space-y-6">
      <Button asChild variant="ghost" size="sm">
        <Link to="/dashboard/ngo/available"><ArrowLeft className="mr-2 h-4 w-4" /> Back to available</Link>
      </Button>

      {/* Header */}
      <div className="flex flex-col gap-4 rounded-2xl border border-border bg-card p-6 shadow-soft sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-start gap-4">
          <div className="h-16 w-16 shrink-0 overflow-hidden rounded-xl bg-muted">
            {donation.image_url && <img src={donation.image_url} alt={donation.food_name} className="h-full w-full object-cover" />}
          </div>
          <div>
            <h1 className="text-2xl font-extrabold">{donation.food_name}</h1>
            <div className="mt-2 flex flex-wrap items-center gap-2">
              <StatusBadge status={donation.status} />
              <span className="text-sm text-muted-foreground">{donation.quantity} {donation.unit}</span>
            </div>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          {isPending ? (
            <Button
              size="lg"
              className="gradient-primary text-white shadow-glow"
              disabled={acceptMutation.isPending}
              onClick={() => acceptMutation.mutate()}
            >
              <HandPlatter className="mr-2 h-5 w-5" />
              {acceptMutation.isPending ? 'Accepting…' : 'Accept donation'}
            </Button>
          ) : alreadyAccepted ? (
            <Button asChild size="lg" variant="outline">
              <Link to="/dashboard/ngo/accepted">View in accepted</Link>
            </Button>
          ) : (
            <span className="rounded-lg bg-muted px-4 py-2 text-sm font-semibold text-muted-foreground">
              Already accepted by another NGO
            </span>
          )}
          <ReportDialog donationId={donation.id} />
        </div>
      </div>

      {/* Gallery */}
      {donation.image_url && (
        <Card className="overflow-hidden shadow-soft">
          <img src={donation.image_url} alt={donation.food_name} className="h-72 w-full object-cover sm:h-96" />
        </Card>
      )}

      <DonationInfo donation={donation} />

      {/* AI assistant */}
      <Card className="p-6 shadow-soft">
        <div className="flex items-center gap-2">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl gradient-accent text-white">
            <Sparkles className="h-5 w-5" />
          </span>
          <div>
            <h3 className="font-bold">AI Food Assistant</h3>
            <p className="text-xs text-muted-foreground">Safety and handling guidance for this donation</p>
          </div>
        </div>
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {recommendations.map((r, i) => {
            const Icon = (Icons[r.icon as keyof typeof Icons] ?? Icons.Sparkles) as React.ComponentType<{ className?: string }>;
            const toneCls = {
              info: 'bg-info/10 text-info',
              success: 'bg-success/10 text-success',
              warning: 'bg-warning/10 text-warning',
            }[r.tone];
            return (
              <div key={i} className="rounded-xl border border-border p-3">
                <div className="flex items-center gap-2">
                  <span className={cn('flex h-8 w-8 items-center justify-center rounded-lg', toneCls)}>
                    <Icon className="h-4 w-4" />
                  </span>
                  <p className="text-sm font-bold">{r.title}</p>
                </div>
                <p className="mt-2 text-xs leading-relaxed text-muted-foreground">{r.body}</p>
              </div>
            );
          })}
        </div>
      </Card>

      {/* Maps placeholder */}
      <Card className="overflow-hidden shadow-soft">
        <div className="p-6">
          <h3 className="font-bold">Pickup Location</h3>
          <p className="mt-1 flex items-center gap-2 text-sm text-muted-foreground">
            <MapPin className="h-4 w-4 text-primary" /> {donation.pickup_address}
          </p>
        </div>
        <div className="relative flex h-56 items-center justify-center bg-gradient-to-br from-primary/10 to-accent/10">
          <div className="bg-grid absolute inset-0 opacity-10" />
          <div className="relative flex flex-col items-center gap-2 text-center">
            <MapPin className="h-10 w-10 text-primary" />
            <a
              href={`https://maps.google.com/?q=${encodeURIComponent(donation.pickup_address)}`}
              target="_blank"
              rel="noreferrer"
              className="rounded-lg gradient-primary px-4 py-2 text-sm font-semibold text-white shadow-glow"
            >
              Get directions
            </a>
          </div>
        </div>
      </Card>
    </div>
  );
}
