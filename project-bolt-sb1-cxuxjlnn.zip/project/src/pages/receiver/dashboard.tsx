import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { Search, CheckCircle2, Package, MapPin, ArrowRight, Truck } from 'lucide-react';
import { useAuth } from '@/contexts/auth-context';
import { fetchAvailableDonations, fetchAcceptedByReceiver } from '@/services/data';
import { StatCard } from '@/components/shared/stat-card';
import { DonationCard } from '@/components/shared/donation-card';
import { EmptyState } from '@/components/shared/empty-state';
import { ErrorState } from '@/components/shared/error-state';
import { LoadingSpinner } from '@/components/shared/loading';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { StatusBadge } from '@/components/shared/status-badge';
import { formatDate } from '@/lib/utils';

export default function ReceiverDashboard() {
  const { user } = useAuth();

  const { data: available, isLoading: availLoading, isError, refetch } = useQuery({
    queryKey: ['available-donations'],
    queryFn: () => fetchAvailableDonations(),
  });

  const { data: accepted } = useQuery({
    queryKey: ['accepted-by-receiver', user?.id],
    queryFn: () => fetchAcceptedByReceiver(user!.id),
    enabled: !!user,
  });

  const recent = (available ?? []).slice(0, 4);
  const activeAccepted = (accepted ?? []).filter((a) => a.delivery_status !== 'delivered' && a.delivery_status !== 'cancelled');

  return (
    <div className="space-y-8">
      <div className="flex flex-col items-start justify-between gap-4 rounded-2xl gradient-accent p-6 text-white shadow-glow sm:flex-row sm:items-center">
        <div>
          <h2 className="text-2xl font-extrabold">Welcome back!</h2>
          <p className="mt-1 text-white/80">Find surplus food near you and feed your community.</p>
        </div>
        <Button asChild variant="secondary" className="bg-white text-accent hover:bg-white/90">
          <Link to="/dashboard/ngo/available">
            <Search className="mr-2 h-4 w-4" /> Browse food
          </Link>
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard icon={<Search className="h-5 w-5" />} label="Available Now" value={available?.length ?? 0} tone="primary" delay={0} />
        <StatCard icon={<Truck className="h-5 w-5" />} label="Active Pickups" value={activeAccepted.length} tone="accent" delay={0.08} />
        <StatCard icon={<CheckCircle2 className="h-5 w-5" />} label="Completed" value={(accepted ?? []).filter((a) => a.delivery_status === 'delivered').length} tone="success" delay={0.16} />
        <StatCard icon={<Package className="h-5 w-5" />} label="Total Accepted" value={accepted?.length ?? 0} tone="info" delay={0.24} />
      </div>

      {/* Active pickups */}
      {activeAccepted.length > 0 && (
        <div>
          <h3 className="mb-4 text-lg font-bold">Active Pickups</h3>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {activeAccepted.map((a) => (
              <Card key={a.id} className="p-4 shadow-soft">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="truncate font-bold">{a.donation?.food_name}</p>
                    <p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
                      <MapPin className="h-3 w-3" /> {a.donation?.pickup_address}
                    </p>
                  </div>
                  <StatusBadge status={a.donation?.status ?? 'accepted'} />
                </div>
                <div className="mt-3 flex items-center justify-between">
                  <span className="text-xs text-muted-foreground">{formatDate(a.created_at)}</span>
                  <Button asChild size="sm" variant="outline">
                    <Link to={`/dashboard/ngo/accepted`}>Track <ArrowRight className="ml-1 h-3 w-3" /></Link>
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Available */}
      <div>
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-lg font-bold">Fresh Nearby</h3>
          <Button asChild variant="ghost" size="sm">
            <Link to="/dashboard/ngo/available">
              View all <ArrowRight className="ml-1 h-4 w-4" />
            </Link>
          </Button>
        </div>
        {isError ? (
          <ErrorState onRetry={refetch} />
        ) : availLoading ? (
          <LoadingSpinner />
        ) : recent.length === 0 ? (
          <EmptyState
            icon={<Search className="h-7 w-7" />}
            title="No donations available"
            description="New donations appear here as soon as donors list surplus food. Check back soon!"
            action={<Button asChild className="gradient-primary text-white"><Link to="/dashboard/ngo/available">Browse food</Link></Button>}
          />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {recent.map((d, i) => (
              <DonationCard key={d.id} donation={d} to={`/dashboard/ngo/available/${d.id}`} index={i} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
