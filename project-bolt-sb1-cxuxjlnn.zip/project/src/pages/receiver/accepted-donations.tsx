import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { CheckCircle2, Package, Truck, MapPin, ArrowRight, ChevronRight } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/auth-context';
import { fetchAcceptedByReceiver, updateDeliveryStatus } from '@/services/data';
import type { DeliveryStatus } from '@/types';
import { DELIVERY_STATUS_STEPS } from '@/types';
import { EmptyState } from '@/components/shared/empty-state';
import { ErrorState } from '@/components/shared/error-state';
import { LoadingSpinner } from '@/components/shared/loading';
import { StatusBadge } from '@/components/shared/status-badge';
import { ReviewsSection } from '@/components/shared/reviews-section';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { cn, formatDate } from '@/lib/utils';

export default function AcceptedDonations() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data, isLoading, isError, refetch } = useQuery({
    queryKey: ['accepted-by-receiver', user?.id],
    queryFn: () => fetchAcceptedByReceiver(user!.id),
    enabled: !!user,
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, status }: { id: string; status: DeliveryStatus }) => updateDeliveryStatus(id, status),
    onSuccess: () => {
      toast.success('Status updated');
      queryClient.invalidateQueries({ queryKey: ['accepted-by-receiver'] });
    },
    onError: (e) => toast.error('Update failed', { description: (e as Error).message }),
  });

  if (isLoading) return <LoadingSpinner label="Loading your accepted donations…" />;
  if (isError) return <ErrorState onRetry={refetch} />;

  const rows = data ?? [];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-extrabold">Accepted Donations</h2>
        <p className="mt-1 text-muted-foreground">Track and update the status of your pickups.</p>
      </div>

      {rows.length === 0 ? (
        <EmptyState
          icon={<CheckCircle2 className="h-7 w-7" />}
          title="No accepted donations yet"
          description="Browse available donations and accept the ones you can collect."
          action={<Button asChild className="gradient-primary text-white"><Link to="/dashboard/ngo/available">Browse food</Link></Button>}
        />
      ) : (
        <div className="space-y-4">
          {rows.map((a) => {
            const donation = a.donation;
            if (!donation) return null;
            const stepIndex = DELIVERY_STATUS_STEPS.findIndex((s) => s.value === a.delivery_status);
            const nextStep = DELIVERY_STATUS_STEPS[stepIndex + 1];
            const isDone = a.delivery_status === 'delivered';
            const isCancelled = a.delivery_status === 'cancelled';

            return (
              <Card key={a.id} className="overflow-hidden shadow-soft">
                <div className="grid gap-0 lg:grid-cols-3">
                  {/* Left: donation info */}
                  <div className="border-b border-border p-5 lg:border-b-0 lg:border-r">
                    <div className="flex items-start gap-3">
                      <div className="h-14 w-14 shrink-0 overflow-hidden rounded-xl bg-muted">
                        {donation.image_url && <img src={donation.image_url} alt={donation.food_name} className="h-full w-full object-cover" />}
                      </div>
                      <div className="min-w-0">
                        <p className="truncate font-bold">{donation.food_name}</p>
                        <p className="text-xs text-muted-foreground">{donation.quantity} {donation.unit}</p>
                        <div className="mt-1.5"><StatusBadge status={donation.status} /></div>
                      </div>
                    </div>
                    <div className="mt-4 space-y-1.5 text-xs text-muted-foreground">
                      <p className="flex items-center gap-2"><MapPin className="h-3.5 w-3.5 text-primary" /> {donation.pickup_address}</p>
                      <p className="flex items-center gap-2"><Package className="h-3.5 w-3.5 text-primary" /> Accepted {formatDate(a.created_at)}</p>
                    </div>
                    <Button asChild variant="ghost" size="sm" className="mt-3 -ml-2">
                      <Link to={`/dashboard/ngo/available/${donation.id}`}>View details <ArrowRight className="ml-1 h-3 w-3" /></Link>
                    </Button>
                  </div>

                  {/* Middle: status timeline */}
                  <div className="border-b border-border p-5 lg:border-b-0 lg:border-r">
                    <p className="text-sm font-bold">Live Status</p>
                    <div className="mt-4 space-y-3">
                      {DELIVERY_STATUS_STEPS.map((step, i) => {
                        const done = !isCancelled && i < stepIndex;
                        const active = !isCancelled && i === stepIndex;
                        return (
                          <div key={step.value} className="flex items-center gap-2.5">
                            <span className={cn(
                              'flex h-6 w-6 items-center justify-center rounded-full text-[10px] font-bold',
                              done && 'bg-primary text-primary-foreground',
                              active && 'border-2 border-primary text-primary',
                              !done && !active && 'border border-border text-muted-foreground',
                              isCancelled && 'border border-destructive text-destructive'
                            )}>
                              {done ? '✓' : i + 1}
                            </span>
                            <span className={cn('text-sm', !done && !active && 'text-muted-foreground', isCancelled && 'text-muted-foreground line-through')}>
                              {step.label}
                            </span>
                            {active && <ChevronRight className="ml-auto h-4 w-4 text-primary" />}
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Right: actions */}
                  <div className="p-5">
                    <p className="text-sm font-bold">Update Status</p>
                    {isDone ? (
                      <div className="mt-4 flex items-center gap-2 rounded-xl border border-success/30 bg-success/5 p-3 text-sm text-success">
                        <CheckCircle2 className="h-4 w-4" /> Delivered successfully
                      </div>
                    ) : isCancelled ? (
                      <div className="mt-4 text-sm text-muted-foreground">This pickup was cancelled.</div>
                    ) : (
                      <>
                        <p className="mt-1 text-xs text-muted-foreground">Move to the next stage of delivery</p>
                        <Select
                          value={a.delivery_status}
                          onValueChange={(v) => updateMutation.mutate({ id: a.id, status: v as DeliveryStatus })}
                        >
                          <SelectTrigger className="mt-3"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {DELIVERY_STATUS_STEPS.map((s) => (
                              <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                            ))}
                            <SelectItem value="cancelled">Cancel pickup</SelectItem>
                          </SelectContent>
                        </Select>
                        {nextStep && (
                          <Button
                            className="mt-3 w-full gradient-primary text-white"
                            size="sm"
                            disabled={updateMutation.isPending}
                            onClick={() => updateMutation.mutate({ id: a.id, status: nextStep.value })}
                          >
                            <Truck className="mr-2 h-4 w-4" /> Mark as {nextStep.label}
                          </Button>
                        )}
                      </>
                    )}
                  </div>
                </div>

                {/* Reviews (only when delivered) */}
                {isDone && donation.donor && (
                  <div className="border-t border-border p-5">
                    <ReviewsSection
                      donationId={donation.id}
                      revieweeId={donation.donor_id}
                      revieweeName={donation.donor.full_name}
                      canReview={donation.donor_id !== user?.id}
                    />
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
