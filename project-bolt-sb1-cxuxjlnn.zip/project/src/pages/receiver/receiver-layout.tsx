import { LayoutDashboard, Search, CheckCircle2, Bell, User, Settings } from 'lucide-react';
import { DashboardShell, type NavItem } from '@/components/layouts/dashboard-shell';

const items: NavItem[] = [
  { to: '/dashboard/ngo', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/dashboard/ngo/available', label: 'Available Donations', icon: Search },
  { to: '/dashboard/ngo/accepted', label: 'Accepted', icon: CheckCircle2 },
  { to: '/dashboard/ngo/notifications', label: 'Notifications', icon: Bell },
  { to: '/dashboard/ngo/profile', label: 'Profile', icon: User },
  { to: '/dashboard/ngo/settings', label: 'Settings', icon: Settings },
];

export default function ReceiverLayout() {
  return <DashboardShell items={items} title="NGO Dashboard" accent="ngo" />;
}
