import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Eye, EyeOff, User, Mail, Lock, Phone, HandPlatter, Building2, UserPlus, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';
import { signUpSchema, type SignUpValues } from '@/lib/validations';
import { useAuth } from '@/contexts/auth-context';
import { AuthLayout } from './auth-layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { cn } from '@/lib/utils';
import type { UserRole } from '@/types';

const roleOptions: { value: UserRole; label: string; desc: string; icon: typeof HandPlatter }[] = [
  { value: 'donor', label: 'Donor', desc: 'I have surplus food to donate', icon: HandPlatter },
  { value: 'ngo', label: 'NGO / Receiver', desc: 'I receive food for my community', icon: Building2 },
];

export default function Signup() {
  const { signUp } = useAuth();
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const form = useForm<SignUpValues>({
    resolver: zodResolver(signUpSchema),
    defaultValues: {
      full_name: '',
      email: '',
      password: '',
      confirmPassword: '',
      phone: '',
      role: 'donor',
      agreeTerms: false as unknown as true,
    },
  });

  const onSubmit = async (values: SignUpValues) => {
    const { error } = await signUp({
      email: values.email,
      password: values.password,
      fullName: values.full_name,
      phone: values.phone,
      role: values.role,
    });
    if (error) {
      toast.error('Sign up failed', { description: error });
      return;
    }
    toast.success('Account created!', { description: 'Welcome to Food Bridge. Redirecting to your dashboard…' });
    navigate(`/dashboard/${values.role}`);
  };

  return (
    <AuthLayout title="Create your account" subtitle="Join Food Bridge and start making an impact today.">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
          <FormField
            control={form.control}
            name="full_name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Full Name</FormLabel>
                <FormControl>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input className="pl-9" placeholder="Jane Doe" {...field} />
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Email</FormLabel>
                <FormControl>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input type="email" className="pl-9" placeholder="you@example.com" {...field} />
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="phone"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Phone Number</FormLabel>
                <FormControl>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input className="pl-9" placeholder="+1 555 000 1234" {...field} />
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="role"
            render={({ field }) => (
              <FormItem>
                <FormLabel>I am a…</FormLabel>
                <div className="grid grid-cols-2 gap-3">
                  {roleOptions.map((opt) => {
                    const active = field.value === opt.value;
                    return (
                      <button
                        key={opt.value}
                        type="button"
                        onClick={() => field.onChange(opt.value)}
                        className={cn(
                          'flex flex-col items-start gap-2 rounded-xl border-2 p-4 text-left transition-all',
                          active
                            ? 'border-primary bg-primary/5 shadow-glow'
                            : 'border-border bg-background hover:border-primary/40'
                        )}
                      >
                        <span className={cn('flex h-9 w-9 items-center justify-center rounded-lg', active ? 'gradient-primary text-white' : 'bg-muted text-muted-foreground')}>
                          <opt.icon className="h-4 w-4" />
                        </span>
                        <span className="text-sm font-bold">{opt.label}</span>
                        <span className="text-xs text-muted-foreground">{opt.desc}</span>
                      </button>
                    );
                  })}
                </div>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="grid gap-4 sm:grid-cols-2">
            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Password</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input type={showPassword ? 'text' : 'password'} className="px-9" placeholder="••••••••" {...field} />
                      <button type="button" onClick={() => setShowPassword((v) => !v)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground" aria-label="Toggle password">
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="confirmPassword"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Confirm Password</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                      <Input type={showConfirm ? 'text' : 'password'} className="px-9" placeholder="••••••••" {...field} />
                      <button type="button" onClick={() => setShowConfirm((v) => !v)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground" aria-label="Toggle password">
                        {showConfirm ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="agreeTerms"
            render={({ field }) => (
              <FormItem className="flex flex-row items-start gap-2.5 space-y-0">
                <FormControl>
                  <Checkbox checked={field.value} onCheckedChange={field.onChange} />
                </FormControl>
                <div className="space-y-1">
                  <FormLabel className="text-sm font-normal leading-snug text-muted-foreground">
                    I agree to the{' '}
                    <Link to="/terms" className="font-medium text-primary hover:underline">Terms</Link> and{' '}
                    <Link to="/privacy" className="font-medium text-primary hover:underline">Privacy Policy</Link>.
                  </FormLabel>
                  <FormMessage />
                </div>
              </FormItem>
            )}
          />

          <Button type="submit" className="w-full gradient-primary text-white shadow-glow" disabled={form.formState.isSubmitting}>
            <UserPlus className="mr-2 h-4 w-4" />
            {form.formState.isSubmitting ? 'Creating account…' : 'Create account'}
          </Button>
        </form>
      </Form>

      <p className="mt-6 flex items-center justify-center gap-2 text-xs text-muted-foreground">
        <CheckCircle2 className="h-3.5 w-3.5 text-primary" /> No credit card. Free forever.
      </p>

      <p className="mt-4 text-center text-sm text-muted-foreground">
        Already have an account?{' '}
        <Link to="/login" className="font-semibold text-primary hover:underline">Sign in</Link>
      </p>
    </AuthLayout>
  );
}
