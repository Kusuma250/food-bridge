import { Link, Navigate, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import type { ReactNode } from 'react';
import { Sprout, ShieldCheck, HeartHandshake, TrendingUp } from 'lucide-react';
import { Logo } from '@/components/shared/logo';
import { ThemeToggle } from '@/components/shared/theme-toggle';
import { useAuth } from '@/contexts/auth-context';

const highlights = [
  { icon: ShieldCheck, title: 'Verified & secure', desc: 'Every NGO is identity-checked and sessions are encrypted.' },
  { icon: TrendingUp, title: 'Real impact tracking', desc: 'Live status timelines from donation to delivery.' },
  { icon: HeartHandshake, title: 'Free forever', desc: 'No fees for donors or receivers. Just generosity.' },
];

export function AuthLayout({
  children,
  title,
  subtitle,
  side = 'left',
}: {
  children: ReactNode;
  title: string;
  subtitle: string;
  side?: 'left' | 'right';
}) {
  const { user, loading } = useAuth();
  const location = useLocation();
  const from = (location.state as { from?: string })?.from;

  if (!loading && user) {
    return <Navigate to={from ?? '/'} replace />;
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      {/* Form side */}
      <div
        className={`flex flex-col px-6 py-8 sm:px-12 ${side === 'right' ? 'order-2 lg:order-2' : 'order-1 lg:order-1'}`}
      >
        <div className="flex items-center justify-between">
          <Logo />
          <ThemeToggle />
        </div>
        <div className="flex flex-1 items-center justify-center py-10">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
            className="w-full max-w-md"
          >
            <h1 className="text-3xl font-extrabold tracking-tight">{title}</h1>
            <p className="mt-2 text-muted-foreground">{subtitle}</p>
            <div className="mt-8">{children}</div>
          </motion.div>
        </div>
        <p className="text-center text-sm text-muted-foreground">
          By continuing you agree to our{' '}
          <Link to="/terms" className="font-medium text-primary hover:underline">Terms</Link> &{' '}
          <Link to="/privacy" className="font-medium text-primary hover:underline">Privacy Policy</Link>.
        </p>
      </div>

      {/* Brand side */}
      <div className="relative hidden overflow-hidden gradient-primary lg:block">
        <div className="absolute inset-0 bg-dots opacity-10" />
        <div className="relative flex h-full flex-col justify-center px-12 text-white">
          <motion.div
            initial={{ opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-md"
          >
            <Sprout className="h-12 w-12" />
            <h2 className="mt-6 text-4xl font-extrabold leading-tight">
              Every meal saved is a person fed.
            </h2>
            <p className="mt-4 text-white/80">
              Join thousands of donors and NGOs bridging the gap between surplus food and hunger.
            </p>
            <ul className="mt-10 space-y-5">
              {highlights.map((h) => (
                <li key={h.title} className="flex gap-4">
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white/15">
                    <h.icon className="h-5 w-5" />
                  </span>
                  <div>
                    <p className="font-bold">{h.title}</p>
                    <p className="text-sm text-white/75">{h.desc}</p>
                  </div>
                </li>
              ))}
            </ul>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
