import { Link } from 'react-router-dom';
import { MailCheck, ArrowLeft, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { AuthLayout } from './auth-layout';
import { useAuth } from '@/contexts/auth-context';
import { useState } from 'react';
import { supabase } from '@/services/supabase';
import { toast } from 'sonner';

export default function VerifyEmail() {
  const { user, signOut } = useAuth();
  const [sending, setSending] = useState(false);

  const resend = async () => {
    if (!user) {
      toast.error('Sign in first to resend the verification email.');
      return;
    }
    setSending(true);
    const { error } = await supabase.auth.resend({ type: 'signup', email: user.email! });
    setSending(false);
    if (error) toast.error('Could not resend', { description: error.message });
    else toast.success('Verification email resent');
  };

  return (
    <AuthLayout title="Verify your email" subtitle="We sent a verification link to your inbox to confirm your account.">
      <div className="rounded-2xl border border-border bg-card p-6 text-center shadow-soft">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary">
          <MailCheck className="h-7 w-7" />
        </div>
        <h2 className="mt-4 text-lg font-bold">Almost there!</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Click the link in your email to verify your account. Once verified, you will have full access to Food Bridge.
        </p>
        <div className="mt-6 space-y-3">
          <Button onClick={resend} variant="outline" className="w-full" disabled={sending}>
            <RefreshCw className={`mr-2 h-4 w-4 ${sending ? 'animate-spin' : ''}`} />
            {sending ? 'Sending…' : 'Resend verification email'}
          </Button>
          <Button asChild variant="ghost" className="w-full" onClick={() => signOut()}>
            <Link to="/login">
              <ArrowLeft className="mr-2 h-4 w-4" /> Back to sign in
            </Link>
          </Button>
        </div>
      </div>
    </AuthLayout>
  );
}
