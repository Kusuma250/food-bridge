import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Twitter, Instagram, Linkedin, Send } from 'lucide-react';
import { toast } from 'sonner';
import { contactSchema, type ContactValues } from '@/lib/validations';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { SectionHeading } from '@/components/shared/section-heading';

const contactInfo = [
  { icon: Mail, label: 'Email', value: 'hello@foodbridge.org', href: 'mailto:hello@foodbridge.org' },
  { icon: Phone, label: 'Phone', value: '+1 (800) 555-0199', href: 'tel:+18005550199' },
  { icon: MapPin, label: 'Address', value: '123 Green Avenue, Impact City', href: '#' },
];

const socials = [
  { icon: Twitter, label: 'Twitter', href: '#' },
  { icon: Instagram, label: 'Instagram', href: '#' },
  { icon: Linkedin, label: 'LinkedIn', href: '#' },
];

export default function Contact() {
  const form = useForm<ContactValues>({
    resolver: zodResolver(contactSchema),
    defaultValues: { name: '', email: '', subject: '', message: '' },
  });

  const onSubmit = (values: ContactValues) => {
    toast.success('Message sent!', { description: `Thanks ${values.name.split(' ')[0]}, we will reply within 24 hours.` });
    form.reset();
  };

  return (
    <div className="overflow-hidden">
      <section className="gradient-hero py-20 sm:py-28">
        <div className="container">
          <SectionHeading
            eyebrow="Contact Us"
            title="We would love to hear from you"
            description="Questions, partnership ideas, or press inquiries — reach out and our team will respond within 24 hours."
          />
        </div>
      </section>

      <section className="py-20">
        <div className="container grid gap-8 lg:grid-cols-2">
          {/* Form */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="rounded-2xl border border-border bg-card p-6 shadow-soft sm:p-8"
          >
            <h2 className="text-xl font-bold">Send a message</h2>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="mt-6 space-y-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Your name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="you@example.com" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <FormField
                  control={form.control}
                  name="subject"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Subject</FormLabel>
                      <FormControl>
                        <Input placeholder="How can we help?" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Message</FormLabel>
                      <FormControl>
                        <Textarea rows={5} placeholder="Tell us more…" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" className="w-full gradient-primary text-white shadow-glow" disabled={form.formState.isSubmitting}>
                  <Send className="mr-2 h-4 w-4" />
                  {form.formState.isSubmitting ? 'Sending…' : 'Send message'}
                </Button>
              </form>
            </Form>
          </motion.div>

          {/* Info + map */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="space-y-6"
          >
            <div className="rounded-2xl border border-border bg-card p-6 shadow-soft">
              <h2 className="text-xl font-bold">Contact details</h2>
              <ul className="mt-5 space-y-4">
                {contactInfo.map((c) => (
                  <li key={c.label}>
                    <a
                      href={c.href}
                      className="flex items-start gap-3 rounded-xl p-3 transition-colors hover:bg-accent/5"
                    >
                      <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
                        <c.icon className="h-5 w-5" />
                      </span>
                      <div>
                        <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{c.label}</p>
                        <p className="text-sm font-medium">{c.value}</p>
                      </div>
                    </a>
                  </li>
                ))}
              </ul>
              <div className="mt-5 flex gap-2 border-t border-border pt-5">
                {socials.map((s) => (
                  <a
                    key={s.label}
                    href={s.href}
                    aria-label={s.label}
                    className="flex h-9 w-9 items-center justify-center rounded-lg border border-border text-muted-foreground transition-colors hover:border-primary hover:bg-primary/10 hover:text-primary"
                  >
                    <s.icon className="h-4 w-4" />
                  </a>
                ))}
              </div>
            </div>

            <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-soft">
              <div className="relative flex h-64 items-center justify-center bg-gradient-to-br from-primary/10 to-accent/10">
                <div className="bg-grid absolute inset-0 opacity-10" />
                <div className="relative flex flex-col items-center gap-2 text-center">
                  <MapPin className="h-10 w-10 text-primary" />
                  <p className="font-bold">Food Bridge HQ</p>
                  <p className="text-sm text-muted-foreground">123 Green Avenue, Impact City</p>
                  <a
                    href="https://maps.google.com/?q=123+Green+Avenue+Impact+City"
                    target="_blank"
                    rel="noreferrer"
                    className="mt-2 text-sm font-semibold text-primary hover:underline"
                  >
                    Open in Google Maps
                  </a>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
