import { Link } from 'react-router-dom';
import { Ban, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Logo } from '@/components/shared/logo';
import { useAuth } from '@/contexts/auth-context';
import { useNavigate } from 'react-router-dom';

export default function Suspended() {
  const { signOut } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  return (
    <div className="flex min-h-screen flex-col items-center justify-center px-6 text-center">
      <Logo />
      <div className="mt-8 flex h-20 w-20 items-center justify-center rounded-3xl bg-warning/10 text-warning">
        <Ban className="h-9 w-9" />
      </div>
      <h1 className="mt-6 text-3xl font-extrabold">Account suspended</h1>
      <p className="mt-2 max-w-md text-muted-foreground">
        Your account has been suspended by an administrator. Please contact support if you believe this is a mistake.
      </p>
      <div className="mt-8 flex gap-3">
        <Button asChild variant="outline">
          <Link to="/contact">Contact support</Link>
        </Button>
        <Button variant="destructive" onClick={handleSignOut}>
          <LogOut className="mr-2 h-4 w-4" /> Sign out
        </Button>
      </div>
    </div>
  );
}
