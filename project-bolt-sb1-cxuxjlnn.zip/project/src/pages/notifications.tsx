import { Link } from 'react-router-dom';
import { Bell, CheckCheck, Trash2, Inbox } from 'lucide-react';
import { useNotifications } from '@/hooks/use-notifications';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { EmptyState } from '@/components/shared/empty-state';
import { LoadingSpinner } from '@/components/shared/loading';
import { timeAgo, cn } from '@/lib/utils';

export default function Notifications() {
  const { notifications, unreadCount, loading, markRead, markAllRead, remove } = useNotifications();

  return (
    <div className="space-y-6">
      <div className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h2 className="text-2xl font-extrabold">Notifications</h2>
          <p className="mt-1 text-muted-foreground">{unreadCount} unread of {notifications.length}</p>
        </div>
        {unreadCount > 0 && (
          <Button variant="outline" size="sm" onClick={markAllRead}>
            <CheckCheck className="mr-2 h-4 w-4" /> Mark all as read
          </Button>
        )}
      </div>

      {loading ? (
        <LoadingSpinner />
      ) : notifications.length === 0 ? (
        <EmptyState icon={<Inbox className="h-7 w-7" />} title="No notifications" description="You will be notified here when donations are accepted, reviewed, or reported." />
      ) : (
        <Card className="divide-y divide-border p-0 shadow-soft">
          {notifications.map((n) => (
            <div
              key={n.id}
              className={cn('group flex items-start gap-3 p-4 transition-colors hover:bg-muted/30', !n.is_read && 'bg-primary/5')}
            >
              <span className={cn('mt-1 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg', n.is_read ? 'bg-muted text-muted-foreground' : 'bg-primary/10 text-primary')}>
                <Bell className="h-4 w-4" />
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <p className="font-semibold">{n.title}</p>
                  {!n.is_read && <span className="h-2 w-2 rounded-full bg-accent" />}
                </div>
                <p className="mt-0.5 text-sm text-muted-foreground">{n.message}</p>
                <div className="mt-2 flex items-center gap-3">
                  <span className="text-xs text-muted-foreground">{timeAgo(n.created_at)}</span>
                  {n.link && (
                    <Link to={n.link} onClick={() => markRead(n.id)} className="text-xs font-semibold text-primary hover:underline">
                      View
                    </Link>
                  )}
                </div>
              </div>
              <div className="flex flex-col gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                {!n.is_read && (
                  <button onClick={() => markRead(n.id)} className="rounded p-1.5 text-primary hover:bg-primary/10" aria-label="Mark read">
                    <CheckCheck className="h-4 w-4" />
                  </button>
                )}
                <button onClick={() => remove(n.id)} className="rounded p-1.5 text-destructive hover:bg-destructive/10" aria-label="Delete">
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </Card>
      )}
    </div>
  );
}
