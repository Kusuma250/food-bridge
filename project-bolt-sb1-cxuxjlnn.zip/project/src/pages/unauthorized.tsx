import { Link } from 'react-router-dom';
import { ShieldX, ArrowLeft, LogIn } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Logo } from '@/components/shared/logo';
import { useAuth } from '@/contexts/auth-context';

export default function Unauthorized() {
  const { profile } = useAuth();
  const dashboardPath = profile?.role === 'admin' ? '/admin' : `/dashboard/${profile?.role ?? 'donor'}`;
  return (
    <div className="flex min-h-screen flex-col items-center justify-center px-6 text-center">
      <Logo />
      <div className="mt-8 flex h-20 w-20 items-center justify-center rounded-3xl bg-destructive/10 text-destructive">
        <ShieldX className="h-9 w-9" />
      </div>
      <h1 className="mt-6 text-3xl font-extrabold">Access denied</h1>
      <p className="mt-2 max-w-md text-muted-foreground">
        You do not have permission to view this page. This area is restricted to specific account roles.
      </p>
      <div className="mt-8 flex gap-3">
        <Button asChild variant="outline">
          <Link to="/">
            <ArrowLeft className="mr-2 h-4 w-4" /> Home
          </Link>
        </Button>
        {profile ? (
          <Button asChild className="gradient-primary text-white">
            <Link to={dashboardPath}>Go to your dashboard</Link>
          </Button>
        ) : (
          <Button asChild className="gradient-primary text-white">
            <Link to="/login">
              <LogIn className="mr-2 h-4 w-4" /> Sign in
            </Link>
          </Button>
        )}
      </div>
    </div>
  );
}
