import { Bell, Moon, Sun, Globe, Shield, Mail, Smartphone } from 'lucide-react';
import { useTheme } from '@/contexts/theme-context';
import { useAuth } from '@/contexts/auth-context';
import { Card } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

export default function Settings() {
  const { theme, setTheme } = useTheme();
  const { profile } = useAuth();

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-extrabold">Settings</h2>
        <p className="mt-1 text-muted-foreground">Customize your Food Bridge experience.</p>
      </div>

      {/* Appearance */}
      <Card className="p-6 shadow-soft">
        <h3 className="flex items-center gap-2 font-bold"><Moon className="h-5 w-5 text-primary" /> Appearance</h3>
        <p className="mt-1 text-sm text-muted-foreground">Choose how Food Bridge looks to you.</p>
        <div className="mt-4 grid grid-cols-2 gap-3 sm:max-w-md">
          <button
            onClick={() => setTheme('light')}
            className={cn(
              'flex flex-col items-center gap-2 rounded-xl border-2 p-5 transition-all',
              theme === 'light' ? 'border-primary bg-primary/5 shadow-glow' : 'border-border hover:border-primary/40'
            )}
          >
            <Sun className="h-7 w-7 text-primary" />
            <span className="text-sm font-semibold">Light</span>
          </button>
          <button
            onClick={() => setTheme('dark')}
            className={cn(
              'flex flex-col items-center gap-2 rounded-xl border-2 p-5 transition-all',
              theme === 'dark' ? 'border-primary bg-primary/5 shadow-glow' : 'border-border hover:border-primary/40'
            )}
          >
            <Moon className="h-7 w-7 text-primary" />
            <span className="text-sm font-semibold">Dark</span>
          </button>
        </div>
      </Card>

      {/* Notification preferences */}
      <Card className="p-6 shadow-soft">
        <h3 className="flex items-center gap-2 font-bold"><Bell className="h-5 w-5 text-primary" /> Notification Preferences</h3>
        <p className="mt-1 text-sm text-muted-foreground">Choose which notifications you want to receive.</p>
        <div className="mt-4 space-y-1">
          <PrefRow icon={<Mail className="h-4 w-4" />} title="Email notifications" desc="Receive updates about your donations" defaultChecked onChange={() => toast.info('Preference saved')} />
          <PrefRow icon={<Bell className="h-4 w-4" />} title="In-app notifications" desc="Realtime alerts in your dashboard" defaultChecked onChange={() => toast.info('Preference saved')} />
          <PrefRow icon={<Smartphone className="h-4 w-4" />} title="Pickup reminders" desc="Get reminded before pickup times" defaultChecked onChange={() => toast.info('Preference saved')} />
        </div>
      </Card>

      {/* Language */}
      <Card className="p-6 shadow-soft">
        <h3 className="flex items-center gap-2 font-bold"><Globe className="h-5 w-5 text-primary" /> Language</h3>
        <p className="mt-1 text-sm text-muted-foreground">Food Bridge is currently available in English. More languages coming soon.</p>
        <Button variant="outline" disabled className="mt-4">English (US)</Button>
      </Card>

      {/* Security */}
      <Card className="p-6 shadow-soft">
        <h3 className="flex items-center gap-2 font-bold"><Shield className="h-5 w-5 text-primary" /> Security</h3>
        <div className="mt-4 space-y-1">
          <PrefRow icon={<Shield className="h-4 w-4" />} title="Session timeout" desc="Automatically sign out after inactivity" defaultChecked onChange={() => toast.info('Preference saved')} />
          <PrefRow icon={<Mail className="h-4 w-4" />} title="Two-factor authentication" desc="Extra security on sign in (coming soon)" onChange={() => toast.info('Coming soon')} />
        </div>
      </Card>

      <p className="text-center text-xs text-muted-foreground">
        Signed in as <span className="font-medium">{profile?.email}</span>
      </p>
    </div>
  );
}

function PrefRow({ icon, title, desc, defaultChecked, onChange }: {
  icon: React.ReactNode; title: string; desc: string; defaultChecked?: boolean; onChange: (checked: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between rounded-xl p-3 transition-colors hover:bg-accent/5">
      <div className="flex items-center gap-3">
        <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary">{icon}</span>
        <div>
          <p className="text-sm font-semibold">{title}</p>
          <p className="text-xs text-muted-foreground">{desc}</p>
        </div>
      </div>
      <Switch defaultChecked={defaultChecked} onCheckedChange={onChange} />
    </div>
  );
}
