export type UserRole = 'donor' | 'ngo' | 'admin';

export type FoodType = 'veg' | 'non-veg' | 'vegan';

export type FoodCategory =
  | 'cooked'
  | 'raw'
  | 'packaged'
  | 'bakery'
  | 'fruits'
  | 'vegetables'
  | 'dairy'
  | 'beverages'
  | 'groceries'
  | 'other';

export type DonationStatus =
  | 'pending'
  | 'accepted'
  | 'collected'
  | 'on_the_way'
  | 'delivered'
  | 'cancelled';

export type DeliveryStatus = 'accepted' | 'preparing' | 'collected' | 'on_the_way' | 'delivered' | 'cancelled';

export type RequestStatus = 'open' | 'fulfilled' | 'cancelled';

export type ReportType = 'fake' | 'expired' | 'spam' | 'abuse' | 'unsafe';

export type ReportStatus = 'open' | 'reviewing' | 'resolved' | 'dismissed';

export type NotificationType = 'donation' | 'request' | 'review' | 'report' | 'system';

export interface Profile {
  id: string;
  full_name: string;
  email: string;
  phone: string | null;
  avatar: string | null;
  role: UserRole;
  address: string | null;
  city: string | null;
  district: string | null;
  state: string | null;
  country: string | null;
  is_suspended: boolean;
  created_at: string;
  updated_at: string;
}

export interface FoodDonation {
  id: string;
  donor_id: string;
  food_name: string;
  food_type: FoodType;
  category: FoodCategory;
  quantity: number;
  unit: string;
  description: string | null;
  prepared_date: string | null;
  expiry_date: string | null;
  pickup_time: string | null;
  pickup_address: string;
  latitude: number | null;
  longitude: number | null;
  image_url: string | null;
  phone: string | null;
  special_instructions: string | null;
  status: DonationStatus;
  created_at: string;
  updated_at: string;
  donor?: Profile;
  accepted?: AcceptedDonation;
}

export interface FoodRequest {
  id: string;
  receiver_id: string;
  title: string;
  description: string | null;
  people_count: number;
  required_before: string | null;
  location: string | null;
  status: RequestStatus;
  created_at: string;
}

export interface AcceptedDonation {
  id: string;
  donation_id: string;
  receiver_id: string;
  accepted_time: string;
  pickup_time: string | null;
  delivery_status: DeliveryStatus;
  created_at: string;
  donation?: FoodDonation;
  receiver?: Profile;
}

export interface Notification {
  id: string;
  user_id: string;
  type: NotificationType;
  title: string;
  message: string;
  is_read: boolean;
  link: string | null;
  created_at: string;
}

export interface Review {
  id: string;
  donation_id: string;
  reviewer_id: string;
  reviewee_id: string;
  rating: number;
  comment: string | null;
  created_at: string;
  reviewer?: Profile;
}

export interface Report {
  id: string;
  donation_id: string | null;
  reporter_id: string;
  type: ReportType;
  reason: string;
  status: ReportStatus;
  created_at: string;
  donation?: FoodDonation;
  reporter?: Profile;
}

export interface DonationWithRelations extends Omit<FoodDonation, 'accepted'> {
  donor: Profile;
  accepted: AcceptedDonation | null;
  reviews: Review[];
}

export const FOOD_CATEGORIES: { value: FoodCategory; label: string }[] = [
  { value: 'cooked', label: 'Cooked Food' },
  { value: 'raw', label: 'Raw Ingredients' },
  { value: 'packaged', label: 'Packaged Food' },
  { value: 'bakery', label: 'Bakery' },
  { value: 'fruits', label: 'Fruits' },
  { value: 'vegetables', label: 'Vegetables' },
  { value: 'dairy', label: 'Dairy' },
  { value: 'beverages', label: 'Beverages' },
  { value: 'groceries', label: 'Groceries' },
  { value: 'other', label: 'Other' },
];

export const FOOD_TYPES: { value: FoodType; label: string }[] = [
  { value: 'veg', label: 'Vegetarian' },
  { value: 'non-veg', label: 'Non-Vegetarian' },
  { value: 'vegan', label: 'Vegan' },
];

export const UNITS = ['kg', 'g', 'litres', 'ml', 'packets', 'boxes', 'trays', 'portions', 'pieces'];

export const DONATION_STATUS_META: Record<
  DonationStatus,
  { label: string; color: string; bg: string; border: string }
> = {
  pending: { label: 'Pending', color: 'text-amber-700 dark:text-amber-300', bg: 'bg-amber-100 dark:bg-amber-500/15', border: 'border-amber-200 dark:border-amber-500/30' },
  accepted: { label: 'Accepted', color: 'text-blue-700 dark:text-blue-300', bg: 'bg-blue-100 dark:bg-blue-500/15', border: 'border-blue-200 dark:border-blue-500/30' },
  collected: { label: 'Collected', color: 'text-indigo-700 dark:text-indigo-300', bg: 'bg-indigo-100 dark:bg-indigo-500/15', border: 'border-indigo-200 dark:border-indigo-500/30' },
  on_the_way: { label: 'On The Way', color: 'text-purple-700 dark:text-purple-300', bg: 'bg-purple-100 dark:bg-purple-500/15', border: 'border-purple-200 dark:border-purple-500/30' },
  delivered: { label: 'Delivered', color: 'text-green-700 dark:text-green-300', bg: 'bg-green-100 dark:bg-green-500/15', border: 'border-green-200 dark:border-green-500/30' },
  cancelled: { label: 'Cancelled', color: 'text-red-700 dark:text-red-300', bg: 'bg-red-100 dark:bg-red-500/15', border: 'border-red-200 dark:border-red-500/30' },
};

export const DELIVERY_STATUS_STEPS: { value: DeliveryStatus; label: string }[] = [
  { value: 'accepted', label: 'Accepted' },
  { value: 'preparing', label: 'Preparing Pickup' },
  { value: 'collected', label: 'Collected' },
  { value: 'on_the_way', label: 'On The Way' },
  { value: 'delivered', label: 'Delivered' },
];
