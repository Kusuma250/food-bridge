/*
# Food Bridge — Core Schema, RLS, Storage & Triggers

1. Purpose
   Food Bridge is a multi-user food donation platform with three roles:
   donor, ngo (receiver), and admin. This migration lays down the complete
   production schema, row-level security, storage buckets, and automation
   triggers (profile creation on signup, atomic donation acceptance with
   notification).

2. New Tables
   - profiles            : per-user public profile, role, location, suspension flag
   - food_donations      : surplus food listings created by donors
   - food_requests       : open food requirements posted by receivers
   - accepted_donations  : join record when an NGO accepts a donation (delivery status)
   - notifications       : in-app notifications scoped per user
   - reviews             : 5-star reviews between donor and receiver
   - reports             : abuse/fake/expired reports submitted by users

3. Relationships
   - profiles.id  <- auth.users(id)  (1:1)
   - food_donations.donor_id        -> profiles.id
   - food_requests.receiver_id      -> profiles.id
   - accepted_donations.donation_id -> food_donations.id
   - accepted_donations.receiver_id -> profiles.id
   - notifications.user_id          -> profiles.id
   - reviews.donation_id            -> food_donations.id
   - reviews.reviewer_id / reviewee_id -> profiles.id
   - reports.donation_id            -> food_donations.id
   - reports.reporter_id            -> profiles.id

4. Automation
   - handle_new_user() trigger: inserts a profiles row whenever a new
     auth.users row is created, copying full_name/phone/role from the
     user's signup metadata.
   - accept_donation() function: atomically creates an accepted_donations
     row, flips the donation status to 'accepted', and inserts a
     notification for the donor. Guards against double-acceptance.

5. Security (RLS)
   - profiles           : self read/update; admins read all
   - food_donations     : donors own their rows; receivers read pending
                          or rows they accepted; admins see all
   - accepted_donations : donor + receiver of the linked donation; admins
   - food_requests      : owner + admin; receivers read open requests
   - notifications      : owner only + admin
   - reviews            : participants of the donation + admin
   - reports            : reporter + admin only
   All policies use auth.uid(); no public access.

6. Storage
   - food-images bucket (public read, authenticated write to own paths)
   - avatars bucket (public read, authenticated write to own path)
*/

-- ============ TABLES FIRST (so functions/policies can reference them) ============

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  email text not null,
  phone text,
  avatar text,
  role text not null default 'donor' check (role in ('donor','ngo','admin')),
  address text,
  city text,
  district text,
  state text,
  country text,
  is_suspended boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.food_donations (
  id uuid primary key default gen_random_uuid(),
  donor_id uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  food_name text not null,
  food_type text not null check (food_type in ('veg','non-veg','vegan')),
  category text not null check (category in ('cooked','raw','packaged','bakery','fruits','vegetables','dairy','beverages','groceries','other')),
  quantity numeric not null default 0,
  unit text not null default 'kg',
  description text,
  prepared_date date,
  expiry_date timestamptz,
  pickup_time text,
  pickup_address text not null,
  latitude double precision,
  longitude double precision,
  image_url text,
  phone text,
  special_instructions text,
  status text not null default 'pending' check (status in ('pending','accepted','collected','on_the_way','delivered','cancelled')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.food_requests (
  id uuid primary key default gen_random_uuid(),
  receiver_id uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  title text not null,
  description text,
  people_count integer not null default 1 check (people_count > 0),
  required_before date,
  location text,
  status text not null default 'open' check (status in ('open','fulfilled','cancelled')),
  created_at timestamptz not null default now()
);

create table if not exists public.accepted_donations (
  id uuid primary key default gen_random_uuid(),
  donation_id uuid not null references public.food_donations(id) on delete cascade,
  receiver_id uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  accepted_time timestamptz not null default now(),
  pickup_time text,
  delivery_status text not null default 'accepted' check (delivery_status in ('accepted','preparing','collected','on_the_way','delivered','cancelled')),
  created_at timestamptz not null default now(),
  unique (donation_id)
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  type text not null default 'system' check (type in ('donation','request','review','report','system')),
  title text not null,
  message text not null,
  is_read boolean not null default false,
  link text,
  created_at timestamptz not null default now()
);

create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  donation_id uuid not null references public.food_donations(id) on delete cascade,
  reviewer_id uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  reviewee_id uuid not null references public.profiles(id) on delete cascade,
  rating integer not null check (rating between 1 and 5),
  comment text,
  created_at timestamptz not null default now()
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  donation_id uuid references public.food_donations(id) on delete set null,
  reporter_id uuid not null default auth.uid() references public.profiles(id) on delete cascade,
  type text not null check (type in ('fake','expired','spam','abuse','unsafe')),
  reason text not null,
  status text not null default 'open' check (status in ('open','reviewing','resolved','dismissed')),
  created_at timestamptz not null default now()
);

-- ============ INDEXES ============
create index if not exists idx_food_donations_donor_id on public.food_donations(donor_id);
create index if not exists idx_food_donations_status on public.food_donations(status);
create index if not exists idx_food_donations_category on public.food_donations(category);
create index if not exists idx_food_donations_created_at on public.food_donations(created_at desc);
create index if not exists idx_food_requests_receiver_id on public.food_requests(receiver_id);
create index if not exists idx_food_requests_status on public.food_requests(status);
create index if not exists idx_accepted_donations_receiver_id on public.accepted_donations(receiver_id);
create index if not exists idx_accepted_donations_donation_id on public.accepted_donations(donation_id);
create index if not exists idx_notifications_user_id on public.notifications(user_id);
create index if not exists idx_notifications_is_read on public.notifications(is_read);
create index if not exists idx_reviews_donation_id on public.reviews(donation_id);
create index if not exists idx_reviews_reviewee_id on public.reviews(reviewee_id);
create index if not exists idx_reports_status on public.reports(status);

-- ============ HELPER FUNCTIONS ============
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'admin'
  );
$$;

-- ============ ENABLE RLS ============
alter table public.profiles enable row level security;
alter table public.food_donations enable row level security;
alter table public.food_requests enable row level security;
alter table public.accepted_donations enable row level security;
alter table public.notifications enable row level security;
alter table public.reviews enable row level security;
alter table public.reports enable row level security;

-- ============ POLICIES: profiles ============
drop policy if exists "profiles_select_self_or_admin" on public.profiles;
create policy "profiles_select_self_or_admin"
  on public.profiles for select to authenticated
  using (auth.uid() = id or public.is_admin());

drop policy if exists "profiles_insert_self" on public.profiles;
create policy "profiles_insert_self"
  on public.profiles for insert to authenticated
  with check (auth.uid() = id);

drop policy if exists "profiles_update_self" on public.profiles;
create policy "profiles_update_self"
  on public.profiles for update to authenticated
  using (auth.uid() = id)
  with check (auth.uid() = id);

drop policy if exists "profiles_update_admin" on public.profiles;
create policy "profiles_update_admin"
  on public.profiles for update to authenticated
  using (public.is_admin())
  with check (public.is_admin());

-- ============ POLICIES: food_donations ============
drop policy if exists "donations_select_owner_receiver_admin" on public.food_donations;
create policy "donations_select_owner_receiver_admin"
  on public.food_donations for select to authenticated
  using (
    donor_id = auth.uid()
    or status = 'pending'
    or public.is_admin()
    or exists (
      select 1 from public.accepted_donations ad
      where ad.donation_id = food_donations.id and ad.receiver_id = auth.uid()
    )
  );

drop policy if exists "donations_insert_owner" on public.food_donations;
create policy "donations_insert_owner"
  on public.food_donations for insert to authenticated
  with check (donor_id = auth.uid());

drop policy if exists "donations_update_owner_admin" on public.food_donations;
create policy "donations_update_owner_admin"
  on public.food_donations for update to authenticated
  using (donor_id = auth.uid() or public.is_admin())
  with check (donor_id = auth.uid() or public.is_admin());

drop policy if exists "donations_delete_owner_admin" on public.food_donations;
create policy "donations_delete_owner_admin"
  on public.food_donations for delete to authenticated
  using (donor_id = auth.uid() or public.is_admin());

-- ============ POLICIES: food_requests ============
drop policy if exists "requests_select_owner_or_open_admin" on public.food_requests;
create policy "requests_select_owner_or_open_admin"
  on public.food_requests for select to authenticated
  using (receiver_id = auth.uid() or status = 'open' or public.is_admin());

drop policy if exists "requests_insert_owner" on public.food_requests;
create policy "requests_insert_owner"
  on public.food_requests for insert to authenticated
  with check (receiver_id = auth.uid());

drop policy if exists "requests_update_owner_admin" on public.food_requests;
create policy "requests_update_owner_admin"
  on public.food_requests for update to authenticated
  using (receiver_id = auth.uid() or public.is_admin())
  with check (receiver_id = auth.uid() or public.is_admin());

drop policy if exists "requests_delete_owner_admin" on public.food_requests;
create policy "requests_delete_owner_admin"
  on public.food_requests for delete to authenticated
  using (receiver_id = auth.uid() or public.is_admin());

-- ============ POLICIES: accepted_donations ============
drop policy if exists "accepted_select_participant_admin" on public.accepted_donations;
create policy "accepted_select_participant_admin"
  on public.accepted_donations for select to authenticated
  using (
    receiver_id = auth.uid()
    or public.is_admin()
    or exists (
      select 1 from public.food_donations fd
      where fd.id = accepted_donations.donation_id and fd.donor_id = auth.uid()
    )
  );

drop policy if exists "accepted_insert_via_rpc" on public.accepted_donations;
create policy "accepted_insert_via_rpc"
  on public.accepted_donations for insert to authenticated
  with check (receiver_id = auth.uid());

drop policy if exists "accepted_update_participant_admin" on public.accepted_donations;
create policy "accepted_update_participant_admin"
  on public.accepted_donations for update to authenticated
  using (
    receiver_id = auth.uid()
    or public.is_admin()
    or exists (
      select 1 from public.food_donations fd
      where fd.id = accepted_donations.donation_id and fd.donor_id = auth.uid()
    )
  )
  with check (
    receiver_id = auth.uid()
    or public.is_admin()
    or exists (
      select 1 from public.food_donations fd
      where fd.id = accepted_donations.donation_id and fd.donor_id = auth.uid()
    )
  );

drop policy if exists "accepted_delete_admin" on public.accepted_donations;
create policy "accepted_delete_admin"
  on public.accepted_donations for delete to authenticated
  using (public.is_admin());

-- ============ POLICIES: notifications ============
drop policy if exists "notifications_select_owner_admin" on public.notifications;
create policy "notifications_select_owner_admin"
  on public.notifications for select to authenticated
  using (user_id = auth.uid() or public.is_admin());

drop policy if exists "notifications_insert_owner_or_admin" on public.notifications;
create policy "notifications_insert_owner_or_admin"
  on public.notifications for insert to authenticated
  with check (user_id = auth.uid() or public.is_admin());

drop policy if exists "notifications_update_owner_admin" on public.notifications;
create policy "notifications_update_owner_admin"
  on public.notifications for update to authenticated
  using (user_id = auth.uid() or public.is_admin())
  with check (user_id = auth.uid() or public.is_admin());

drop policy if exists "notifications_delete_owner_admin" on public.notifications;
create policy "notifications_delete_owner_admin"
  on public.notifications for delete to authenticated
  using (user_id = auth.uid() or public.is_admin());

-- ============ POLICIES: reviews ============
drop policy if exists "reviews_select_participant_admin" on public.reviews;
create policy "reviews_select_participant_admin"
  on public.reviews for select to authenticated
  using (
    reviewer_id = auth.uid()
    or reviewee_id = auth.uid()
    or public.is_admin()
    or exists (
      select 1 from public.food_donations fd
      where fd.id = reviews.donation_id
        and (fd.donor_id = auth.uid() or exists (
          select 1 from public.accepted_donations ad
          where ad.donation_id = fd.id and ad.receiver_id = auth.uid()
        ))
    )
  );

drop policy if exists "reviews_insert_participant" on public.reviews;
create policy "reviews_insert_participant"
  on public.reviews for insert to authenticated
  with check (
    reviewer_id = auth.uid()
    and exists (
      select 1 from public.food_donations fd
      where fd.id = reviews.donation_id
        and (fd.donor_id = auth.uid() or exists (
          select 1 from public.accepted_donations ad
          where ad.donation_id = fd.id and ad.receiver_id = auth.uid()
        ))
    )
  );

drop policy if exists "reviews_delete_owner_admin" on public.reviews;
create policy "reviews_delete_owner_admin"
  on public.reviews for delete to authenticated
  using (reviewer_id = auth.uid() or public.is_admin());

-- ============ POLICIES: reports ============
drop policy if exists "reports_select_reporter_admin" on public.reports;
create policy "reports_select_reporter_admin"
  on public.reports for select to authenticated
  using (reporter_id = auth.uid() or public.is_admin());

drop policy if exists "reports_insert_reporter" on public.reports;
create policy "reports_insert_reporter"
  on public.reports for insert to authenticated
  with check (reporter_id = auth.uid());

drop policy if exists "reports_update_admin" on public.reports;
create policy "reports_update_admin"
  on public.reports for update to authenticated
  using (public.is_admin())
  with check (public.is_admin());

drop policy if exists "reports_delete_admin" on public.reports;
create policy "reports_delete_admin"
  on public.reports for delete to authenticated
  using (public.is_admin() or reporter_id = auth.uid());

-- ============ TRIGGERS & FUNCTIONS ============
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_profiles_updated_at on public.profiles;
create trigger trg_profiles_updated_at
  before update on public.profiles
  for each row execute function public.set_updated_at();

drop trigger if exists trg_food_donations_updated_at on public.food_donations;
create trigger trg_food_donations_updated_at
  before update on public.food_donations
  for each row execute function public.set_updated_at();

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, email, phone, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', 'New User'),
    new.email,
    new.raw_user_meta_data->>'phone',
    coalesce(new.raw_user_meta_data->>'role', 'donor')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

create or replace function public.accept_donation(
  p_donation_id uuid,
  p_receiver_id uuid
)
returns public.accepted_donations
language plpgsql
security definer
set search_path = public
as $$
declare
  result public.accepted_donations;
  donor_id uuid;
begin
  select fd.donor_id into donor_id
  from public.food_donations fd
  where fd.id = p_donation_id and fd.status = 'pending'
  for update;

  if donor_id is null then
    raise exception 'Donation is no longer available';
  end if;

  insert into public.accepted_donations (donation_id, receiver_id)
  values (p_donation_id, p_receiver_id)
  returning * into result;

  update public.food_donations
    set status = 'accepted', updated_at = now()
    where id = p_donation_id;

  insert into public.notifications (user_id, type, title, message, link)
  values (
    donor_id,
    'donation',
    'Donation Accepted',
    'Your donation has been accepted by an NGO. Check your dashboard for pickup details.',
    '/dashboard/donor/my-donations'
  );

  insert into public.notifications (user_id, type, title, message, link)
  values (
    p_receiver_id,
    'donation',
    'Acceptance Confirmed',
    'You accepted a donation. Coordinate pickup with the donor.',
    '/dashboard/receiver/accepted'
  );

  return result;
end;
$$;

-- ============ STORAGE BUCKETS ============
insert into storage.buckets (id, name, public)
values ('food-images', 'food-images', true)
on conflict (id) do nothing;

insert into storage.buckets (id, name, public)
values ('avatars', 'avatars', true)
on conflict (id) do nothing;

drop policy if exists "food_images_public_read" on storage.objects;
create policy "food_images_public_read"
  on storage.objects for select to anon, authenticated
  using (bucket_id = 'food-images');

drop policy if exists "food_images_auth_insert" on storage.objects;
create policy "food_images_auth_insert"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'food-images');

drop policy if exists "food_images_owner_delete" on storage.objects;
create policy "food_images_owner_delete"
  on storage.objects for delete to authenticated
  using (bucket_id = 'food-images' and owner = auth.uid());

drop policy if exists "avatars_public_read" on storage.objects;
create policy "avatars_public_read"
  on storage.objects for select to anon, authenticated
  using (bucket_id = 'avatars');

drop policy if exists "avatars_auth_insert" on storage.objects;
create policy "avatars_auth_insert"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'avatars');

drop policy if exists "avatars_owner_update" on storage.objects;
create policy "avatars_owner_update"
  on storage.objects for update to authenticated
  using (bucket_id = 'avatars' and owner = auth.uid())
  with check (bucket_id = 'avatars');

drop policy if exists "avatars_owner_delete" on storage.objects;
create policy "avatars_owner_delete"
  on storage.objects for delete to authenticated
  using (bucket_id = 'avatars' and owner = auth.uid());
